"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    percentage: { type: Number, trim: true, required: true },
    phase: { type: String, trim: true, lowercase: true, unique: true, required: true },
    projectId: { type: mongoose_1.Types.ObjectId, ref: 'project' },
    createdBy: { type: String },
    isDeleted: { type: Boolean, default: false }
}, { timestamps: true });
exports.financialSchema = mongoose_1.model('financial_info', schema);
