"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const error_msg_1 = require("../utils/error_msg");
const users_1 = require("../utils/users");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const module_1 = require("../role/module");
;
//  create Private Group 
async function createPrivateGroup(body, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, "manage-private-group");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.PRIVATE_MEMBER.CREATE.NO_ACCESS, 403);
        if (!body.name || body.name.trim() == "" || !Array.isArray(body.members) || !body.members.length)
            throw new Error(error_msg_1.PRIVATE_MEMBER.CREATE.MISSING_FIELDS);
        if (body.name && (!/.*[A-Za-z0-9]{1}.*$/.test(body.name)))
            throw new Error(error_msg_1.PRIVATE_MEMBER.CREATE.INVALID_NAME);
        // await validatePrivateMembersConstants(body);
        if (body.members.includes(userObj._id))
            throw new Error(error_msg_1.PRIVATE_MEMBER.CREATE.OWNER_NOT_PRIVATE_MEMBER);
        let existGroups = await model_1.privateGroupSchema.find({ codeName: body.name, createdBy: userObj._id, is_active: true });
        if (existGroups.length)
            throw new Error(error_msg_1.PRIVATE_MEMBER.CREATE.GROUP_NAME_EXIST);
        return model_1.privateGroupSchema.create(Object.assign({}, body, { codeName: body.name, createdBy: userObj._id }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.createPrivateGroup = createPrivateGroup;
;
//  edit Private Group
async function editPrivateGroup(groupId, body, userId) {
    try {
        let groupDetails = await model_1.privateGroupSchema.findById(groupId).exec();
        if (!groupDetails)
            throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.GROUP_NOT_FOUND);
        if (groupDetails.createdBy != userId)
            throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.NO_ACCESS);
        if (body.members && (!Array.isArray(body.members) || !body.members.length))
            throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.MINIMUM_ONE_USER_REQUIRED);
        if (body.name && (!/.*[A-Za-z0-9]{1}.*$/.test(body.name)))
            throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.INVALID_NAME);
        // await validatePrivateMembersConstants(body);
        if (body)
            if (body.members) {
                let existUsersRemoved = body.members.filter((user) => !groupDetails.members.includes(user));
                if (!existUsersRemoved.length)
                    throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.ALREADY_MEMBER);
                body.members = [...new Set(groupDetails.members.concat(body.members))];
                if (body.members.includes(userId))
                    throw new Error(error_msg_1.PRIVATE_MEMBER.EDIT.OWNER_NOT_PRIVATE_MEMBER);
            }
        return await model_1.privateGroupSchema.findByIdAndUpdate(groupId, { $set: Object.assign({}, body) });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.editPrivateGroup = editPrivateGroup;
;
//  edit Private Group
async function removePrivateGroup(groupId, body, userId) {
    try {
        let groupDetails = await model_1.privateGroupSchema.findById(groupId).exec();
        if (!groupDetails)
            throw new Error(error_msg_1.PRIVATE_MEMBER.REMOVE.GROUP_NOT_FOUND);
        if (groupDetails.createdBy != userId)
            throw new Error(error_msg_1.PRIVATE_MEMBER.REMOVE.NO_ACCESS);
        if (Array.isArray(body.members) && body.members.length) {
            body.members = groupDetails.members.filter((userId) => !body.members.includes(userId));
        }
        if (groupDetails.members.length == 1)
            throw new Error(error_msg_1.PRIVATE_MEMBER.REMOVE.MINIMUM_ONE_USER_REQUIRED);
        return await model_1.privateGroupSchema.findByIdAndUpdate(groupId, { $set: Object.assign({}, body) });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.removePrivateGroup = removePrivateGroup;
;
//  change private Group status
async function privateGroupStatus(groupId, userId) {
    try {
        let group = await model_1.privateGroupSchema.findById(groupId).exec();
        if (!group)
            throw new Error(error_msg_1.PRIVATE_MEMBER.STATUS.GROUP_NOT_FOUND);
        if (group.createdBy != userId)
            throw new Error(error_msg_1.PRIVATE_MEMBER.STATUS.NO_ACCESS);
        let data = await model_1.privateGroupSchema.findByIdAndUpdate(groupId, { $set: { is_active: group.is_active ? false : true } });
        return { message: data.is_active ? error_msg_1.RESPONSE.ACTIVE : error_msg_1.RESPONSE.INACTIVE };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.privateGroupStatus = privateGroupStatus;
;
//  Get Group Detail
async function privateGroupDetails(groupId) {
    try {
        let groupDetail = await model_1.privateGroupSchema.findById(groupId).exec();
        return await groupDetails(groupDetail);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.privateGroupDetails = privateGroupDetails;
;
//  Get Group Detail
async function privateGroupList(userId, search) {
    try {
        let searchQuery = search ? { name: new RegExp(search, "i"), createdBy: userId, is_active: true } : { createdBy: userId, is_active: true };
        let groupList = await model_1.privateGroupSchema.find(Object.assign({}, searchQuery)).exec();
        return await Promise.all(groupList.map((group) => groupDetails(group)));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.privateGroupList = privateGroupList;
;
async function groupDetails(group) {
    try {
        let userData = await users_1.userFindMany('_id', group.members.concat([group.createdBy]), { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, is_active: 1 });
        userData = await Promise.all(userData.map((user) => getUserDateWithRole(user)));
        return Object.assign({}, group.toJSON(), { createdBy: userData.find((user) => user._id == group.createdBy), members: userData.filter((user) => group.members.includes(user._id)) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function getUserDateWithRole(userData) {
    return Object.assign({}, userData, { role: ((await module_1.userRoleAndScope(userData._id)).data || [""])[0] });
}
;
// async function validatePrivateMembersConstants(body: any) {
//     try {
//         let { docNamePg, docDescriptionPg }: any = await getConstantsAndValues(["docNamePg", "docDescriptionPg"])
//         if (body.name > Number(docNamePg)) {
//             throw new Error(`Private members name should not exceed more than ${docNamePg} characters`);
//         }
//         if (body.description > Number(docDescriptionPg)) {
//             throw new Error(`Private members description should not exceed more than ${docDescriptionPg} characters`);
//         }
//     }
//     catch (err) {
//         throw err
//     }
// }
