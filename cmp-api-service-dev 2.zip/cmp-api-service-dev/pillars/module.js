"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const role_management_1 = require("../utils/role_management");
const urls_1 = require("../utils/urls");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
async function create(userId, payload, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `add-edit-pillar`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const pillarInfo = await model_1.PillarSchema.create(Object.assign({}, payload, { nameCode: payload.name, createdBy: userId }));
    return { pillarInfo, successMessage: `Pillar created successfully` };
}
exports.create = create;
async function list(userToken) {
    const tasks = await role_management_1.httpRequest({
        url: `${urls_1.TASKS_URL}/task/getPillarRelatedTasks`,
        json: true,
        method: 'POST',
        body: { status: { $nin: [8] } },
        headers: { 'Authorization': `Bearer ${userToken}` }
    });
    const pillars = await model_1.PillarSchema.find({ disabled: false }).exec();
    return pillars.map((pillar) => {
        const filteredTasks = tasks.filter((task) => task.pillarId == pillar.id);
        return (Object.assign({}, pillar.toJSON(), { progressPercentage: filteredTasks.length ? (filteredTasks.reduce((p, c) => p + (c.progressPercentage || 0), 0) / filteredTasks.length).toFixed(0) : 0 }));
    });
}
exports.list = list;
async function pillarDetail(id) {
    return await model_1.PillarSchema.findById(id).exec();
}
exports.pillarDetail = pillarDetail;
async function updatePillar(id, updates, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `add-edit-pillar`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    if (updates.name) {
        updates = Object.assign({}, updates, { nameCode: updates.name });
    }
    let pillarInfo = await model_1.PillarSchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
    return { pillarInfo, successMessage: `Pillar updated successfully` };
}
exports.updatePillar = updatePillar;
async function getPillars() {
    return await model_1.PillarSchema.find({ disabled: false }).exec();
}
exports.getPillars = getPillars;
async function getPillarsbyIds(pillarIds) {
    return await model_1.PillarSchema.find({ _id: { $in: pillarIds } }).exec();
}
exports.getPillarsbyIds = getPillarsbyIds;
