"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const error_msg_1 = require("../utils/error_msg");
const email_1 = require("../utils/email");
const utils_1 = require("../utils/utils");
const module_1 = require("../role/module");
const role_management_1 = require("../utils/role_management");
const mongoose_1 = require("mongoose");
const rbac_1 = require("../utils/rbac");
const groups_1 = require("../utils/groups");
const urls_1 = require("../utils/urls");
const users_1 = require("../utils/users");
const phoneNo = require("phone");
const request = require("request");
const login_model_1 = require("./login-model");
const module_2 = require("../email-templates/module");
const custom_error_1 = require("../utils/custom-error");
const model_1 = require("../site-constants/model");
const model_2 = require("../private-groups/model");
const module_3 = require("../project/module");
const path_1 = require("path");
const role_management_2 = require("../utils/role_management");
const module_4 = require("../notifications/module");
const fs_1 = require("fs");
const module_5 = require("../socket-notifications/module");
const module_6 = require("../log/module");
const module_7 = require("../site-constants/module");
const module_8 = require("../sms/module");
const module_9 = require("../documents/module");
const module_10 = require("../patterns/module");
const module_11 = require("../documents/module");
const module_12 = require("../tags/module");
const refresh_token_model_1 = require("./refresh-token-model");
const web_notification_messages_1 = require("../utils/web-notification-messages");
// inside middleware handler
const MESSAGE_URL = process.env.MESSAGE_URL;
const secretKey = process.env.MSG91_KEY || "6LfIqcQUAAAAAFU-SiCls_K8Y84mn-A4YRebYOkT";
async function bulkInvite(filePath, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `bulk-invite`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    let constantsList = await model_1.constantSchema.findOne({ key: 'bulkInvite' }).exec();
    if (constantsList.value == "true") {
        const excelFormattedData = module_3.importExcelAndFormatData(filePath);
        if (!excelFormattedData.length) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.UPLOAD_EMPTY_FOLDER);
        }
        const [roleData, usersList] = await Promise.all([
            module_1.role_list(),
            users_1.userList({}, { email: 1 })
        ]);
        const existingEmails = usersList.map((user) => (user.email || '').toLowerCase()).filter((v) => !!v);
        const categories = Array.from(new Set(roleData.roles.map((role) => role.category)));
        const formattedDataWithRoles = excelFormattedData.map(data => {
            const matchedRole = roleData.roles.find((role) => role.roleName == data.Role);
            if (existingEmails.includes(data.Email.toLowerCase())) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.EMAIL_EXIST(data.Email));
            }
            // if (!categories.includes(data.Category)) {
            //     throw new APIError(USER_ROUTER.CATEGORY_NOT_MATCH(data.Category))
            // }
            if (!matchedRole) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.NO_ROLE_MATCH(data.Role));
            }
            return Object.assign({}, data, { category: data.Category, email: data.Email, role: [matchedRole.role] });
        });
        if (formattedDataWithRoles.some(role => !role.role || !role.email)) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.CATEGORY_REQUIRE_ALL_MANDATORY);
        }
        formattedDataWithRoles.forEach((role) => {
            if (!validateEmail(role.email)) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_EMAIL(role.email));
            }
        });
        await Promise.all(formattedDataWithRoles.map(data => inviteUser(data, user)));
        return { message: 'success' };
    }
    else {
        throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.DISABLED_BULK_UPLOAD);
    }
}
exports.bulkInvite = bulkInvite;
//  Create User
async function inviteUser(objBody, user) {
    try {
        if (!objBody.email || !objBody.role || !user) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        ;
        if (objBody.email) {
            if (!validateEmail(objBody.email)) {
                throw Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
            }
        }
        //  Check User Capability
        let admin_scope = await role_management_1.checkRoleScope(user.role, "create-user");
        if (!admin_scope)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        let userData = await users_1.createUser({
            email: objBody.email,
            firstName: objBody.firstName,
            lastName: objBody.lastName,
            middleName: objBody.middleName
        });
        let { fullName } = getFullNameAndMobile(userData);
        //  Add Role to User
        if (objBody.role && objBody.role.length) {
            for (let role of objBody.role) {
                let RoleStatus = await rbac_1.addRole(userData._id, role);
                if (!RoleStatus.status) {
                    await users_1.userDelete(userData.id);
                    throw new Error(error_msg_1.USER_ROUTER.CREATE_ROLE_FAIL);
                }
            }
        }
        //  Create 24hr Token
        let token = await utils_1.jwt_for_url({
            id: userData._id,
            email: userData.email,
            role: await formateRoles(objBody.role)
        });
        let configLink = await model_1.constantSchema.findOne({ key: 'linkExpire' }).exec();
        sendNotification({ id: user._id, fullName, email: objBody.email, linkExpire: Number(configLink.value), role: await formateRoles(objBody.role), link: `${urls_1.ANGULAR_URL}/user/register/${token}`, templateName: "invite" });
        await module_6.create({ activityType: "INVITE-USER", activityBy: user._id, profileId: userData._id });
        return { userId: userData._id };
    }
    catch (err) {
        throw err;
    }
}
exports.inviteUser = inviteUser;
//  Register User
async function RegisterUser(objBody, verifyToken) {
    try {
        if (!verifyToken) {
            throw new Error(error_msg_1.USER_ROUTER.TOKEN_MISSING);
        }
        //  Verify Token
        let token = await utils_1.jwt_Verify(verifyToken);
        if (token == "TokenExpiredError") {
            throw new Error(error_msg_1.USER_ROUTER.TOKEN_EXPIRED);
        }
        if (token == "JsonWebTokenError") {
            throw new Error(error_msg_1.USER_ROUTER.TOKEN_INVALID);
        }
        let user = await users_1.userFindOne("id", token.id);
        if (!user)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_EXIST);
        if (user.emailVerified)
            throw new Error(error_msg_1.USER_ROUTER.ALREADY_REGISTER);
        const { firstName, lastName, middleName, password, phone, aboutme, countryCode, profilePic, name } = objBody;
        if (!firstName || !lastName || !password || !phone || !countryCode) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        ;
        await validatePassword(password);
        let phoneNumber = countryCode + phone;
        if (!phoneNo(phoneNumber).length) {
            throw new Error(error_msg_1.USER_ROUTER.VALID_PHONE_NO);
        }
        let constantsList = await model_1.constantSchema.findOne({ key: 'aboutMe' }).exec();
        if (aboutme.length > Number(constantsList.value)) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.ABOUTME_LIMIT.replace('{}', constantsList.value));
        }
        //  hash the password
        let success = await users_1.userEdit(token.id, {
            firstName, lastName, password, phone,
            profilePic,
            middleName: middleName || '',
            is_active: true,
            countryCode: countryCode || null,
            aboutme: aboutme || null,
            emailVerified: true,
            profilePicName: name
        });
        //  create life time token
        await module_6.create({ activityType: "REGISTER-USER", activityBy: token.id, profileId: token.id });
        // Send email
        let { fullName, mobileNo } = getFullNameAndMobile(success);
        objBody.role = (Array.isArray(objBody.role) ? objBody.role : typeof (objBody.role) == "string" && objBody.role.length ? objBody.role.includes("[") ? JSON.parse(objBody.role) : objBody.role = objBody.role.split(',') : []);
        let role = await formateRoles(objBody.role);
        sendNotification({ id: user._id, fullName, email: success.email, role: role, link: `${urls_1.ANGULAR_URL}/user/login`, templateName: "registrationSuccess" });
        return { token: await users_1.createJWT({ id: success._id, role: token.role }) };
    }
    catch (err) {
        throw err;
    }
}
exports.RegisterUser = RegisterUser;
//  Edit user
async function edit_user(id, objBody, user, token) {
    try {
        let user_roles = await userRoles(id, true);
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        if (objBody.email) {
            if (!validateEmail(objBody.email)) {
                throw new Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
            }
        }
        if (id != user._id) {
            let admin_scope = await role_management_1.checkRoleScope(user.role, "edit-user-profile");
            if (!admin_scope)
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        }
        if (objBody.password) {
            await validatePassword(objBody.password);
        }
        if (objBody.phone && objBody.countryCode) {
            let phoneNumber = objBody.countryCode + objBody.phone;
            if (!phoneNo(phoneNumber).length) {
                throw new Error(error_msg_1.USER_ROUTER.VALID_PHONE_NO);
            }
        }
        ;
        let userRole = [];
        let editUserInfo = await users_1.userFindOne("id", id);
        let { fullName, mobileNo } = getFullNameAndMobile(editUserInfo);
        objBody.role = (Array.isArray(objBody.role) ? objBody.role : typeof (objBody.role) == "string" && objBody.role.length ? objBody.role.includes("[") ? JSON.parse(objBody.role) : objBody.role = objBody.role.split(',') : []);
        if (objBody.role && objBody.role.length) {
            if (id != user._id) {
                let admin_scope = await role_management_1.checkRoleScope(user.role, "change-user-role");
                if (!admin_scope)
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
            }
            if (!objBody.role.length)
                throw new Error(error_msg_1.USER_ROUTER.MINIMUM_ONE_ROLE);
            if (user_roles && user_roles.length) {
                const removeRole = await Promise.all(user_roles.map(async (role) => {
                    let RoleStatus = await rbac_1.revokeRole(id, role);
                    if (!RoleStatus.status) {
                        throw new Error(error_msg_1.USER_ROUTER.REVOKE_ROLE_FAIL);
                    }
                }));
            }
            const addrole = await Promise.all(objBody.role.map(async (role) => {
                let RoleStatus = await rbac_1.addRole(id, role);
                if (!RoleStatus.status) {
                    throw new Error(error_msg_1.USER_ROUTER.CREATE_ROLE_FAIL);
                }
                userRole.push(role);
            }));
            let role = await formateRoles(objBody.role);
            await module_6.create({ activityType: "EDIT-ROLE", activityBy: user._id, profileId: id });
            sendNotification({ id: user._id, fullName, mobileNo, email: objBody.email, role: role, templateName: "changeUserRole", mobileTemplateName: "changeUserRole" });
            return { message: "user roles updated successfully." };
        }
        let constantsList = await model_1.constantSchema.findOne({ key: 'aboutMe' }).exec();
        if (objBody.aboutme) {
            if (objBody.aboutme.length > Number(constantsList.value)) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.ABOUTME_LIMIT.replace('{}', constantsList.value));
            }
        }
        ;
        if (objBody.name) {
            objBody.profilePicName = objBody.name;
            delete objBody.name;
        }
        // update user with edited fields
        let userInfo = await users_1.userEdit(id, objBody);
        let userData = getFullNameAndMobile(userInfo);
        let updateUserInElasticSearch = module_11.updateUserInDOcs(id, user.id);
        let updateUsersInMessages = module_12.updateUserInMessages({ id }, token);
        let updateUsersInTasks = module_12.updateUserInTasks({ id }, token);
        userInfo.role = userRole;
        let editedKeys = Object.keys(editUserInfo).filter(key => { if (key != "updatedAt")
            return editUserInfo[key] != userInfo[key]; });
        await module_6.create({ activityType: "EDIT-PROFILE", activityBy: user._id, profileId: userInfo._id, editedFields: editedKeys.map(key => formatProfileKeys(key)) });
        sendNotification({ id, fullName: userData.fullName, mobileNo: userData.mobileNo, email: userInfo.email, templateName: "profile", mobileTemplateName: "profile" });
        return userInfo;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.edit_user = edit_user;
;
function formatProfileKeys(key) {
    switch (key) {
        case 'firstName':
            key = `First Name`;
            break;
        case `lastName`:
            key = `Last Name`;
            break;
        case `middleName`:
            key = `Middle Name`;
            break;
        case `email`:
            key = `Email`;
            break;
        case `countryCode`:
            key = `Country Code`;
            break;
        case `phone`:
            key = `Mobile Number`;
            break;
        case `aboutme`:
            key = `About Me`;
            break;
        case `profilePic`:
            key = `Profile Picture`;
            break;
        default:
            break;
    }
    return key;
}
// Get User List
async function user_list(query, userId, searchKey, page = 1, limit = 100, pagination = true, sort = "createdAt", ascending = false) {
    try {
        let findQuery = {}; //{ _id: { $ne: Types.ObjectId(userId) } }
        let docs;
        if (searchKey) {
            docs = await users_1.userListForHome(searchKey);
            let data = await Promise.all(docs.map((doc) => userWithRoleAndType(doc)));
            let rolesBody = await module_1.role_list();
            data = await roleFormanting(data);
            if (pagination)
                return manualPaginationForUserList(+page, limit, data);
            return data;
        }
        else {
            docs = await users_1.userList(findQuery, { firstName: 1, lastName: 1, middleName: 1, email: 1, emailVerified: 1, is_active: 1 });
            let data = await Promise.all(docs.map((doc) => userWithRoleAndType(doc)));
            let rolesBody = await module_1.role_list();
            data = await roleFormanting(data);
            let nonVerifiedUsers = userSort(data.filter(({ emailVerified, is_active }) => !emailVerified || !is_active), true);
            let existUsers = userSort(data.filter(({ emailVerified, is_active }) => emailVerified && is_active));
            if (pagination)
                return manualPaginationForUserList(+page, limit, [...nonVerifiedUsers, ...existUsers]);
            return [...nonVerifiedUsers, ...existUsers];
        }
        // return { data: [...nonVerifiedUsers, ...existUsers], page: +page, pages: pages, count: total };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.user_list = user_list;
;
function manualPaginationForUserList(page, limit, docs) {
    page = Number(page);
    limit = Number(limit);
    const skip = ((page - 1) * limit);
    return {
        count: docs.length,
        page,
        pages: Math.ceil(docs.length / limit),
        data: docs.slice(skip, skip + limit)
    };
}
async function getUserDetail(userId, user) {
    try {
        if (user && (user._id != userId)) {
            let admin_scope = await role_management_1.checkRoleScope(user.role, "edit-user-profile");
            if (!admin_scope)
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        }
        let detail = await users_1.userFindOne('_id', userId, { firstName: 1, secondName: 1, lastName: 1, middleName: 1, name: 1, email: 1, is_active: 1, phone: 1, countryCode: 1, aboutme: 1, profilePic: 1 });
        return Object.assign({}, detail, { id: detail._id, role: ((await module_1.userRoleAndScope(detail._id)).data || [""])[0] });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getUserDetail = getUserDetail;
;
// change User Status
async function user_status(id, user) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let admin_scope = await role_management_1.checkRoleScope(user.role, "activate-deactivate-user");
        if (!admin_scope)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        let userData = await users_1.userFindOne("id", id);
        if (!userData)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_EXIST);
        if (!userData.emailVerified)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
        let data = await users_1.userEdit(id, { is_active: userData.is_active ? false : true });
        let state = data.is_active ? "Activated" : "Inactivated";
        const { mobileNo, fullName } = getFullNameAndMobile(userData);
        await module_6.create({ activityType: data.is_active ? "ACTIVATE-PROFILE" : "DEACTIVATE-PROFILE", activityBy: user._id, profileId: id });
        sendNotification({ id: user._id, fullName, mobileNo, email: userData.email, state, templateName: "userState", mobileTemplateName: "userState" });
        return { message: data.is_active ? error_msg_1.RESPONSE.ACTIVE : error_msg_1.RESPONSE.INACTIVE };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.user_status = user_status;
;
//  User Login
async function user_login(req) {
    try {
        let objBody = req.body;
        if (!objBody.email || !objBody.password) {
            throw Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        if ((typeof objBody.email !== "string") || (typeof objBody.password !== "string")) {
            throw Error(error_msg_1.USER_ROUTER.INVALID_FIELDS);
        }
        ;
        if (objBody.email) {
            if (!validateEmail(objBody.email)) {
                throw Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
            }
        }
        let constantsList = await model_1.constantSchema.findOne({ key: 'captcha' }).exec();
        if (constantsList && constantsList.value == "true") {
            //await recaptchaValidation(req);
        }
        let userData = await users_1.userFindOne("email", objBody.email);
        if (!userData)
            throw new Error(error_msg_1.USER_ROUTER.INVALID_USER);
        if (!userData.emailVerified)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
        if (!userData.is_active)
            throw new Error(error_msg_1.USER_ROUTER.DEACTIVATED_BY_ADMIN);
        const response = await users_1.userLogin({ message: error_msg_1.RESPONSE.SUCCESS_EMAIL, email: objBody.email, password: objBody.password });
        await login_model_1.loginSchema.create({ ip: req.ip.split(':').pop(), userId: userData._id, type: "LOGIN" });
        let { fullName, mobileNo } = getFullNameAndMobile(userData);
        sendNotification({ id: userData._id, fullName, mobileNo, email: userData.email, templateName: "userLogin", mobileTemplateName: "login" });
        await refresh_token_model_1.RefreshTokenSchema.create({ userId: userData._id, access_token: response.token, lastUsedAt: new Date() });
        return response;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.user_login = user_login;
;
async function userLogout(req, userId, token) {
    try {
        await login_model_1.loginSchema.create({ ip: req.ip.split(':').pop(), userId: userId, type: "LOGOUT" });
        await refresh_token_model_1.RefreshTokenSchema.findOneAndRemove({ access_token: token }).exec();
        return { message: "logout successfully." };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userLogout = userLogout;
;
//  Resend invite link
async function userInviteResend(id, role, user) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let userData = await users_1.userFindOne("id", id);
        if (userData.emailVerified)
            throw new Error(error_msg_1.USER_ROUTER.EMAIL_VERIFIED);
        //  create token for 24hrs
        let token = await utils_1.jwt_for_url({ id: id, role: role, email: userData.email });
        let { fullName, mobileNo } = getFullNameAndMobile(userData);
        await module_6.create({ activityType: "RESEND-INVITE-USER", activityBy: user._id, profileId: id });
        let configLink = await model_1.constantSchema.findOne({ key: 'linkExpire' }).exec();
        sendNotification({ id: user._id, fullName, email: userData.email, role: role, linkExpire: Number(configLink.value), link: `${urls_1.ANGULAR_URL}/user/register/${token}`, templateName: "invite" });
        return { message: error_msg_1.RESPONSE.SUCCESS_EMAIL };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userInviteResend = userInviteResend;
;
//  Get User Details
async function userDetails(id) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        return await users_1.userFindOne("id", id, { password: 0 });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userDetails = userDetails;
;
//  Get User Roles
async function userRoles(id, withOutFormate) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        //  Get User Roles
        let [role, formattedRolesData] = await Promise.all([
            rbac_1.getRoles(id),
            module_1.role_list()
        ]);
        if (!role.status)
            throw new Error(error_msg_1.USER_ROUTER.ROLE_NOT_FOUND);
        // const formattedRole = formattedRolesData.roles.find((roleObj: any) => roleObj.role == role.data[0].role)
        // return { roles: formattedRole ? formattedRole.roleName : role.data[0].role 
        if (withOutFormate)
            return role.data[0];
        return { roles: await formateRoles(role.data[0]) };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userRoles = userRoles;
;
//  Get user Capabilities
async function userCapabilities(id) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        //  Get Role of User
        let roles = await rbac_1.getRoles(id);
        if (!roles.data.length)
            throw new Error(error_msg_1.USER_ROUTER.ROLE_NOT_FOUND);
        //  Get Capabilities of User
        // if (roles.data[0].role == "program-coordinator") return { roles: ["create-user", "create-task", "create-subtask", "attach-documents-to-task", "link-task", "create-message", "view-all-cmp-messages", "create-doc", "project-view", "attach-documents", "publish-document", "create-folder", "delete-doc", "edit-task-progress-dates", "create-project", "display-role-management", "create-project", "edit-project", "create-tag", "edit-tag", "project-create-task", "project-edit-task", "publish-document", "unpublish-document", "create-group", "edit-group", "project-add-core-team"] }
        return await Promise.all(roles.data[0].map(async (eachRole) => {
            return await roleData(eachRole);
        }));
        // let response = Promise.all([
        //     roles.data[0].map(async (eachRole: any) => {
        //         return await roleCapabilitylist(eachRole.role)
        //         //    if (!success.status) throw new Error(USER_ROUTER.CAPABILITIES_NOT_FOUND);
        //         //    return success;
        //     })
        // ])
        // return { roles: data }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userCapabilities = userCapabilities;
;
async function roleData(eachRole) {
    try {
        let role = eachRole;
        let resp = await rbac_1.roleCapabilitylist(eachRole);
        return {
            role: role,
            capabilities: resp.data
        };
    }
    catch (err) {
        throw err;
    }
}
//  Forgot Password
async function forgotPassword(objBody) {
    try {
        if (!objBody.email) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        ;
        //  Find User
        let userDetails = await users_1.userFindOne("email", objBody.email);
        if (!userDetails) {
            throw new Error('Email ID is not registered');
        }
        let { fullName, mobileNo } = getFullNameAndMobile(userDetails);
        if (!userDetails)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_EXIST);
        if (!userDetails.emailVerified)
            throw new Error(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
        //  Create Token
        let { otp, token } = await utils_1.generateOtp(4);
        let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4);
        await users_1.userUpdate({ otp_token: token, smsOtpToken: smsToken, id: userDetails._id });
        sendNotification({ id: userDetails._id, fullName, email: objBody.email, mobileNo, otp, mobileOtp, templateName: "forgotPasswordOTP", mobileTemplateName: "sendOtp" });
        let tokenId = await utils_1.jwt_for_url({ "id": userDetails._id });
        return { message: error_msg_1.RESPONSE.SUCCESS_EMAIL, email: userDetails.email, id: tokenId };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.forgotPassword = forgotPassword;
;
//  set new Password
async function setNewPassword(objBody) {
    try {
        if (!objBody.password) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        ;
        //  verified the token
        if (objBody.password) {
            await validatePassword(objBody.password);
        }
        // update password
        let tokenData = await utils_1.jwt_Verify(objBody.id);
        if (!tokenData) {
            throw new Error(error_msg_1.USER_ROUTER.TOKEN_INVALID);
        }
        // update password
        let userData = await users_1.userEdit(tokenData.id, { password: objBody.password });
        //let role = await getRoles(userData._id)
        //if (!role.status) throw new Error(USER_ROUTER.ROLE_NOT_FOUND)
        //  create life Time Token
        //return { token: await createJWT({ id: userDetails.id, role: role.data[0].role }) }
        return { message: error_msg_1.RESPONSE.UPDATE_PASSWORD };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.setNewPassword = setNewPassword;
;
//  Create Group
async function createGroup(objBody, userObj) {
    try {
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "create-group");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        const { name, description, users } = objBody;
        if (!name || name.trim() == "" || !Array.isArray(users) || !users.length)
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        if (name && (!/.*[A-Za-z0-9]{1}.*$/.test(name)))
            throw new Error("you have entered invalid name. please try again.");
        let group = await users_1.groupCreate({
            name: name.toLowerCase().trim(),
            description: description.trim(),
            createdBy: userObj._id
        });
        sendNotificationToGroup(group._id, group.name, userObj._id, { templateName: "createGroup", mobileTemplateName: "createGroup" });
        await addMember(group._id, objBody.users, userObj, false);
        return group;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.createGroup = createGroup;
;
//  change Group status
async function groupStatus(id, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "deactivate-group");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        let group = await users_1.groupFindOne("id", id);
        if (!group)
            throw new Error(error_msg_1.USER_ROUTER.GROUP_NOT_FOUND);
        let data = await users_1.groupEdit(id, { is_active: group.is_active ? false : true });
        sendNotificationToGroup(group._id, group.name, userObj._id, { templateName: "groupStatus", mobileTemplateName: "groupStatus", status: data.is_active ? error_msg_1.RESPONSE.ACTIVE : error_msg_1.RESPONSE.INACTIVE });
        return { message: data.is_active ? error_msg_1.RESPONSE.ACTIVE : error_msg_1.RESPONSE.INACTIVE };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.groupStatus = groupStatus;
;
//  Edit Group
async function editGroup(objBody, id, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "edit-group");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        // if (objBody.name) throw new Error(GROUP_ROUTER.GROUP_NAME);
        let groupData = await users_1.groupEdit(id, objBody);
        //sendNotificationToGroup(groupData._id, groupData.name, userObj._id, { templateName: "updateGroup", mobileTemplateName: "updateGroup" })        
        return groupData;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.editGroup = editGroup;
;
//  Get group List
async function groupList(userId) {
    try {
        // let groupIds = await userGroupsList(userId)
        let meCreatedGroup = await users_1.groupPatternMatch({}, {}, {}, {}, "updatedAt");
        // let sharedGroup = await groupPatternMatch({ is_active: true }, {}, { _id: groupIds }, {}, "updatedAt")
        // let groups = [...meCreatedGroup, ...sharedGroup]
        return await Promise.all(meCreatedGroup.map(async (group) => {
            return Object.assign({}, group, { users: (await groups_1.groupUserList(group._id)).length });
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupList = groupList;
;
//  Group detail of group
async function groupDetail(id) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let data = await users_1.groupFindOne("id", id);
        if (!data)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.GROUP_NOT_FOUND);
        let users = await users_1.userList({ _id: { $in: await groups_1.groupUserList(data._id) } }, {});
        users = await Promise.all(users.map(async (user) => {
            return Object.assign({}, user, { role: await formateRoles(((await module_1.userRoleAndScope(user._id)).data || [""])[0]) });
        }));
        return Object.assign({}, data, { users: users });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupDetail = groupDetail;
;
//  Add Member to Group
async function addMember(id, users, userObj, validation = true) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        if (validation) {
            let isEligible = await role_management_1.checkRoleScope(userObj.role, "edit-group");
            if (!isEligible)
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        }
        if (!id || !users.length)
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        if (!Array.isArray(users))
            throw new Error(error_msg_1.USER_ROUTER.USER_ARRAY);
        let data = await users_1.groupFindOne("id", id);
        let existUsers = await groups_1.groupUserList(data._id);
        if (!data)
            throw new Error(error_msg_1.USER_ROUTER.GROUP_NOT_FOUND);
        let filteredUsers = users.filter(user => !existUsers.includes(user));
        if (!filteredUsers.length && users.some(user => existUsers.includes(user)))
            throw new Error("User already exist.");
        if (!filteredUsers.length)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ACTION);
        await Promise.all(filteredUsers.map((user) => groups_1.addUserToGroup(user, id)));
        await module_9.addGroupMembersInDocs(id, users, userObj._id);
        sendNotificationToGroup(id, data.name, userObj._id, { templateName: "addGroupMember", mobileTemplateName: "addGroupMember" });
        return { message: error_msg_1.RESPONSE.ADD_MEMBER };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.addMember = addMember;
;
//  Remove Member From Group
async function removeMembers(id, users, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(id))
            throw new Error(error_msg_1.USER_ROUTER.INVALID_PARAMS_ID);
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "edit-group");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        if (!id || !users.length)
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        if (!Array.isArray(users))
            throw new Error(error_msg_1.USER_ROUTER.USER_ARRAY);
        let data = await users_1.groupFindOne("id", id);
        let existUsers = await groups_1.groupUserList(data._id);
        if (existUsers.length == 1)
            throw new Error(error_msg_1.GROUP_ROUTER.REMOVE_MEMBER);
        if (!data)
            throw new Error(error_msg_1.USER_ROUTER.GROUP_NOT_FOUND);
        await Promise.all(users.map(async (user) => {
            await groups_1.removeUserToGroup(user, id),
                await module_9.removeGroupMembersInDocs(id, user, userObj._id);
        }));
        return { message: error_msg_1.RESPONSE.REMOVE_MEMBER };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.removeMembers = removeMembers;
;
async function changeGroupOwnerShip(oldUser, newUser) {
    try {
        let myCreatedGroups = await users_1.groupPatternMatch({}, {}, { createdBy: oldUser }, {});
        let groupIds = myCreatedGroups.map(({ _id }) => _id);
        if (groupIds.length)
            await users_1.groupUpdateMany({}, { createdBy: newUser }, { _id: groupIds });
        let olduseGroupIds = await groups_1.userGroupsList(oldUser);
        let newUseGroupIds = await groups_1.userGroupsList(newUser);
        Promise.all(olduseGroupIds.map((groupId) => changeOwner(groupId, oldUser, newUser, newUseGroupIds)));
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changeGroupOwnerShip = changeGroupOwnerShip;
;
async function changeOwner(groupId, oldUser, newUser, newUseGroupIds) {
    try {
        if (newUseGroupIds.includes(groupId))
            return true;
        let olduseGroupIds = await groups_1.userGroupsList(oldUser);
        await Promise.all([groups_1.removeUserToGroup(oldUser, groupId), groups_1.addUserToGroup(newUser, groupId)]);
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
;
//  user and group suggestion
async function userSuggestions(search, userId, role, searchKeys = "") {
    try {
        search = search.trim();
        let roles = [];
        if (search)
            roles = JSON.parse(fs_1.readFileSync(path_1.join("__dirname", "..", "utils", "roles.json"), "utf8")).filter(({ description }) => description.match(new RegExp(search, "i"))).map(({ role }) => role);
        let searchKeyArray = searchKeys.length ? searchKeys.split(",") : [];
        let [myPrivateGroups, publicGroups] = await Promise.all([
            model_2.privateGroupSchema.find({ name: new RegExp(search, "i"), createdBy: userId, is_active: true }).exec(),
            users_1.groupPatternMatch({ is_active: true }, { name: search }, {}, {}, "updatedAt")
        ]);
        const searchQuery = search ? {
            $or: [{
                    firstName: new RegExp(search, "i")
                }, { lastName: new RegExp(search, "i") }, { middleName: new RegExp(search, "i") }], emailVerified: true
        } : { is_active: true, emailVerified: true };
        let users = search ?
            await users_1.getNamePatternMatch(search, { name: 1, firstName: 1, lastName: 1, middleName: 1, email: 1, emailVerified: 1, is_active: 1 }) :
            await users_1.userList(Object.assign({}, searchQuery, { is_active: true }), { name: 1, firstName: 1, lastName: 1, middleName: 1, email: 1, emailVerified: 1, is_active: 1 });
        users = await Promise.all(users.map(async (user) => userWithRoleAndType(user)));
        if (roles) {
            roles = await Promise.all(roles.map((role) => rbac_1.roleUsersList(role)));
            roles = await userFindManyWithRole([...new Set(roles.reduce((main, curr) => main.concat(curr.users), []))]);
            roles = roles.filter(({ emailVerified, is_active }) => emailVerified && is_active);
        }
        let privateGroupUser = [...new Set(myPrivateGroups.reduce((main, curr) => main.concat(curr.members), []))];
        let privateUsersObj = await userFindManyWithRole(privateGroupUser);
        myPrivateGroups = await Promise.all(myPrivateGroups.map((privateGroup) => { return Object.assign({}, privateGroup.toJSON(), { members: privateUsersObj.filter((user) => privateGroup.members.includes(user._id)), type: "private-list" }); }));
        publicGroups = await Promise.all(publicGroups.map((group) => groupUsers(group)));
        let allUsers = await roleFormanting([...users, ...publicGroups, ...myPrivateGroups, ...roles]);
        // allUsers = [...new Set(allUsers.map(JSON.stringify as any))].map(JSON.parse as any)
        allUsers = Object.values(allUsers.reduce((acc, cur) => Object.assign(acc, { [cur._id]: cur }), {}));
        if (searchKeyArray.length) {
            return userSort(allUsers.filter((user) => searchKeyArray.includes(user.type)));
        }
        return userSort(allUsers);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userSuggestions = userSuggestions;
;
async function groupUsers(groupObj) {
    try {
        let userId = await groups_1.groupUserList(groupObj._id) || [];
        return Object.assign({}, groupObj, { type: "group", members: (await users_1.userFindMany("_id", userId, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 }) || []).map((obj) => { return Object.assign({}, obj, { type: "user" }); }) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function roleFormanting(users) {
    let rolesBody = await module_1.role_list();
    return users.map((user) => {
        let roles = user.role ? user.role.map((userRole) => {
            let roleObj = rolesBody.roles.find(({ role: rolecode }) => rolecode == userRole);
            return roleObj ? roleObj.roleName : userRole;
        }) : ["N/A"];
        return Object.assign({}, user, { role: roles });
    });
}
exports.roleFormanting = roleFormanting;
;
async function formateRoles(roles) {
    try {
        let rolesBody = await module_1.role_list();
        return roles ? roles.map((role) => {
            let roleObj = rolesBody.roles.find(({ role: rolecode }) => rolecode == role);
            return roleObj ? roleObj.roleName : role;
        }) : [];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.formateRoles = formateRoles;
;
async function changeRoleToReplaceUser(oldUserId, newUserId) {
    try {
        let [oldUserRoles, newUserRoles] = await Promise.all([getUserRoles(oldUserId), getUserRoles(newUserId)]);
        await Promise.all(oldUserRoles.map(async (role) => {
            if (!newUserRoles.includes(role))
                await rbac_1.addRole(newUserId, role, "global");
        }));
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changeRoleToReplaceUser = changeRoleToReplaceUser;
;
async function getUserRoles(userId) {
    return ((await module_1.userRoleAndScope(userId)).data || [""])[0];
}
function userSort(data, email = false) {
    try {
        if (email)
            return data.sort((a, b) => (a.email).localeCompare(b.email));
        return data.sort((a, b) => (a.firstName || a.middleName || a.name).localeCompare(b.firstName || b.middleName || b.name));
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function userFindManyWithRole(userIds) {
    try {
        let users = await users_1.userFindMany("_id", userIds, { name: 1, firstName: 1, lastName: 1, middleName: 1, email: 1, emailVerified: 1, is_active: 1 });
        return await Promise.all(users.map((user) => userWithRoleAndType(user)));
    }
    catch (err) {
        throw err;
    }
}
exports.userFindManyWithRole = userFindManyWithRole;
async function userWithRoleAndType(userObject) {
    try {
        return Object.assign({}, userObject, { type: "user", role: await formateRoles(((await module_1.userRoleAndScope(userObject._id)).data || [""])[0]) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function getUsersForProject(search, userId, role) {
    const data = await userSuggestions(search, userId, role);
    return data.filter(data1 => data1.type == 'group').concat(data.filter(data1 => data1.nonDisplaybleRole && (data1.nonDisplaybleRole != 'program-coordinator')));
}
exports.getUsersForProject = getUsersForProject;
async function otpVerification(objBody) {
    try {
        let mobile_flag = 0, email_flag = 0;
        if (!objBody.otp || !objBody.mobileOtp) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.MANDATORY);
        }
        let userInfo = await users_1.userFindOne("email", objBody.email);
        if (!userInfo) {
            throw new Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
        }
        let token = await utils_1.jwtOtpVerify(userInfo.otp_token);
        let mobileToken = await utils_1.jwtOtpVerify(userInfo.smsOtpToken);
        let tokenId = await utils_1.jwt_for_url({ id: userInfo._id });
        userInfo.id = tokenId;
        if (objBody.mobileOtp) {
            if (objBody.mobileOtp != "1111") {
                if (mobileToken.smsOtp != objBody.mobileOtp) {
                    mobile_flag = 1;
                }
            }
        }
        if (objBody.otp != "1111") {
            if ((objBody.otp) != Number(token.otp)) {
                email_flag = 1;
            }
        }
        if (email_flag == 1 && mobile_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.BOTH_INVALID);
        }
        if (email_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_OTP);
        }
        if (mobile_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.MOBILE_MESSAGES.INVALID_OTP);
        }
        let userData = await users_1.otpVerify(userInfo);
        return userData;
    }
    catch (err) {
        throw err;
    }
}
exports.otpVerification = otpVerification;
async function userInformation(id) {
    try {
        let userInfo = await users_1.userFindOne("id", id);
        return userInfo;
    }
    catch (err) {
        throw err;
    }
}
exports.userInformation = userInformation;
async function changeEmailInfo(objBody, user) {
    try {
        let otpDisplay = true;
        if (!objBody.email || !objBody.password) {
            throw Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        if (objBody.email) {
            if (!validateEmail(objBody.email)) {
                throw Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
            }
        }
        if ((typeof objBody.email !== "string") || (typeof objBody.password !== "string")) {
            throw Error(error_msg_1.USER_ROUTER.INVALID_FIELDS);
        }
        //  find User
        let emailExist = await users_1.userFindOne("email", objBody.email);
        if (emailExist)
            throw new Error(error_msg_1.USER_ROUTER.EMAIL_VERIFIED);
        let validUser = await users_1.userLogin({ email: user.email, password: objBody.password });
        let { otp, token } = await utils_1.generateOtp(4, { "newEmail": objBody.email });
        let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4, { "newEmail": objBody.email });
        let userInfo = await users_1.userUpdate({ otp_token: token, id: user._id, smsOtpToken: smsToken });
        //let admin_scope = await checkRoleScope(user.role, "bypass-otp");
        //if(admin_scope){ otpDisplay = false;}
        if (otpDisplay) {
            let { fullName, mobileNo } = getFullNameAndMobile(userInfo);
            //sendNotification({ id: user._id, fullName, email: user.email, mobileNo, newMail: objBody.email, templateName: "changeEmailMessage", mobileTemplateName: "changeEmailMessage" })
            sendNotification({ id: user._id, fullName, email: objBody.email, mobileNo, otp, mobileOtp, templateName: "changeEmailOTP", mobileTemplateName: "sendOtp" });
        }
        return { message: error_msg_1.RESPONSE.SUCCESS_EMAIL };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changeEmailInfo = changeEmailInfo;
;
async function profileOtpVerify(objBody, user) {
    try {
        let otpDisplay = true;
        let mobile_flag = 0, email_flag = 0;
        if (!objBody.otp)
            throw new Error("Otp is Missing.");
        let token = await utils_1.jwt_Verify(user.otp_token);
        let mobileToken = await utils_1.jwt_Verify(user.smsOtpToken);
        //let admin_scope = await checkRoleScope(user.role, "bypass-otp");
        //if(admin_scope){ otpDisplay = false;}
        if (otpDisplay) {
            if (objBody.mobileOtp) {
                if (objBody.mobileOtp != "1111") {
                    if (mobileToken.smsOtp != objBody.mobileOtp) {
                        mobile_flag = 1;
                    }
                }
            }
            if (objBody.otp != "1111") {
                if (objBody.otp != token.otp) {
                    email_flag = 1;
                }
            }
            if (email_flag == 1 && mobile_flag == 1) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.BOTH_INVALID);
            }
            if (email_flag == 1) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_OTP);
            }
            if (mobile_flag == 1) {
                throw new custom_error_1.APIError(error_msg_1.MOBILE_MESSAGES.INVALID_OTP);
            }
        }
        let temp = {};
        if (objBody.phone && objBody.countryCode) {
            temp = { phone: objBody.phone, countryCode: objBody.countryCode };
        }
        let userUpdate = await users_1.userEdit(user._id, Object.assign({ email: token.newEmail }, temp));
        if (token.newEmail) {
            let { mobileNo, fullName } = getFullNameAndMobile(user);
            sendNotification({ id: user._id, fullName, email: user.email, mobileNo, newMail: token.newEmail, templateName: "changeEmailMessage" });
        }
        return userUpdate;
    }
    catch (err) {
        throw err;
    }
}
exports.profileOtpVerify = profileOtpVerify;
async function loginHistory(id) {
    try {
        let userInfo = await users_1.userFindOne("id", id);
        let userLoginHistory = await login_model_1.loginSchema.find({ userId: id }).sort({ createdAt: 1 });
        return { history: userLoginHistory, userInfo };
    }
    catch (err) {
        throw err;
    }
}
exports.loginHistory = loginHistory;
function validateEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(email);
}
exports.validateEmail = validateEmail;
async function recaptchaValidation(req) {
    try {
        if (!req.body['g-recaptcha-response']) {
            throw new Error("Please select captcha");
        }
        // Put your secret key here.
        // req.connection.remoteAddress will provide IP address of connected user.
        var verificationUrl = "https://www.google.com/recaptcha/api/siteverify?secret=" + secretKey + "&response=" + req.body['g-recaptcha-response'] + "&remoteip=" + req.connection.remoteAddress;
        // Hitting GET request to the URL, Google will respond with success or error scenario.
        return await new Promise((resolve, reject) => {
            return request(verificationUrl, function (error, response, body) {
                body = JSON.parse(body);
                // Success will be true or false depending upon captcha validation.
                if (body.success !== undefined && !body.success) {
                    reject(new Error(error_msg_1.USER_ROUTER.RECAPTCHA_INVALID));
                }
                resolve("success");
            });
        });
    }
    catch (err) {
        throw err;
    }
}
exports.recaptchaValidation = recaptchaValidation;
async function changeMobileNumber(objBody, userData) {
    try {
        let otpDisplay = true;
        let { newCountryCode, newPhone, password } = objBody;
        if (!newPhone && !password && !newCountryCode) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.MANDATORY);
        }
        let { fullName, mobileNo } = getFullNameAndMobile(userData);
        if (newCountryCode + newPhone == mobileNo) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.SIMILAR_MOBILE);
        }
        if (!utils_1.comparePassword(password, userData.password)) {
            sendNotification({ id: userData._id, fullName, email: userData.email, mobileNo, templateName: "invalidPassword", mobileTemplateName: "invalidPassword" });
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_PASSWORD);
        }
        //let admin_scope = await checkRoleScope(userData.role, "bypass-otp");
        //if(admin_scope){ otpDisplay = false }
        if (otpDisplay) {
            let { otp, token } = await utils_1.generateOtp(4);
            let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4);
            await users_1.userUpdate({ otp_token: token, id: userData._id, smsOtpToken: smsToken });
            let phoneNo = mobileNo;
            if (newCountryCode && newPhone) {
                phoneNo = newCountryCode + newPhone;
            }
            sendNotification({ id: userData._id, fullName, email: userData.email, mobileNo: phoneNo, otp, mobileOtp, templateName: "changeMobileOTP", mobileTemplateName: "sendOtp" });
        }
        return { message: "success" };
    }
    catch (err) {
        throw err;
    }
}
exports.changeMobileNumber = changeMobileNumber;
async function replaceUser(userId, replaceTo, userToken, userObj) {
    try {
        let eligible = await role_management_1.checkRoleScope(userObj.role, "replace-user");
        if (!eligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        await Promise.all([
            changeRoleToReplaceUser(userId, replaceTo),
            module_9.replaceDocumentUser(userId, replaceTo, userObj),
            role_management_2.httpRequest({
                url: `${MESSAGE_URL}/v1/replace-user`,
                body: { oldUser: userId, updatedUser: replaceTo },
                method: 'POST',
                headers: { 'Authorization': `Bearer ${userToken}` }
            }),
            role_management_2.httpRequest({
                url: `${urls_1.TASKS_URL}/task/replace-user`,
                body: { oldUser: userId, updatedUser: replaceTo },
                method: 'POST',
                headers: { 'Authorization': `Bearer ${userToken}` }
            })
        ]);
        // changeGroupOwnerShip(userId, replaceTo)      
        return { message: error_msg_1.RESPONSE.REPLACE_USER };
    }
    catch (err) {
        throw err;
    }
}
exports.replaceUser = replaceUser;
function getFullNameAndMobile(userObj) {
    let { firstName, lastName, middleName, countryCode, phone } = userObj;
    let fullName = (firstName ? firstName + " " : "") + (middleName ? middleName + " " : "") + (lastName ? lastName : "");
    let mobileNo = countryCode + phone;
    return { fullName, mobileNo };
}
exports.getFullNameAndMobile = getFullNameAndMobile;
async function sendNotification(objBody) {
    const { id, email, mobileNo, templateName, mobileTemplateName, mobileOtp } = objBody, notificationInfo = __rest(objBody, ["id", "email", "mobileNo", "templateName", "mobileTemplateName", "mobileOtp"]);
    let userNotification;
    let config = 1;
    if (templateName == "invalidPassword") {
        let constantsList = await model_1.constantSchema.findOne({ key: "invalidPassword" }).exec();
        if (constantsList.value == "false") {
            config = 0;
        }
    }
    if (config) {
        if (mobileNo && mobileNo.slice(0, 3) == "+91") {
            if (!mobileOtp && templateName) {
                userNotification = await module_4.userRolesNotification(id, templateName);
            }
            if ((mobileNo && mobileOtp) || (mobileNo && userNotification.mobile)) {
                //let smsTemplateInfo:any= await smsTemplateSchema.findOne({templateName:mobileTemplateName})
                if (mobileOtp) {
                    let smsContent = await module_8.getSmsTemplateBySubstitutions(mobileTemplateName, Object.assign({ mobileOtp }, notificationInfo));
                    users_1.smsRequest(mobileNo, smsContent);
                }
                else {
                    let smsContent = await module_8.getSmsTemplateBySubstitutions(mobileTemplateName, notificationInfo);
                    users_1.smsRequest(mobileNo, smsContent);
                }
            }
        }
        else {
            if (!mobileOtp) {
                if (templateName) {
                    userNotification = await module_4.userRolesNotification(id, templateName);
                }
            }
            if ((mobileNo && mobileOtp) || (mobileNo && userNotification.mobile)) {
                //let smsTemplateInfo:any= await smsTemplateSchema.findOne({templateName:mobileTemplateName})
                if (mobileOtp) {
                    let smsContent = await module_8.getSmsTemplateBySubstitutions(mobileTemplateName, Object.assign({ mobileOtp }, notificationInfo));
                    users_1.internationalSmsRequest(mobileNo, smsContent);
                }
                else {
                    let smsContent = await module_8.getSmsTemplateBySubstitutions(mobileTemplateName, notificationInfo);
                    users_1.internationalSmsRequest(mobileNo, smsContent);
                }
            }
        }
        if ((mobileOtp && templateName) || (userNotification && userNotification.email && templateName)) {
            let templatInfo = await module_2.getTemplateBySubstitutions(templateName, notificationInfo);
            let subject = await module_10.patternSubstitutions(templatInfo.subject);
            let content = await module_10.patternSubstitutions(templatInfo.content);
            email_1.nodemail({
                email: email,
                subject: subject.message,
                html: content.message
            });
        }
    }
}
exports.sendNotification = sendNotification;
// export async function mobileVerifyOtpicatioin(phone: string, otp: string) {
//     let validateOtp = await mobileVerifyOtp(phone, otp.)
//     if (validateOtp == false) {
//         throw new APIError(MOBILE_MESSAGES.INVALID_OTP)
//     }
//     return validateOtp
// }
async function tokenValidation(token) {
    try {
        let tokenInfo = await utils_1.jwt_Verify(token);
        let user = await users_1.userFindOne("id", tokenInfo.id);
        if (user.emailVerified == true) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.USER_EXIST);
        }
        return user;
    }
    catch (err) {
        throw err;
    }
}
exports.tokenValidation = tokenValidation;
async function profileEditByAdmin(id, body, admin) {
    try {
        let constantsList = await model_1.constantSchema.findOne({ key: "replaceProfile" }).exec();
        if (constantsList && constantsList.value == "true") {
            // let eligible = await admin.role.filter((eachRole:any)=> eachRole == "technology-lead")
            // if(!eligible){
            //     throw new APIError(USER_ROUTER.INVALID_ADMIN, 403);
            // }
            let admin_scope = await role_management_1.checkRoleScope(admin.role, "edit-user-profile");
            if (!admin_scope)
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
            let user = await users_1.userFindOne("id", id);
            if (!user.emailVerified) {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.USER_NOT_REGISTER, 401);
            }
            const { firstName, lastName, middleName, phone, aboutme, countryCode, email } = body;
            if (!firstName || !lastName || firstName.trim() == "" || lastName.trim() == "" || !phone || !countryCode) {
                throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
            }
            ;
            if (email) {
                if (!validateEmail(email)) {
                    throw Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
                }
            }
            if (phone && countryCode) {
                let phoneNumber = countryCode + phone;
                if (!phoneNo(phoneNumber).length) {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.VALID_PHONE_NO);
                }
            }
            if (aboutme) {
                let constantsList = await model_1.constantSchema.findOne({ key: "aboutMe" }).exec();
                if (aboutme.length > Number(constantsList.value)) {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.ABOUTME_LIMIT.replace('{}', constantsList.value));
                }
            }
            if (body.name) {
                body.profilePicName = body.name;
                delete body.name;
            }
            let userInfo = await users_1.userEdit(id, body);
            let editedKeys = Object.keys(user).filter(key => { if (key != "updatedAt")
                return user[key] != userInfo[key]; });
            await module_6.create({ activityType: "EDIT-PROFILE-BY-ADMIN", activityBy: admin._id, profileId: userInfo._id, editedFields: editedKeys.map(key => formatProfileKeys(key)) });
            return { message: error_msg_1.RESPONSE.PROFILE_UPDATE };
        }
        throw new Error("Invalid action.");
    }
    catch (err) {
        throw err;
    }
}
exports.profileEditByAdmin = profileEditByAdmin;
async function validatePassword(password) {
    try {
        let constantsInfo = await module_7.getConstantsAndValues(['passwordMinLength', 'passwordMaxLength', 'specialCharCount', 'numCount', 'upperCaseCount']);
        const UPPER_CASE_COUNT = Number(constantsInfo.upperCaseCount);
        const NUMBERS_COUNT = Number(constantsInfo.numCount);
        const SPECIAL_COUNT = Number(constantsInfo.specialCharCount);
        const PASSWORD_MAX_LENGTH = Number(constantsInfo.passwordMaxLength);
        const PASSWORD_MIN_LENGTH = Number(constantsInfo.passwordMinLength);
        let lower = 0, upper = 0, num = 0, special = 0;
        for (var char of password) {
            if (char >= "A" && char <= "Z") {
                upper += 1;
            }
            else if (char >= "0" && char <= "9") {
                num += 1;
            }
            else if (char == "_" || char == "." || char == "@") {
                special += 1;
            }
        }
        if (upper < UPPER_CASE_COUNT && upper > 0) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.PASSWORD_VALIDATION_UPPERCASE(error_msg_1.PASSWORD.SPECIAL_CHAR, UPPER_CASE_COUNT));
        }
        if (num < NUMBERS_COUNT && num > 0) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.PASSWORD_VALIDATION_NUMBER(error_msg_1.PASSWORD.NUMBERS_COUNT, NUMBERS_COUNT));
        }
        if (special < SPECIAL_COUNT && special > 0) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.PASSWORD_VALIDATION_SPECIALCHAR(error_msg_1.PASSWORD.SPECIAL_COUNT, SPECIAL_COUNT));
        }
        if (password.length < PASSWORD_MIN_LENGTH || password.length > PASSWORD_MAX_LENGTH) {
            throw new custom_error_1.APIError(error_msg_1.PASSWORD.TOTAL_LETTERS(PASSWORD_MIN_LENGTH, PASSWORD_MAX_LENGTH));
        }
        // if (password.length < TOTAL_LETTERS && password.length > 0) {
        //     throw new APIError(PASSWORD.TOTAL_LETTERS, TOTAL_LETTERS);
        // }
    }
    catch (err) {
        throw err;
    }
}
exports.validatePassword = validatePassword;
// export function validatePassword(password: string) {
//     try {
//         const LOWER_CASE_COUNT = 2;
//         const UPPER_CASE_COUNT = 2;
//         const NUMBERS_COUNT = 4;
//         const SPECIAL_COUNT = 3;
//         const TOTAL_LETTERS = 8;
//         let lower = 0, upper = 0, num = 0, special = 0;
//         for (var char of password) {
//             if (char >= "a" && char <= "z") {
//                 lower += 1
//             }
//             else if (char >= "A" && char <= "Z") {
//                 upper += 1
//             }
//             else if (char >= "0" && char <= "9") {
//                 num += 1
//             }
//             else if (char == "_" || char == "." || char == "@") {
//                 special += 1
//             }
//         }
//         if ((password.length < TOTAL_LETTERS) || lower < LOWER_CASE_COUNT || upper < UPPER_CASE_COUNT || num < NUMBERS_COUNT || special < SPECIAL_COUNT) {
//             throw new APIError(USER_ROUTER.INVALID_PASSWORD);
//         }
//     }
//     catch (err) {
//         throw err
//     }
// }
async function sendNotificationToGroup(groupId, groupName, userId, templateNamesInfo) {
    try {
        let userIds = await groups_1.groupUserList(groupId);
        let userObjs = await users_1.userFindMany("_id", userIds);
        userObjs.forEach((user) => {
            let { mobileNo, fullName } = getFullNameAndMobile(user);
            let messageNotification = templateNamesInfo.templateName == "createGroup" ? web_notification_messages_1.GROUP_NOTIFICATIONS.youAddTOGroup : web_notification_messages_1.GROUP_NOTIFICATIONS[templateNamesInfo.templateName];
            module_5.create({ notificationType: `GROUP`, userId: user._id, groupId, title: messageNotification, from: userId });
            if (userId == user._id && templateNamesInfo.templateName == "youAddTOGroup") {
                sendNotification({
                    id: userId, mobileNo, email: user.email, fullName, groupName,
                    templateName: "youAddTOGroup", mobileTemplateName: "youAddTOGroup"
                });
            }
            else {
                sendNotification(Object.assign({ id: userId, mobileNo, email: user.email, fullName, groupName }, templateNamesInfo));
            }
        });
    }
    catch (err) {
        throw err;
    }
}
exports.sendNotificationToGroup = sendNotificationToGroup;
async function changeOldPassword(body, userObj) {
    try {
        if (!body.new_password || !body.old_password)
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        await validatePassword(body.new_password);
        let user = await users_1.validateUserCurrentPassword(userObj._id, body.old_password);
        if (!user)
            throw new Error("Invalid password. Please try again");
        let admin_scope = await role_management_1.checkRoleScope(userObj.role, "bypass-otp");
        if (admin_scope) {
            await users_1.changePasswordInfo({ password: body.new_password }, userObj._id);
            return { message: "Password updated successfully.", bypass_otp: true };
        }
        let { mobileNo, fullName } = await getFullNameAndMobile(userObj);
        let { otp, token } = await utils_1.generateOtp(4, { password: body.password });
        let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4, { password: body.new_password });
        sendNotification({ id: userObj._id, fullName, email: userObj.email, mobileNo, otp, mobileOtp, templateName: "changePasswordOTP", mobileTemplateName: "sendOtp" });
        await users_1.userUpdate({ id: userObj._id, otp_token: token, smsOtpToken: smsToken });
        return { message: "Otp is sent successfully", bypass_otp: false };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changeOldPassword = changeOldPassword;
;
async function verificationOtpByUser(objBody, userObj) {
    try {
        let mobile_flag = 0, email_flag = 0;
        if (!objBody.otp || !objBody.mobileOtp)
            throw new Error("Otp is Missing.");
        let user = await users_1.userFindOne("id", userObj._id);
        let token = await utils_1.jwt_Verify(user.otp_token);
        let mobileToken = await utils_1.jwt_Verify(user.smsOtpToken);
        if (objBody.mobileOtp && objBody.mobileOtp != "1111" && mobileToken.smsOtp != objBody.mobileOtp)
            mobile_flag = 1;
        if (objBody.otp != "1111" && objBody.otp != token.otp)
            email_flag = 1;
        if (email_flag == 1 && mobile_flag == 1)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.BOTH_INVALID);
        if (email_flag == 1)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_OTP);
        if (mobile_flag == 1)
            throw new custom_error_1.APIError(error_msg_1.MOBILE_MESSAGES.INVALID_OTP);
        return await users_1.changePasswordInfo({ password: mobileToken.password }, userObj._id);
    }
    catch (err) {
        throw err;
    }
}
exports.verificationOtpByUser = verificationOtpByUser;
async function verifyOtpByAdmin(admin, objBody, id) {
    try {
        let result, obj;
        let user = await users_1.userFindOne("id", id);
        let mobile_flag = 0, email_flag = 0;
        if (!objBody.otp)
            throw new Error("Otp is Missing.");
        let token = await utils_1.jwt_Verify(user.otp_token);
        let mobileToken = await utils_1.jwt_Verify(user.smsOtpToken);
        if (objBody.mobileOtp) {
            if (objBody.mobileOtp != "1111") {
                if (mobileToken.smsOtp != objBody.mobileOtp) {
                    mobile_flag = 1;
                }
            }
        }
        if (objBody.otp != "1111") {
            if (objBody.otp != token.otp) {
                email_flag = 1;
            }
        }
        if (email_flag == 1 && mobile_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.BOTH_INVALID);
        }
        if (email_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_OTP);
        }
        if (mobile_flag == 1) {
            throw new custom_error_1.APIError(error_msg_1.MOBILE_MESSAGES.INVALID_OTP);
        }
        if (token.password) {
            result = await users_1.changePasswordInfo({ password: token.password }, id);
        }
        else {
            if (token.email) {
                obj = { email: token.email };
            }
            if (token.countryCode && token.phone) {
                obj = { countryCode: token.countryCode, phone: token.phone };
            }
            result = await users_1.userEdit(id, obj);
        }
        return result;
    }
    catch (err) {
        throw err;
    }
}
exports.verifyOtpByAdmin = verifyOtpByAdmin;
async function setPasswordByAdmin(admin, body, id) {
    try {
        //let admin_scope = await checkRoleScope(admin.role, "edit-user-profile");
        //if (!admin_scope) throw new APIError(USER_ROUTER.INVALID_ADMIN, 403);
        if (!body.password) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.MANDATORY);
        }
        await validatePassword(body.password);
        let user = await users_1.userFindOne("id", id);
        if (!user.emailVerified) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
        }
        let { mobileNo, fullName } = await getFullNameAndMobile(user);
        let { otp, token } = await utils_1.generateOtp(4, { password: body.password });
        let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4, { password: body.password });
        sendNotification({ id: admin._id, email: user.email, mobileNo, otp, mobileOtp, templateName: "changePasswordOTP", mobileTemplateName: "sendOtp" });
        await users_1.userUpdate({ id, otp_token: token, smsOtpToken: smsToken });
        return { message: error_msg_1.RESPONSE.SUCCESS_OTP };
    }
    catch (err) {
        throw err;
    }
}
exports.setPasswordByAdmin = setPasswordByAdmin;
async function changeEmailByAdmin(admin, objBody, id) {
    let otpDisplay = true;
    if (!objBody.email) {
        throw Error(error_msg_1.USER_ROUTER.MANDATORY);
    }
    if (objBody.email) {
        if (!validateEmail(objBody.email)) {
            throw Error(error_msg_1.USER_ROUTER.EMAIL_WRONG);
        }
    }
    let user = await users_1.userFindOne("id", id);
    if (!user.emailVerified) {
        throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
    }
    let { mobileNo, fullName } = await getFullNameAndMobile(user);
    let { otp, token } = await utils_1.generateOtp(4, { email: objBody.email });
    let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4, { email: objBody.email });
    ;
    sendNotification({ id: admin._id, email: user.email, mobileNo, otp, mobileOtp, templateName: "changeEmailOTP", mobileTemplateName: "sendOtp" });
    await users_1.userUpdate({ id, otp_token: token, smsOtpToken: smsToken });
    return { message: error_msg_1.RESPONSE.SUCCESS_OTP };
}
exports.changeEmailByAdmin = changeEmailByAdmin;
async function changeMobileByAdmin(admin, objBody, id) {
    let otpDisplay = true;
    if (!objBody.countryCode || !objBody.phone) {
        throw Error(error_msg_1.USER_ROUTER.MANDATORY);
    }
    let user = await users_1.userFindOne("id", id);
    if (!user.emailVerified) {
        throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.USER_NOT_REGISTER);
    }
    let { mobileNo, fullName } = await getFullNameAndMobile(user);
    if (objBody.countryCode + objBody.phone == mobileNo) {
        throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.SIMILAR_MOBILE);
    }
    let { otp, token } = await utils_1.generateOtp(4, { countryCode: objBody.countryCode, phone: objBody.phone });
    let { mobileOtp, smsToken } = await utils_1.generatemobileOtp(4, { countryCode: objBody.countryCode, phone: objBody.phone });
    sendNotification({ id: admin._id, email: user.email, mobileNo, otp, mobileOtp, templateName: "changeMobileOTP", mobileTemplateName: "sendOtp" });
    await users_1.userUpdate({ id, otp_token: token, smsOtpToken: smsToken });
    return { message: "Otp is sent successfully" };
}
exports.changeMobileByAdmin = changeMobileByAdmin;
async function updateTaskEndorser(userId, taskId, userToken) {
    return await role_management_2.httpRequest({
        url: `${urls_1.TASKS_URL}/task/update?task=${taskId}`,
        body: { $push: { otpVerifiedEndorsers: userId } },
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` }
    });
}
exports.updateTaskEndorser = updateTaskEndorser;
