"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const utils_1 = require("../utils/utils");
const fs_1 = require("fs");
const path_1 = require("path");
const module_2 = require("../documents/module");
const http_1 = require("http");
const https_1 = require("https");
const urls_1 = require("../utils/urls");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_3 = require("../role/module");
const error_msg_1 = require("../utils/error_msg");
const router = express_1.Router();
const multer = require("multer");
const model_1 = require("../site-constants/model");
const role_management_1 = require("../utils/role_management");
const requestIp = require("request-ip");
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        console.log("Dest");
        cb(null, (__dirname + '/uploads/'));
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + file.originalname);
    }
});
const upload = multer({ storage });
const ipMiddleware = function (req, res, next) {
    const ip = requestIp.getClientIp(req);
    next();
};
//  Invite User
router.post('/create', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.inviteUser(req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post(`/bulk-invite`, utils_1.authenticate, upload.single('upfile'), async (req, res, next) => {
    try {
        res.status(200).send(await module_1.bulkInvite(req.file.path, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
// Register User
router.post("/register/:token", async (req, res, next) => {
    try {
        const payload = await module_2.uploadToFileService(req);
        // req.body.profilePic = JSON.parse(imageObj).id
        res.status(200).send(await module_1.RegisterUser(JSON.parse(payload), req.params.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Resend invite link
router.get('/invite/resend/:role/:id', utils_1.authenticate, async (req, res, next) => {
    try {
        const { role, id } = req.params;
        res.status(200).send(await module_1.userInviteResend(id, role, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  user list
router.get('/list', utils_1.authenticate, async (req, res, next) => {
    try {
        req.query.page = req.query.page || 1;
        req.query.limit = 50;
        res.status(200).send(await module_1.user_list(req.query, res.locals.user._id, req.query.search, req.query.page, req.query.limit, req.query.pagination));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get(`/detail/:id`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getUserDetail(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Edit User
router.post('/edit/:id', utils_1.authenticate, async (req, res, next) => {
    try {
        //const payload: any = await uploadToFileService(req)
        let payload;
        // if(req.file){
        //     payload = await uploadToFileService(req)
        // } else {
        //     payload = JSON.stringify(req.body)
        // }
        const contentType = req.get('content-type');
        if (contentType.includes('multipart/form-data')) {
            payload = await module_2.uploadToFileService(req);
        }
        if (contentType.includes('application/json')) {
            payload = JSON.stringify(req.body);
        }
        //req.body.profilePic = JSON.parse(imageObj).id
        res.status(http_status_codes_1.OK).send(await module_1.edit_user(req.params.id, JSON.parse(payload), res.locals.user, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
    ;
});
//  change status user
router.put('/status/:id', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.user_status(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  login user
router.post('/email/login', ipMiddleware, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.user_login(req));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/email/logout", ipMiddleware, async (req, res, next) => {
    try {
        if (!req.query.userId)
            throw new Error("required userId");
        res.status(200).send(await module_1.userLogout(req, req.query.userId));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get(`/getImage/:userId`, async (request, response, next) => {
    try {
        const userDetail = await module_1.getUserDetail(request.params.userId);
        const req = urls_1.FILES_SERVER_BASE.startsWith("https") ?
            https_1.get(`${urls_1.FILES_SERVER_BASE}/files/${userDetail.profilePic}`, (res) => {
                response.setHeader('Content-disposition', 'inline');
                response.setHeader('Content-type', res.headers['content-type']);
                res.pipe(response);
            }) : http_1.get(`${urls_1.FILES_SERVER_BASE}/files/${userDetail.profilePic}`, (res) => {
            response.setHeader('Content-disposition', 'inline');
            response.setHeader('Content-type', res.headers['content-type']);
            res.pipe(response);
        });
        req.on('error', (e) => {
            next(e);
        });
        req.end();
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
// Get user Details
router.get("/me", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userDetails(res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
// Get user roles
router.get("/me/role", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userRoles(res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
// Get user capabilities
router.get("/me/capabilities", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userCapabilities(res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
// Forgot Password
router.post("/forgot", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.forgotPassword(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/forgot/verify", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.otpVerification(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Set New Password
router.post("/forgot/setPassword", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.setNewPassword(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Add Group
router.post("/group/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.createGroup(req.body, res.locals.user));
    }
    catch (err) {
        if (err.message.includes("E11000")) {
            err.message = `Group name already exists.`;
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  List Group
router.get("/group/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.groupList(res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Edit Group
router.put("/group/:id/edit", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.editGroup(req.body, req.params.id, res.locals.user));
    }
    catch (err) {
        if (err.message.includes("E11000")) {
            err.message = `Group name already exists.`;
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  edit status of group
router.put("/group/:id/status", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.groupStatus(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Add Member
router.post("/group/:id/member/add", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addMember(req.params.id, req.body.users, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Remove Member
router.post("/group/:id/member/remove", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.removeMembers(req.params.id, req.body.users, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get User suggestion
router.get("/suggestion", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userSuggestions(req.query.search, res.locals.user._id, res.locals.user.role, req.query.searchKeys));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get(`/search-for-listing`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send({});
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/getUsersForProject`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getUsersForProject(req.query.search, res.locals.user._id, res.locals.user.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  Group Details
router.get("/group/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.groupDetail(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/countryCodes", async (req, res, next) => {
    try {
        res.status(200).send(JSON.parse(fs_1.readFileSync(path_1.join(__dirname, "..", "utils", "country_codes.json"), "utf8")));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/userInfo/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userInformation(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/changePassword", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.changeOldPassword(req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post('/changeEmail', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.changeEmailInfo(req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post('/profile/otp/verification', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.profileOtpVerify(req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
router.get(`/getFormattedRoles`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_3.role_list());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/login/history/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.loginHistory(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/send/mobileOtp/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await utils_1.mobileSendOtp(req.body.phone, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/resend/mobileOtp/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await utils_1.mobileRetryOtp(req.body.phone, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/mobile/verify/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await utils_1.mobileVerifyOtp(req.body.phone, req.body.otp, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/change/mobile", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.changeMobileNumber(req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
// Replace User
router.post(`/:id/replace`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.replaceUser(req.params.id, req.body.replaceTo, req.token, res.locals.user));
    }
    catch (error) {
        next(error);
    }
});
router.post('/send/notification', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(module_1.sendNotification(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get('/validation/:token', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.tokenValidation(req.params.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post('/:id/admin/profile/edit', utils_1.authenticate, async (req, res, next) => {
    try {
        let admin_scope = await role_management_1.checkRoleScope(res.locals.user.role, "edit-user-profile");
        if (!admin_scope)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        let payload;
        const contentType = req.get('content-type');
        if (contentType.includes('multipart/form-data')) {
            payload = await module_2.uploadToFileService(req);
        }
        if (contentType.includes('application/json')) {
            payload = JSON.stringify(req.body);
        }
        res.status(http_status_codes_1.OK).send(await module_1.profileEditByAdmin(req.params.id, JSON.parse(payload), res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get('/check/recaptcha', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await model_1.constantSchema.findOne({ key: "captcha" }));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/task-endorse/send-otp", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await utils_1.mobileSendOtp(`${res.locals.user.countryCode}${res.locals.user.phone}`, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/task-endorse/verify-otp", utils_1.authenticate, async (req, res, next) => {
    try {
        const verifiedToken = await utils_1.mobileVerifyOtp(req.body.phone, req.body.otp, res.locals.user._id);
        await module_1.updateTaskEndorser(res.locals.user._id, req.query.task, req.token);
        res.status(http_status_codes_1.OK).send(verifiedToken);
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/otp/verify/admin/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.verifyOtpByAdmin(res.locals.user, req.body, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/setPassword/admin/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.setPasswordByAdmin(res.locals.user, req.body, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/otp/verify/user", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.verificationOtpByUser(req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/changeEmail/admin/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.changeEmailByAdmin(res.locals.user, req.body, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/changeMobile/admin/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.changeMobileByAdmin(res.locals.user, req.body, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/role-formate", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.formateRoles(req.body.roles));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
