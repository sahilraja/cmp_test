"use strict";
const express_1 = require("express");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("../steps/module");
const urls_1 = require("../utils/urls");
const upload_format_model_1 = require("../project/upload-format-model");
const http_1 = require("http");
const https_1 = require("https");
const module_2 = require("../documents/module");
const router = express_1.Router();
router.get(`/step-info`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.stepDetail(req.params.stepId));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-all-steps`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/upload-sample-excel`, async (req, res, next) => {
    try {
        let payload;
        const contentType = req.get('content-type');
        if (contentType.includes('multipart/form-data')) {
            payload = await module_2.uploadToFileService(req);
        }
        payload = JSON.parse(payload);
        res.status(http_status_codes_1.OK).send(await upload_format_model_1.UploadFormatSchema.findOneAndUpdate({ type: 'TASK_EXCEL' }, { type: 'TASK_EXCEL', name: payload.name, fileId: payload.id }, { upsert: true }).exec());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/download-bulk-task-excel`, async (request, response, next) => {
    const detail = await upload_format_model_1.UploadFormatSchema.findOne({ type: 'TASK_EXCEL' }).exec();
    const req = urls_1.FILES_SERVER_BASE.startsWith("https") ?
        https_1.get(`${urls_1.FILES_SERVER_BASE}/files/${detail.fileId}`, (res) => {
            response.setHeader('Content-disposition', `attachment;filename=${detail.name || `sample.csv`}`);
            response.setHeader('Content-type', res.headers['content-type']);
            res.pipe(response);
        }) : http_1.get(`${urls_1.FILES_SERVER_BASE}/files/${detail.fileId}`, (res) => {
        response.setHeader('Content-disposition', `attachment;filename=${detail.name || `sample.csv`}`);
        response.setHeader('Content-type', res.headers['content-type']);
        res.pipe(response);
    });
    req.on('error', (e) => {
        next(e);
    });
    req.end();
});
router.post(`/upload-user-excel`, async (req, res, next) => {
    try {
        let payload;
        const contentType = req.get('content-type');
        if (contentType.includes('multipart/form-data')) {
            payload = await module_2.uploadToFileService(req);
        }
        payload = JSON.parse(payload);
        res.status(http_status_codes_1.OK).send(await upload_format_model_1.UploadFormatSchema.findOneAndUpdate({ type: 'USER_EXCEL' }, { type: 'USER_EXCEL', name: payload.name, fileId: payload.id }, { upsert: true }).exec());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/download-bulk-user-excel`, async (request, response, next) => {
    const detail = await upload_format_model_1.UploadFormatSchema.findOne({ type: 'USER_EXCEL' }).exec();
    const req = urls_1.FILES_SERVER_BASE.startsWith("https") ?
        https_1.get(`${urls_1.FILES_SERVER_BASE}/files/${detail.fileId}`, (res) => {
            response.setHeader('Content-disposition', `attachment;filename=${detail.name || `sample.csv`}`);
            response.setHeader('Content-type', res.headers['content-type']);
            res.pipe(response);
        }) : http_1.get(`${urls_1.FILES_SERVER_BASE}/files/${detail.fileId}`, (res) => {
        response.setHeader('Content-disposition', `attachment;filename=${detail.name || `sample.csv`}`);
        response.setHeader('Content-type', res.headers['content-type']);
        res.pipe(response);
    });
    req.on('error', (e) => {
        next(e);
    });
    req.end();
});
module.exports = router;
