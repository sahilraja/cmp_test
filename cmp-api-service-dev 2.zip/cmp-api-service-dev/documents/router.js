"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const groups_1 = require("../utils/groups");
const http_1 = require("http");
const https_1 = require("https");
const utils_1 = require("../utils/utils");
const urls_1 = require("../utils/urls");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const role_management_1 = require("../utils/role_management");
const http_status_codes_1 = require("http-status-codes");
const module_2 = require("../site-constants/module");
const module_3 = require("../log/module");
const multer = require("multer");
const path_1 = require("path");
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        console.log("Dest");
        cb(null, (path_1.join(__dirname, "..", 'uploads')));
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + file.originalname);
    }
});
const upload = multer({ storage });
const router = express_1.Router();
const ensureCanViewDocument = (req, res, next) => {
    const documentId = req.params.id;
    next();
};
const ensureCanViewVersion = (req, res, next) => {
    const documentId = req.params.id;
    //Make sure this is either CS or owner.
    next();
};
const siteConstants = async (req, res, next) => {
    let constantsInfo = await module_2.getConstantsAndValues(['docNameLength', 'docSize', 'docDescriptionSize', 'replaceDoc']);
    req.siteConstants = constantsInfo;
    next();
};
const ensureCanEditDocument = (req, res, next) => {
    const documentId = req.params.id;
    const userId = res.locals.user._id;
    //if (userId not allowed to documentId)
    // return next(new Error("Not authorized to perform actions on this document"));
    //else
    next();
};
const ensureCanPublishDocument = (req, res, next) => {
    const documentId = req.params.id;
    const userId = res.locals.user._id;
    //if (userId not allowed to publish documentId)
    // return next(new Error())
    //else
    next();
};
// router.param("id", async (req, res, next, value) => {
//   const documentId = req.params.id;
//   try {
//     const doc = await getDocumentById(documentId);
//     next();
//   } catch (err) {
//     next(new APIError(err.message));
//   }
// });
//  Create Document
router.post("/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.createDoc(req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get(`/insert-in-elastic-search`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getDocsAndInsertInElasticSearch());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  Create Document new Api
router.post("/create/new", utils_1.authenticate, siteConstants, async (req, res, next) => {
    try {
        const isEligible = await role_management_1.checkRoleScope(res.locals.user.role, "create-doc");
        if (!isEligible)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.NO_PERMISSION);
        req.body.constants = siteConstants;
        const fileObj = JSON.parse(await module_1.uploadToFileService(req, req.siteConstants.docSize));
        if (fileObj.errors)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.FILE_SIZE(req.siteConstants.docSize));
        res.status(200).send(await module_1.createNewDoc(fileObj, res.locals.user._id, req.siteConstants, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Get Public List
router.get("/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getDocList(req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`, req.query.sortOrder, req.query.sortBy));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Get My shared list
router.get("/shared/me", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.sharedList(res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`, req.query.sortOrder, req.query.sortBy));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Get My shared list
router.get("/financial-documents/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getFinancialDocList(res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Get My shared list
router.get("/publish/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.publishList(res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Get My shared list
router.get("/all/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.allDocuments(res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Get My list
router.get("/me", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getDocListOfMe(res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Get pending Approval parent Docs
router.get("/approvals", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.approvalList(`${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// get pending and Approval parent Docs
router.get("/approvals/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getApprovalDoc(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/search", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.docFilter(req.query.filter, res.locals.user._id, req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`, req.query.publish));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/user-capabilities", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.checkCapabilitiesForUser(req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/user-capabilities-new", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.checkCapabilitiesForUserNew(req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/add-user-capabilities", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.shareDocForUsers(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/add-user-capabilities-new", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.shareDocForUsersNew(req.body, res.locals.user, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get(`/get-document/:docId`, async (request, response, next) => {
    try {
        const req = urls_1.FILES_SERVER_BASE.startsWith("https") ?
            https_1.get(`${urls_1.FILES_SERVER_BASE}/compressed-image/${request.params.docId}`, (res) => {
                response.setHeader('Content-disposition', 'inline');
                response.setHeader('Content-type', res.headers['content-type']);
                res.pipe(response);
            }) : http_1.get(`${urls_1.FILES_SERVER_BASE}/compressed-image/${request.params.docId}`, (res) => {
            response.setHeader('Content-disposition', 'inline');
            response.setHeader('Content-type', res.headers['content-type']);
            res.pipe(response);
        });
        req.on('error', (e) => {
            next(e);
        });
        req.end();
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/all", utils_1.superUserAuthenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getAllDocs());
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/project-info-for-docs", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getProjectNamesForES(req.body.docIds, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/background", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.backgroundJobForDocumentPhases(req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Used for tasks while approving or endorsing
router.post(`/get-latest-versions`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getLatestVersionforDocuments(req.body.documentIds));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
// router.get("/get-doc-view/:docId", async (request, response, next) => {
//   try {
//     const req = (FILES_SERVER_BASE as string).startsWith("https")
//       ? httpsGet(`${FILES_SERVER_BASE}/files/${request.params.docId}`, (res: any) => {
//         response.writeHead(200, res.headers);
//         res.pipe(response);
//       })
//       : httpGet(`${FILES_SERVER_BASE}/files/${request.params.docId}`, (res: any) => {
//         console.log(res)
//         response.writeHead(200, res.headers);
//         res.pipe(response);
//       });
//     req.on('error', (e: Error) => {
//       next(e);
//     });
//     req.end();
//   } catch (err) {
//     throw err
//   }
// })
//  Create new Version
// router.post("/:id/versions/:versionId/create", authenticate, ensureCanEditDocument, async (req, res, next: NextFunction) => {
//     try {
//         const { id, versionId } = req.params
//         res.status(200).send(await createNewVersion(id, versionId, res.locals.user._id, req.body));
//     } catch (err) {
//         next(new APIError(err.message));
//     };
// });
// get versions
router.get("/:id/versions", utils_1.authenticate, ensureCanPublishDocument, async (req, res, next) => {
    try {
        const { id } = req.params;
        res.status(200).send(await module_1.getVersions(id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Publish a specific version to public.
// router.post("/:id/versions/:versionId/publish", authenticate, ensureCanPublishDocument, async (req, res, next: NextFunction) => {
//     try {
//         const { id, versionId } = req.params
//         res.status(200).send(await ApproveDoc(id, versionId))
//     } catch (err) {
//         next(new APIError(err.message));
//     };
// });
// create File
// router.post("/:id/versions/:versionId/reject", authenticate, ensureCanPublishDocument, async (req, res, next: NextFunction) => {
//     try {
//         const { id, versionId } = req.params
//         res.status(200).send(await RejectDoc(id, versionId))
//     } catch (err) {
//         next(new APIError(err.message));
//     };
// });
// Upload File for a version.
router.post("/:id/file", utils_1.authenticate, ensureCanEditDocument, async (req, res, next) => {
    try {
        const { id } = req.params;
        const fileObj = await module_1.uploadToFileService(req);
        let response = await module_1.createFile(id, fileObj);
        res.status(200).send(response);
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//Download a file for a given version.
// router.get("/:id/versions/:versionId/file", ensureCanViewDocument, async (request: any, response: any, next: NextFunction) => {
//     try {
//         const { id, versionId } = request.params;
//         const { fileId } = await getDocumentVersionById(id);
//         const req = httpGet(`${FILES_SERVER_BASE}/files/${fileId}`, (res: any) => {
//             response.writeHead(200, res.headers);
//             res.pipe(response);
//         });
//         req.on('error', (e: Error) => {
//             next(e);
//         });
//         req.end();
//     } catch (err) {
//         next(new APIError(err.message));
//     };
// });
router.get("/:id/file-download-log", utils_1.authenticate, async (req, res, next) => {
    try {
        let documentDetails = await module_1.getDocumentById(req.params.id);
        await module_3.create({ activityType: `DOCUMENT_DOWNLOAD`, activityBy: res.locals.user._id, documentId: documentDetails.parentId || documentDetails._id });
        res.status(http_status_codes_1.OK).send({ success: true });
    }
    catch (err) {
        throw err;
    }
    ;
});
//Download a file for a given document id
router.get("/:id/file", ensureCanViewDocument, async (request, response, next) => {
    try {
        const { id } = request.params;
        const { fileId } = await module_1.getDocumentById(id);
        // const fileId = '5d66b64f7690505a261ab0fd';
        const req = urls_1.FILES_SERVER_BASE.startsWith("https")
            ? https_1.get(`${urls_1.FILES_SERVER_BASE}/files/${fileId}`, (res) => {
                response.writeHead(200, res.headers);
                res.pipe(response);
            })
            : http_1.get(`${urls_1.FILES_SERVER_BASE}/files/${fileId}`, (res) => {
                response.writeHead(200, res.headers);
                res.pipe(response);
            });
        req.on("error", (e) => {
            next(e);
        });
        req.end();
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Submit for approval
router.put("/:id/submit", utils_1.authenticate, ensureCanEditDocument, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.submit(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Get Document Details with versions
// router.get("/:id/versions/:versionId", authenticate, ensureCanViewDocument, async (req, res, next: NextFunction) => {
//     try {
//         res.status(200).send(await getDocWithVersion(req.params.id, req.params.versionId));
//     } catch (err) {
//         next(new APIError(err.message));;
//     };
// });
//  Add collaborators
router.post("/:id/collaborator/add", utils_1.authenticate, async (req, res, next) => {
    try {
        res
            .status(200)
            .send(await module_1.addCollaborator(req.params.id, req.body.collaborators));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  remove collaborators
router.put("/:id/collaborator/remove", utils_1.authenticate, async (req, res, next) => {
    try {
        res
            .status(200)
            .send(await module_1.removeCollaborator(req.params.id, req.body.collaborators));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Add viewers
router.post("/:id/viewer/add", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addViewers(req.params.id, req.body.viewers));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  remove viewers
router.put("/:id/viewer/remove", utils_1.authenticate, async (req, res, next) => {
    try {
        res
            .status(200)
            .send(await module_1.removeViewers(req.params.id, req.body.viewers));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  viewers list
router.get("/:id/viewer/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.viewerList(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  collaborators list
router.get("/:id/collaborator/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.collaboratorList(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  invite user
router.post("/:id/share", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.invitePeople(req.params.id, req.body.users, req.query.role, res.locals.user._id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  invite user list
router.get("/:id/share/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.invitePeopleList(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  invite user edit      
router.put("/:id/share/:type/:userId/edit", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id, type, userId } = req.params;
        res.status(200).send(await module_1.invitePeopleEdit(id, userId, type, req.query.role, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  invite user edit
router.delete("/:id/share/:type/:userId/remove", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id, type, userId } = req.params;
        res.status(200).send(await module_1.invitePeopleRemove(id, userId, type, req.query.role, res.locals.user, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.get("/:id/capabilities", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.documnetCapabilities(req.params.id, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.post("/:id/publish", utils_1.authenticate, async (req, res, next) => {
    try {
        const host = `${req.protocol}://${req.get('host')}`;
        res.status(200).send(await module_1.published(req.body, req.params.id, res.locals.user, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.put("/:id/unpublish", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.unPublished(req.params.id, res.locals.user, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.put(`/:id/mark-as-public`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.markDocumentAsPublic(req.params.id, res.locals.user.role, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/mark-as-unpublic`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.markDocumentAsUnPublic(req.params.id, res.locals.user.role, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  update exist doc
router.post("/:id/replace/:replaceDocId", utils_1.authenticate, siteConstants, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.replaceDoc(req.params.id, req.params.replaceDocId, res.locals.user, req.siteConstants, req.body, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.get("/:id/cancel", utils_1.authenticate, ensureCanEditDocument, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.cancelUpdate(req.params.id, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.post("/:id", utils_1.authenticate, ensureCanEditDocument, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.updateDoc(req.body, req.params.id, res.locals.user._id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  update exist doc
router.post("/:id/new", utils_1.authenticate, ensureCanEditDocument, siteConstants, async (req, res, next) => {
    try {
        const fileObj = JSON.parse(await module_1.uploadToFileService(req));
        res.status(200).send(await module_1.updateDocNew(fileObj, req.params.id, res.locals.user._id, req.siteConstants, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Get Document Details
router.get("/:id", utils_1.authenticate, ensureCanViewDocument, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getDocDetails(req.params.id, res.locals.user._id, req.token, req.query.allCmp));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
/**
 * API for success response
 * this API wont create activity log that user viewed document
 * Instead of changing all other API responses creted this API
 */
router.get("/:id/view-details", utils_1.authenticate, ensureCanViewDocument, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getDocDetailsForSuccessResp(req.params.id, res.locals.user._id, req.token, req.query.allCmp));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Create Folder
router.post("/folder/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.createFolder(req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//Move file to a folder
router.put("/moveTo/folder/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.moveToFolder(req.params.id, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//remove file from folder
router.put("/removeFrom/folder/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.removeFromFolder(req.params.id, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//list of folders
router.get("/folder/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.listFolders(res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//list of folders and files in it
router.get("/folder/:folderId/list", utils_1.authenticate, async (req, res, next) => {
    try {
        const host = `${req.protocol}://${req.get('host')}`;
        res.status(200).send(await module_1.getFolderDetails(req.params.folderId, res.locals.user._id, req.query.page, req.query.limit, host, req.rootPath, req.query.sortOrder, req.query.sortBy));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//delete folder
router.delete("/folder/delete/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.deleteFolder(req.params.id, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/multiple/list", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.documentsList(req.body.ids));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.put("/delete/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.deleteDoc(req.params.id, res.locals.user._id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/all/me", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getListOfFoldersAndFiles(res.locals.user._id, req.query.page, req.query.limit, req.query.sortOrder, req.query.sortBy, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docId/suggest/tags", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.suggestTags(req.params.docId, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docId/suggest/tags/addOrRemove", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.suggestTagsToAddOrRemove(req.params.docId, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docId/approve/tags", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.approveTags(req.params.docId, req.body, res.locals.user._id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docId/reject/tags", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.rejectTags(req.params.docId, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/get/tags", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getAllTags(req.body.tags));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docId/delete/suggested/tags", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.deleteSuggestedTag(req.params.docId, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/:id/requests/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getAllRequest(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:id/requests/accept", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.requestAccept(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:id/requests/denied", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.requestDenied(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/:docid/requests/raise", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.requestRaise(req.params.docid, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Get All Cmp Docs List
router.get("/allcmp/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getAllCmpDocs(req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`, res.locals.user._id, req.query.sortOrder, req.query.sortBy));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get(`/public/all`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getAllPublicDocuments(req.query.page, req.query.limit, `${req.protocol}://${req.get('host')}`, req.query.tags, req.query.search));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  Create Folder
router.put("/folder/rename/:folderId", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.renameFolder(req.params.folderId, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/search/doc", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.searchDoc(req.query.search, res.locals.user._id, req.query.page, req.query.limit, req.query.pagination, req.query.searchAllCmp));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/update/userDocs", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.updateUserInDOcs(req.body, res.locals.user._id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/create/index", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.createIndex(req.body.index));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post("/remove/index", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.removeIndex(req.body.index));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post(`/bulk-document/upload`, utils_1.authenticate, siteConstants, upload.single('upfile'), async (req, res, next) => {
    try {
        res.status(200).send(await module_1.bulkUploadDocument(req.file.path, res.locals.user, req.siteConstants, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/:id/details", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getDocumentById(req.params.id));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.get("/:id/get-doc-users", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await groups_1.GetUserIdsForDocWithRole(req.params.id, req.query.role));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.get("/:id/get-project-details", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getProjectDetailsForES(req.params.id, (req.token)));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.post(`/:id/create-task-activity`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createTaskActivityOnDoc(req.body, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/:token/verifyJwt", async (req, res, next) => {
    try {
        res.status(200).send(await utils_1.jwt_Verify(req.params.token));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.get("/:id/move-to-my-docs", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.moveToMyDocuments(req.params.id, res.locals.user._id));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.get("/all/mydocs-and-moved-docs", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.getListOfFoldersAndFilesWithMovedDocuments(res.locals.user._id, req.query.page, req.query.limit, req.query.sortOrder, req.query.sortBy, `${req.protocol}://${req.get('host')}`));
    }
    catch (err) {
        throw err;
    }
    ;
});
router.get("/:id/delete-moved-doc", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.deleteMovedDocInMyDocs(req.params.id, res.locals.user._id));
    }
    catch (err) {
        throw err;
    }
    ;
});
module.exports = router;
