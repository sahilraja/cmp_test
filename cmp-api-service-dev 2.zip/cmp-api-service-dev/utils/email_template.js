"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
//  Invite User Email Template
function inviteUserForm(body) {
    try {
        const text = `
        Hi,<br/></br>
        <br/>
        You are invited by an Administrator of CMP platform to join for the role of <b>${body.role}.</b><br/>
        <br/>
        You can proceed with your registration by accepting invitation by clicking on the following <a href=${body.link}>link</a>.<br/>
        <br/>
        Please ignore if you think this is not intended for you. <br/>
        <br/>
        Best Regards,<br/>
        CITIIS Management Platform Team
        `;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.inviteUserForm = inviteUserForm;
;
//  Forgot Password Email Template
function forgotPasswordForm(body) {
    try {
        const text = `Hello <b>${body.fullName}</b>,<br><br>
            <u>${body.otp}</u> is the One Time Password (OTP) to activate your CMP account.
            <br/>
            <br/>
            Best Regards,<br/>
            CMP Support.`;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.forgotPasswordForm = forgotPasswordForm;
;
function profileOtp(body) {
    try {
        const text = `Hello <b>${body.fullName}</b>,<br><br>
            <u>${body.otp}</u> is the One Time Password (OTP) to update your CMP account.
            <br/>
            <br/>
            Please ignore if you think this is not intended for you. <br/>
            <br/>
            Best Regards,<br/>
            CITIIS Management Platform Team`;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.profileOtp = profileOtp;
;
//  Document Invite Email Template
function docInvitePeople(body) {
    try {
        const text = `
        Hi,<br/></br>
        <br/>
        You are invited by an user of CMP to collaborate on the document <b>${body.documentName}</b><br/>
        <br/>
        You can click this <a href="${body.documentUrl}">link</a> to access it. <br/>
        Please ignore if you think this is not intended for you. <br/>
        <br/>
        Best Regards,<br/>
        CITIIS Management Platform Team
        `;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.docInvitePeople = docInvitePeople;
;
function userLoginForm(body) {
    try {
        const text = `Welcome to <h>CMP<h>`;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.userLoginForm = userLoginForm;
function userState(body) {
    try {
        const text = `Your account has been ${body.state} | CMP`;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.userState = userState;
function suggestTagNotification(body) {
    try {
        const text = `
        Hi,<br/></br>
        <br/>
        <b>${body.userName}</b> suggested a tag.<br/>
        <br/>
        You can click this <a href="${body.documentUrl}">link</a> to view it. <br/>
        Please ignore if you think this is not intended for you. <br/>
        <br/>
        Best Regards,<br/>
        CITIIS Management Platform Team
        `;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.suggestTagNotification = suggestTagNotification;
;
function approveTagNotification(body) {
    try {
        const text = `
        Hi,<br/></br>
        <br/>
        <b>${body.fullName}</b>has been approved a tag suggested by you.<br/>
        <br/>
        You can click this <a href="${body.documentUrl}">link</a> to view it.<br/>
        Please ignore if you think this is not intended for you. <br/>
        <br/>
        Best Regards,<br/>
        CITIIS Management Platform Team
        `;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.approveTagNotification = approveTagNotification;
;
function rejectTagNotification(body) {
    try {
        const text = `
        Hi,<br/></br>
        <br/>
        <b>${body.fullName}</b> has neen rejected a tag suggested by you.<br/>
        <br/>
        You can click this <a href="${body.documentUrl}">link</a> to view it.<br/>
        Please ignore if you think this is not intended for you. <br/>
        <br/>
        Best Regards,<br/>
        CITIIS Management Platform Team
        `;
        return text;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.rejectTagNotification = rejectTagNotification;
;
