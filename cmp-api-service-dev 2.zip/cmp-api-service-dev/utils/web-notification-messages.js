"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOC_NOTIFICATIONS = {
    inviteForDocument: (name) => `You are invited by [from] to collaborate on the document ${name}`,
    suggestTagNotification: (name) => `You have a tag suggestion on the document ${name} from [from]`,
    approveTagNotification: (name, tagNames) => `A tag ${tagNames} you suggested has been approved on the document ${name}`,
    approveRemoveTagNotification: (name, tagNames) => `A tag ${tagNames} you suggested for removal has been approved on the document ${name}`,
    rejectTagNotification: (name, tagNames) => `A tag ${tagNames} you suggested has been rejected on the document ${name}`,
    rejectRemoveTagNotification: (name, tagNames) => `A tag ${tagNames} you suggested for removal has been rejected on the document ${name}`,
    addCommentToDoc: (name) => `A new comment has been added to the document ${name}`,
    documentUpdate: (text, name) => `Document ${name} has been updated ${text ? "with " + text : ""}`,
    invitePeopleDoc: (sharedUsers, role, name) => `Your document ${name} on CITIIS Management Platform, is shared with ${sharedUsers} in the capacity of ${role}`,
    publishDocument: (name) => `Document ${name} is published`,
    unPublishDocument: (name) => `Document ${name} is unpublished`,
    replaceDocument: (name) => `Document ${name} is replaced with a new document.`,
    documentRequest: (name) => `Someone request your document for access on the document ${name}.`,
    documentRequestApproved: (name) => `your request for access was approved on the document ${name}.`,
    documentRequestRejected: (name) => `your request for access was rejected on the document ${name}.`,
    documentSuggestTagsModified: (name) => `You have new update in tag suggestion on the document ${name} from [from]`,
};
exports.GROUP_NOTIFICATIONS = {
    youAddTOGroup: `You are added to a group [groupId]`,
    groupStatus: `Group status for [groupId], which you are a part of, has been updated on CITIIS Management Platform.`,
    addGroupMember: `A new member is added to the user group [groupId] on CITIIS Management Platform.`
};
exports.USER_PROFILE = {
    passwordUpdateByAdmin: `Your password has been updated by [from]`,
    emailUpdateByAdmin: `Your email has been updated by [from]`,
    phoneUpdateByAdmin: `Your phone number has been updated by [from]`,
    emailUpdateByUser: `successfully you email has been updated`,
    phoneUpdateByUser: `successfully you phone number has been updated`,
    passwordUpdateByUser: `successfully you password has been updated`,
};
exports.PROJECT_NOTIFICATIONS = {
    TRIPART_DATE_UPDATED: (projectName) => `Tripart date has been updated for the project ${projectName}`,
    MIS_COMPLIANCE_UPDATED: (projectName) => `Miscompliance has been updated for the project ${projectName}`,
    // RISK_CREATED:(projectName: string) => ``,
    PHASES_UPDATED: (projectName) => `Phases has been updated for the project ${projectName}`,
    MEMBER_ADDED_TO_PROJECT: (projectName) => `You are added to a project ${projectName} on CMP`,
    ADDED_FUND_RELEASE: (projectName) => `New fund release has been added to the project ${projectName}`,
    FINANCIAL_INFO_UPDATED: (projectName) => `Financial information data has been added to the project ${projectName}`
};
