"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
class APIError extends Error {
    constructor(message, code = 400) {
        const regex = /@()@|([{}":\[/\]/])/g;
        message = message.replace(regex, '').replace(`errors`, `error`).replace(/error/gi, '').split('-').pop().trim();
        super(message);
        this.code = code;
    }
}
exports.APIError = APIError;
class UnformatedAPIError extends Error {
    constructor(message, code = 400) {
        super(message);
        this.code = code;
    }
}
exports.UnformatedAPIError = UnformatedAPIError;
class FormattedAPIError extends Error {
    constructor(message, shouldFormatError, code = 400) {
        const regex = /@()@|([{}":\[/\]/])/g;
        if (shouldFormatError) {
            message = message.replace(regex, '').replace(/error(s)?/gi, '').split('-').pop().trim();
        }
        super(message);
        this.code = code;
    }
}
exports.FormattedAPIError = FormattedAPIError;
