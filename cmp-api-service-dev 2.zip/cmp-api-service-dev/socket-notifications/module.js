"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const socket_1 = require("../socket");
const users_1 = require("../utils/users");
const module_1 = require("../users/module");
const module_2 = require("../patterns/module");
const mongoose_1 = require("mongoose");
async function create(payload) {
    const createdNotification = await model_1.SocketNotifications.create(payload);
    socket_1.emitLatestNotificationCount(createdNotification.userId);
    socket_1.emitLatestInboxCount(createdNotification.userId);
    return createdNotification;
}
exports.create = create;
async function list(userId, currentPage = 1, limit = 30, token) {
    let { docs: notifications, page, limit: pageLimit, pages, total } = await model_1.SocketNotifications.paginate({ userId }, { page: Number(currentPage), limit: Number(limit), sort: { createdAt: -1 }, populate: "docId" });
    let [userObjs, taskObjs, groupObjs, projectObjects] = await Promise.all([
        users_1.userFindMany("_id", [...new Set((notifications.reduce((main, curr) => main.concat(curr.from, curr.userId), []).filter(id => mongoose_1.Types.ObjectId(id))))]),
        users_1.getTasksByIds([...new Set((notifications.map(({ taskId }) => taskId)).filter(id => mongoose_1.Types.ObjectId(id)))], token),
        users_1.groupPatternMatch({ "_id": [...new Set((notifications.map(({ groupId }) => groupId)).filter(id => mongoose_1.Types.ObjectId(id)))] }),
        notifications.filter((notification) => notification.notificationType == `PROJECT`)
    ]);
    let docList = await Promise.all(notifications.map((notificationObj) => formatNotification(notificationObj.toJSON(), userId, { users: userObjs, tasks: taskObjs, groups: groupObjs, projects: projectObjects })));
    return { docs: docList, page, limit: pageLimit, pages, total };
}
exports.list = list;
async function formatNotification(notificationObj, userId, details) {
    let userKeys = ["from", "userId"];
    let keys = (notificationObj.title.match(/\[(.*?)\]/g));
    keys = keys && keys.length ? keys.map((key) => key.substring(1, key.length - 1)) : [];
    let replaceAllObj = keys.map((key) => {
        // if (userKeys.includes(key)) {
        //     return { key: key, match: notificationObj.from == userId ? `You` : (getFullNameAndMobile(details.users.find((userObj: any) => notificationObj[key] == userObj._id)) || { fullName: "" }).fullName }
        // }
        if (key == `from`) {
            return { key: key, match: notificationObj.from == userId ? `You` : (module_1.getFullNameAndMobile(details.users.find((userObj) => notificationObj[key] == userObj._id)) || { fullName: "" }).fullName };
        }
        if (key == `userId`) {
            return { key: key, match: notificationObj.userId == userId ? `you` : (module_1.getFullNameAndMobile(details.users.find((userObj) => notificationObj[key] == userObj._id)) || { fullName: "" }).fullName };
        }
        if (key == "taskId") {
            return {
                key: key, match: details.tasks.find((taskObj) => notificationObj[key] == taskObj._id).name
            };
        }
        if (key == "docId") {
            return { key: key, match: notificationObj.docId.name };
        }
        if (key == "groupId") {
            return { key: key, match: details.groups.find((groupObj) => notificationObj[key] == groupObj._id).name };
        }
        else {
            return { key: [key], match: "" };
        }
    });
    for (const { key, match } of replaceAllObj) {
        notificationObj.title = module_2.replaceAll(notificationObj.title, `[${key}]`, match);
    }
    return Object.assign({}, notificationObj, { docId: notificationObj.docId ? notificationObj.docId._id : notificationObj.docId });
}
async function listUnreadNotifications(userId) {
    return await model_1.SocketNotifications.find({ userId, read: false }).exec();
}
exports.listUnreadNotifications = listUnreadNotifications;
async function markAsRead(id, userId) {
    const updatedNotification = await model_1.SocketNotifications.findByIdAndUpdate(id, { $set: { read: true } }).exec();
    socket_1.emitLatestNotificationCount(userId);
    return updatedNotification;
}
exports.markAsRead = markAsRead;
