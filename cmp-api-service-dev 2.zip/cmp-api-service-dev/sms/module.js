"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const error_msg_1 = require("../utils/error_msg");
async function smsTemplateCreate(body) {
    try {
        if (!body.content || !body.templateName || !body.displayName) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        let templateCreate = await model_1.smsTemplateSchema.create(body);
        return templateCreate;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.smsTemplateCreate = smsTemplateCreate;
;
async function list() {
    return await model_1.smsTemplateSchema.find({}).exec();
}
exports.list = list;
async function smsTemplateEdit(body, id) {
    try {
        let objBody = {};
        if (body.content) {
            objBody.content = body.content;
        }
        if (body.displayName) {
            objBody.displayName = body.displayName;
        }
        if (body.subject) {
            objBody.subject = body.subject;
        }
        let templateCreate = await model_1.smsTemplateSchema.findByIdAndUpdate(id, { $set: objBody }, { new: true });
        return templateCreate;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.smsTemplateEdit = smsTemplateEdit;
;
async function smsTemplateDelete(body, id) {
    try {
        let templateCreate = await model_1.smsTemplateSchema.findByIdAndRemove(id);
        return { message: "Successfully deleted template" };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.smsTemplateDelete = smsTemplateDelete;
;
async function smsTemplateGet(id) {
    try {
        let template = await model_1.smsTemplateSchema.findById(id);
        return template;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.smsTemplateGet = smsTemplateGet;
;
async function getSmsTemplateBySubstitutions(templateId, substitutions) {
    try {
        var template = await model_1.smsTemplateSchema.findOne({ templateName: templateId }).exec();
    }
    catch (err) {
        throw err;
    }
    if (!template) {
        throw new Error(`Email template is invalid, please try again`);
    }
    let smsContnet = Object.keys(substitutions).reduce((prev, key) => {
        return prev.replace(new RegExp(`\\[${key}\\]`, "g"), substitutions[key]);
    }, template.content);
    return smsContnet;
}
exports.getSmsTemplateBySubstitutions = getSmsTemplateBySubstitutions;
