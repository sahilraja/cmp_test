"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    role: { type: String, unique: true },
    templates: [{
            templateName: { type: String },
            displayName: { type: String },
            email: { type: Boolean },
            mobile: { type: Boolean },
            category: { type: String }
        }]
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.notificationSchema = mongoose_1.model("notifications", schema);
