"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const kue_1 = require("kue");
const utils_1 = require("./utils/utils");
const queue = kue_1.createQueue({
    redis: process.env.REDIS_URL || `redis://localhost:6379`
});
const PHASE_UPDATE = `UPDATE_PHASE`;
exports.jobRouter = kue_1.app;
function createJob(delayTime) {
    kue_1.Job.rangeByType(PHASE_UPDATE, 'delayed', 0, 2, 'asc', async (err, jobs) => {
        console.log(`delayTime`, delayTime);
        if (err || !jobs.length) {
            queue.create(PHASE_UPDATE, {}).delay(new Date(delayTime)).priority('high').attempts(10).removeOnComplete(true).save();
            console.log(`No Jobs found. Hence created a job`);
        }
        else {
            console.log(`Existing Job Found while creation`);
        }
    });
}
exports.createJob = createJob;
queue.process(PHASE_UPDATE, async (job, done) => {
    try {
        // let user:any = await userFindOne("is_active", true, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 })
        // let token= await createJWT({ id: user._id }); 
        // await createRefreshToken({id:user._id,token:token})
        utils_1.backGroundJobForPhasesInElasticSearch();
        // await removeRefreshToken({ id: user._id, token: token })
    }
    catch (error) {
        job.log(error);
    }
    finally {
        createJob(new Date().setHours(new Date().getHours() + 24, 0, 0, 0));
        done();
    }
});
