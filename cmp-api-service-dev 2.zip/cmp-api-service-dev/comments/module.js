"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const urls_1 = require("../utils/urls");
const users_1 = require("../utils/users");
const module_1 = require("../role/module");
const role_management_1 = require("../utils/role_management");
const error_msg_1 = require("../utils/error_msg");
const model_1 = require("./model");
const module_2 = require("../users/module");
const custom_error_1 = require("../utils/custom-error");
const module_3 = require("../log/module");
const model_2 = require("../documents/model");
const module_4 = require("../documents/module");
async function addComment(body, user, userToken) {
    try {
        if (!body.type || !body.comment || !body.entity_id)
            throw new Error(error_msg_1.COMMENT_ROUTER.MANDATORY);
        if (body.type == "document") {
            var doc = await model_2.documents.findById(body.entity_id);
            if (doc.parentId) {
                doc = await model_2.documents.findById(doc.parentId).exec();
            }
            // Added if -> add comments to task is also triggering the same API
            if (doc) {
                let admin_scope = (doc.status == 2) ? await role_management_1.checkRoleScope(user.role, "document-comments-publish") : await role_management_1.checkRoleScope(user.role, "document-comments");
                if (!admin_scope)
                    throw new custom_error_1.APIError(error_msg_1.COMMENT_ROUTER.UNAUTHORIZED, 403);
            }
        }
        if (body.type == `task`) {
            const taskDetail = await role_management_1.httpRequest({
                url: `${urls_1.TASKS_URL}/task/${body.entity_id}/soft-detail`,
                json: true,
                method: 'GET',
                // body: { status: { $nin: [8] } },
                headers: { 'Authorization': `Bearer ${userToken}` }
            });
            if (taskDetail && taskDetail.success && ![...taskDetail.approvers, ...taskDetail.endorsers, taskDetail.actualAssignee, taskDetail.owner].includes(user._id)) {
                throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.INVALID_WFM_BY_USER);
            }
            await module_3.create({ activityType: `TASK_COMMENT`, activityBy: user._id, taskId: body.entity_id });
        }
        let commentInfo = await model_1.comments.create({
            type: body.type,
            comment: body.comment,
            entity_id: body.entity_id,
            user_id: user._id
        });
        if (doc && body.type == "document" && doc.status != 2) {
            await module_3.create({ activityType: `DOCUMENT_COMMENT`, activityBy: user._id, documentId: body.entity_id });
            const { fullName, mobileNo } = module_2.getFullNameAndMobile(user);
            module_4.mailAllCmpUsers("addCommentToDoc", doc, false, user._id);
            // sendNotification({ id: user._id, fullName, mobileNo, email: user.email, templateName: "addCommentToDoc", mobileTemplateName: "addCommentToDoc" });
        }
        return commentInfo;
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.addComment = addComment;
async function commentsList(doc_id, type) {
    try {
        if (!doc_id) {
            throw new Error(error_msg_1.COMMENT_ROUTER.INVALID_OR_MISSING_DATA);
        }
        let data = await model_1.comments.find({ entity_id: doc_id, type: type });
        const commentsList = await Promise.all(data.map(comment => {
            return commentData(comment);
        }));
        return { comments: commentsList };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.commentsList = commentsList;
async function commentData(commentData) {
    try {
        let data = await Promise.all([{
                commentId: commentData._id,
                comment: commentData.comment,
                type: commentData.type,
                createdAt: commentData.createdAt,
                role: ((await module_1.userRoleAndScope(commentData.user_id)).data || [""])[0],
                user: await users_1.userFindOne("id", commentData.user_id, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 })
            }]);
        return data[0];
    }
    catch (err) {
        throw err;
    }
}
