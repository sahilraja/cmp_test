"use strict";
const express_1 = require("express");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const router = express_1.Router();
router.post(`/:id/risk/create`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.create(req.body, req.params.id, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/risk/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/risk/edit/save-all`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.riskSaveAll(req.params.id, req.body.saveAll, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.get(`/:id/risk/:riskId/edit-history/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.logList(req.params.id, req.params.riskId));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.get(`/:id/risk/:risk_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.detail(req.params.risk_id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/risk/:risk_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit(req.params.risk_id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.delete(`/:id/risk/:risk_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit(req.params.risk_id, { deleted: true }, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
