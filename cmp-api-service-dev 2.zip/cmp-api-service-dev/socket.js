"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const utils_1 = require("./utils/utils");
const users_1 = require("./utils/users");
const module_1 = require("./socket-notifications/module");
const module_2 = require("./tags/module");
const socketIO = require('socket.io');
let io = null;
function initializeSocket(http) {
    io = socketIO(http);
    io.use(async (socket, next) => {
        let user = await verify(socket.handshake.query);
        if (!user) {
            socket.emit('subscribe', 'User not found');
        }
        else {
            let roomExists = Object.keys(socket.rooms).includes(user._id);
            if (!roomExists) {
                socket.join(user._id);
            }
            // emitLatestNotificationCount(user._id)
            setTimeout(_ => emitLatestNotificationCount(user._id), 2000);
            setTimeout(_ => emitLatestInboxCount(user._id), 2000);
        }
        next();
    }).on('connection', async (socket) => {
        socket.on('subscribe', async (data) => {
        });
        // socket.on('send message', async (data: any) => {
        // })
        socket.on('disconnect', async (data) => {
            let user = await verify(data);
            if (!user) {
                socket.emit('subscribe', 'User not found');
            }
            else {
                socket.leave(user._id);
            }
        });
    });
}
exports.initializeSocket = initializeSocket;
async function verify(data) {
    if (!(data.access_token)) {
        return null;
    }
    let token = await utils_1.jwt_Verify(data.access_token);
    if (!token) {
        return null;
    }
    const user = await users_1.userFindOne("id", token.id);
    if (!user || !user.is_active) {
        return null;
    }
    return user;
}
async function emitLatestNotificationCount(userId) {
    if (!io)
        return;
    const unreadNotifications = await module_1.listUnreadNotifications(userId);
    io.to(userId).emit(`notificationCount`, unreadNotifications.length);
}
exports.emitLatestNotificationCount = emitLatestNotificationCount;
async function emitLatestInboxCount(userId) {
    if (!io)
        return;
    const unreadNotifications = await module_2.getUnreadMessages(userId);
    io.to(userId).emit(`inboxCount`, unreadNotifications.count);
}
exports.emitLatestInboxCount = emitLatestInboxCount;
