"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoose_transform_1 = require("mongoose-transform");
var RISK_STATUS;
(function (RISK_STATUS) {
    RISK_STATUS[RISK_STATUS["OPEN"] = 1] = "OPEN";
    RISK_STATUS[RISK_STATUS["CLOSED"] = 2] = "CLOSED";
})(RISK_STATUS = exports.RISK_STATUS || (exports.RISK_STATUS = {}));
const SchemaDef = new mongoose_1.Schema({
    riskNumber: { type: Number },
    riskTrend: { type: Number, default: null },
    dateRaised: { type: Date },
    projectId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'project' },
    riskFamily: { type: String, trim: true },
    description: { type: String, trim: true },
    phase: { type: mongoose_1.Schema.Types.ObjectId, ref: 'phase' },
    impact: { type: Number, default: 0 },
    probability: { type: Number, default: 0 },
    actions: { type: String, trim: true },
    comments: { type: String, trim: true },
    riskProvision: { type: Number, default: 0 },
    riskOwner: { type: String },
    status: { type: String },
    previousTrend: { type: Number, default: 0 },
    deleted: { type: Boolean, default: false },
    parentId: { type: mongoose_1.Types.ObjectId, default: null, ref: "risks" },
    createdBy: { type: String }
}, { timestamps: true });
SchemaDef.index({ projectId: 1 });
SchemaDef.index({ parentId: 1 });
SchemaDef.index({ parentId: 1, projectId: 1 });
SchemaDef.plugin(mongoose_transform_1.default);
exports.RiskSchema = mongoose_1.model(`risks`, SchemaDef);
