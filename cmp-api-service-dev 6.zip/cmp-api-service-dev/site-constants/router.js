"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const custom_error_1 = require("../utils/custom-error");
const module_1 = require("./module");
const utils_1 = require("../utils/utils");
const router = express_1.Router();
router.post(`/create`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createConstant(req.body, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/groupBy`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getConstantsGroupBy());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/update", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addConstants(req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/list", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.constantsList());
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post('/keyValues', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getConstantsAndValues(req.body.constantKeys));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
module.exports = router;
