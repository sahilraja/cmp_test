"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    docId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'documents' },
    requestedBy: { type: String },
    isDelete: { type: Boolean, default: false },
}, { timestamps: true });
exports.docRequestModel = mongoose_1.model("document-request", schema);
