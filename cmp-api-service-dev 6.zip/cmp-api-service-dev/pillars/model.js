"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoose_transform_1 = require("mongoose-transform");
const uniqueValidator = require('mongoose-unique-validator');
const SchemaDef = new mongoose_1.Schema({
    name: { type: String, trim: true, required: 'Name is required', unique: true, uniqueCaseInsensitive: true },
    createdBy: { type: String },
    disabled: { type: Boolean, default: false }
}, { timestamps: true });
SchemaDef.plugin(uniqueValidator, { message: 'Error, expected {PATH} to be unique.' });
SchemaDef.plugin(mongoose_transform_1.default);
exports.PillarSchema = mongoose_1.model('pillars', SchemaDef);
