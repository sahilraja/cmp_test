"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    content: { type: String },
    templateName: { type: String, unique: true },
    displayName: { type: String },
    subject: { type: String },
    form: { type: String, default: 'html' }
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.TemplateSchema = mongoose_1.model("template", schema);
