"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.USE_REMOTE_DB = process.env.USE_REMOTE_DB === 'true' || false;
exports.GROUPS_URL = exports.USE_REMOTE_DB ? process.env.REMOTE_GROUPS_URL : process.env.GROUPS_URL;
exports.FILES_SERVER_BASE = exports.USE_REMOTE_DB ? process.env.REMOTE_FILE_SERVER_URL : process.env.FILES_SERVER_BASE;
exports.RBAC_URL = exports.USE_REMOTE_DB ? process.env.REMOTE_RBAC_URL : process.env.RBAC_URL;
exports.ANGULAR_URL = process.env.ANGULAR_URL;
exports.TASKS_URL = process.env.CURRENT_HOST || "http://localhost:3000";
