"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    role: { type: String, unique: true },
    roleName: { type: String },
    category: { type: String },
    description: { type: String },
    createdBy: { type: String }
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.roleSchema = mongoose_1.model("roles", schema);
