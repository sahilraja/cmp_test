"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const utils_1 = require("../utils/utils");
const module_1 = require("../users/module");
async function create(payload, projectId, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
    }
    let risk = await model_1.RiskSchema.create(Object.assign({}, payload, { projectId, createdBy: userObj._id }));
    await model_1.RiskSchema.create(Object.assign({}, payload, { parentId: risk._id, projectId, createdBy: userObj._id }));
    return risk;
}
exports.create = create;
async function list(projectId) {
    let details = await model_1.RiskSchema.find({ deleted: false, projectId, parentId: null }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
    return details.map((riskObj) => { return Object.assign({}, riskObj.toJSON(), { age: utils_1.dateDifference(riskObj.createdAt) }); });
}
exports.list = list;
async function detail(riskId) {
    const detail = await model_1.RiskSchema.findById(riskId).populate({ path: 'phase' }).exec();
    const { riskOwner } = detail.toJSON();
    if (riskOwner) {
        return Object.assign({}, detail.toJSON(), { riskOwner: (await module_1.userFindManyWithRole(riskOwner) || [{}]).pop(), age: utils_1.dateDifference(detail.createdAt) });
    }
    return detail;
}
exports.detail = detail;
async function edit(id, updates, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
    }
    const oldObject = await model_1.RiskSchema.findById(id).exec();
    if (Object.keys(updates).includes('impact')) {
        if (oldObject.impact != updates.impact) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    if (Object.keys(updates).includes('probability')) {
        if (oldObject.probability != updates.probability) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    let riskDetails = await model_1.RiskSchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
    await model_1.RiskSchema.create(Object.assign({}, riskDetails, { parentId: riskDetails._id }));
    return riskDetails;
}
exports.edit = edit;
async function riskSaveAll(projectId, updateObjs, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
        await Promise.all(updateObjs.map((riskObj) => saveaAll(riskObj, projectId, userObj)));
        return { message: "Saved successfully" };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.riskSaveAll = riskSaveAll;
;
async function saveaAll(riskObj, projectId, userObj) {
    try {
        if ("_id" in riskObj || "id" in riskObj) {
            const oldObject = await model_1.RiskSchema.findById(riskObj._id || riskObj.id).exec();
            if (Object.keys(riskObj).some(key => riskObj[key] != oldObject[key])) {
                if (!riskObj.riskTrend && riskObj.riskTrend != 0) {
                    riskObj.riskTrend = 0;
                }
                else {
                    let lastUpdatedObj = (await model_1.RiskSchema.find({ parentId: riskObj._id || riskObj.id })).pop();
                    riskObj.riskTrend = Math.abs((lastUpdatedObj.impact || 0) * (lastUpdatedObj.probability || 0) - (riskObj.impact || 0) * (riskObj.probability || 0));
                }
                if (Object.keys(riskObj).includes('impact'))
                    if (oldObject.impact != riskObj.impact)
                        riskObj['previousTrend'] = oldObject.impact * oldObject.probability;
                if (Object.keys(riskObj).includes('probability'))
                    if (oldObject.probability != riskObj.probability)
                        riskObj['previousTrend'] = oldObject.impact * oldObject.probability;
                let riskDetails = await model_1.RiskSchema.findByIdAndUpdate(riskObj._id || riskObj.id, { $set: riskObj }, { new: true }).exec();
                await model_1.RiskSchema.create(Object.assign({}, riskDetails.toJSON(), { projectId, parentId: riskDetails._id }));
            }
            ;
        }
        else {
            let risk = await model_1.RiskSchema.create(Object.assign({}, riskObj, { projectId, createdBy: userObj._id }));
            await model_1.RiskSchema.create(Object.assign({}, riskObj, { parentId: risk._id, projectId, createdBy: userObj._id }));
        }
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function logList(projectId, riskId) {
    return await model_1.RiskSchema.find({ deleted: false, projectId, parentId: riskId }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
}
exports.logList = logList;
