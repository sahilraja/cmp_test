"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const request = require("request-promise");
const http = require("http");
const urls_1 = require("./urls");
const USERS_URL = process.env.USERS_URL || "http://localhost:4000";
const FILE_SERVICE_URL = process.env.FILE_SERVICE_URL || "http://localhost:4040";
// create user
async function createUser(body) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/create`,
            method: "POST",
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.createUser = createUser;
;
// user Login
async function userLogin(body) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/login`,
            method: "POST",
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userLogin = userLogin;
;
async function validateUserCurrentPassword(userId, password) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/compare-password/${userId}`,
            method: "POST",
            body: { password },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.validateUserCurrentPassword = validateUserCurrentPassword;
;
// user find One
async function userFindOne(key, value, selectFields) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/findOne`,
            method: "POST",
            body: { key, value, selectFields: selectFields || {} },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userFindOne = userFindOne;
;
async function changeEmailRoute(userId, objBody) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/changeEmail/${userId}`,
            method: "POST",
            body: objBody,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changeEmailRoute = changeEmailRoute;
async function userUpdate(objBody) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/update`,
            method: "POST",
            body: objBody,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userUpdate = userUpdate;
;
// user Login
async function userFindMany(key, value, selectFields) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/findMany`,
            method: "POST",
            body: {
                key,
                value,
                selectFields: selectFields || {}
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userFindMany = userFindMany;
;
async function getNamePatternMatch(queryString, selectFields) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/patternMatch`,
            method: "POST",
            body: {
                searchKeys: ['name', 'firstName', 'lastName', 'middleName', 'secondName'],
                searchQuery: queryString,
                selectFields: selectFields || {}
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getNamePatternMatch = getNamePatternMatch;
// user List
async function userList(searchQuery, selectFields) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/list`,
            method: "POST",
            body: {
                searchQuery: searchQuery,
                selectFields: selectFields || {}
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userList = userList;
;
async function userListForHome(searchQuery) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/homepage-search?search=${searchQuery}`,
            method: "GET",
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userListForHome = userListForHome;
;
async function verifyJWT(token) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/verifyJWT`,
            method: "POST",
            body: { token },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.verifyJWT = verifyJWT;
;
async function createJWT(payload) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/createToken`,
            method: "POST",
            body: payload,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.createJWT = createJWT;
;
async function userEdit(userId, payload) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/${userId}/edit`,
            method: "POST",
            body: payload,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userEdit = userEdit;
;
async function userPaginatedList(searchQuery, selectFields, page, limit, sort, ascending) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/paginatedList`,
            method: "POST",
            body: { searchQuery, selectFields, page, limit, sort, ascending },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userPaginatedList = userPaginatedList;
;
async function userDelete(userId) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/${userId}`,
            method: "DELETE",
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userDelete = userDelete;
;
async function uploadPhoto(request) {
    const options = {
        hostname: 'localhost',
        port: 4040,
        path: '/photo',
        method: 'POST',
        headers: request.headers
    };
    return new Promise((resolve, reject) => {
        const req = http.request(options, res => {
            // response.writeHead(200, res.headers);
            res.setEncoding('utf8');
            let content = '';
            res.on('data', (chunk) => {
                content += chunk;
            });
            res.on('end', () => {
                resolve(content);
            });
        });
        req.on('error', (e) => {
            console.error(e);
        });
        request.pipe(req);
    });
}
exports.uploadPhoto = uploadPhoto;
async function changePasswordInfo(payload, userId) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/changePassword/${userId}`,
            method: "POST",
            body: payload,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.changePasswordInfo = changePasswordInfo;
;
//  Create Group Record in Users module
async function groupCreate(payload) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/create`,
            method: "POST",
            body: payload,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupCreate = groupCreate;
;
//  Get Group List From User Module  
async function groupsFindMany(key, value) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/findMany`,
            method: "POST",
            body: { key, value },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupsFindMany = groupsFindMany;
;
//  Get Group List From User Module  
async function listGroup(searchQuery, selectFields, sort) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/list`,
            method: "POST",
            body: { searchQuery, selectFields: selectFields || {}, sort: sort || undefined },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.listGroup = listGroup;
;
//  Get Group List From User Module  
async function groupPatternMatch(searchQuery, patternQuery, objectQuery, selectFields, sort) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/Pattern-match`,
            method: "POST",
            body: {
                searchQuery: searchQuery || {},
                patternQuery: patternQuery || {},
                objectQuery: objectQuery || {},
                selectFields: selectFields || {},
                sort: sort || undefined
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupPatternMatch = groupPatternMatch;
;
//  Get Group List From User Module  
async function groupUpdateMany(searchQuery, updateData, patternQuery) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/updateMany`,
            method: "POST",
            body: {
                searchQuery: searchQuery || {},
                patternQuery: patternQuery || {},
                updateData: updateData || {}
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupUpdateMany = groupUpdateMany;
;
//  Get Group Document from user Module
async function groupFindOne(key, value, selectFields) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/findOne`,
            method: "POST",
            body: { key, value, selectFields: selectFields || {} },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupFindOne = groupFindOne;
;
//  Edit Group Details in users Module
async function groupEdit(groupId, payload) {
    try {
        let Options = {
            uri: `${USERS_URL}/group/${groupId}/edit`,
            method: "PUT",
            body: payload,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupEdit = groupEdit;
;
async function otpVerify(objBody) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/otpVerify`,
            method: "POST",
            body: objBody,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.otpVerify = otpVerify;
;
async function searchByname(search) {
    try {
        let Options = {
            uri: `${USERS_URL}/user/search?search=${search}`,
            method: "GET",
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.searchByname = searchByname;
;
async function getTasksByIds(taskIds, token) {
    try {
        const options = {
            uri: `${urls_1.TASKS_URL}/task/getByIds`,
            method: 'POST',
            json: true,
            headers: { 'Authorization': `Bearer ${token}` },
            body: { taskIds }
        };
        return await request(options);
    }
    catch (error) {
        throw error;
    }
}
exports.getTasksByIds = getTasksByIds;
async function smsRequest(mobileNo, smsContent) {
    try {
        const options = {
            url: `http://mobicomm.dove-sms.com//submitsms.jsp?user=NationalIN&key=04f397d2daXX&mobile=${mobileNo}&message=${smsContent}&senderid=NTFSMS&accusage=1`,
            method: 'GET',
            json: true
        };
        return await request(options);
    }
    catch (error) {
        throw error;
    }
}
exports.smsRequest = smsRequest;
async function internationalSmsRequest(mobileNo, smsContent) {
    try {
        const options = {
            url: `http://95.216.8.124:8787/msg//submitsms.jsp?user=nainuras&key=9d67e9da3bXX&mobile=${mobileNo}&message=${smsContent}&senderid=INFOSM&accusage=3`,
            method: 'GET',
            json: true
        };
        return await request(options);
    }
    catch (error) {
        throw error;
    }
}
exports.internationalSmsRequest = internationalSmsRequest;
