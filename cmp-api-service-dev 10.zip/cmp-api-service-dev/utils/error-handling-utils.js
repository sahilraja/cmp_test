"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const custom_error_1 = require("./custom-error");
function processMongooseErrors(error) {
    if (!error.errors) {
        return error;
    }
    return Object.keys(error.errors).map(key => {
        if (error.errors[key].kind == 'enum') {
            error.errors[key].message = `Please enter valid data for ${key}`;
        }
        var keys = key.split(".").pop();
        if (!error.errors[key].errors) {
            return new custom_error_1.APIError(error.errors[key].message || `Invalid ${keys}`);
        }
        // checking for innerSchema errors
        if (error.errors[key].errors) {
            return Object.keys(error.errors[key].errors).map(innerKey => {
                if (error.errors[key].errors[innerKey].kind == 'enum') {
                    error.errors[key].errors[innerKey].message = `Please enter valid data for ${innerKey}`;
                }
                return new custom_error_1.APIError(error.errors[key].errors[innerKey].message);
            });
        }
        return new custom_error_1.APIError(error.errors[key].message);
    });
}
exports.processMongooseErrors = processMongooseErrors;
function processErrors(errors) {
    if (!Array.isArray(errors)) {
        errors = [errors];
    }
    return errors.reduce((prev, current) => {
        if (current instanceof custom_error_1.APIError) {
            prev[(current.key)] = current.message;
            if (current.code) {
                prev['code'] = current.code;
            }
            return prev;
        }
        else {
            prev['__globals'] = (prev['__globals'] || []).concat(current.message);
            return prev;
        }
    }, {});
}
exports.processErrors = processErrors;
