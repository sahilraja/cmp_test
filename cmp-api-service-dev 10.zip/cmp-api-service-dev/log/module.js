"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const users_1 = require("../utils/users");
const mongoose_1 = require("mongoose");
const tag_model_1 = require("../tags/tag_model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
async function create(payload) {
    return await model_1.ActivitySchema.create(payload);
}
exports.create = create;
async function list(query = {}) {
    return await model_1.ActivitySchema.find(query).exec();
}
exports.list = list;
async function detail(id) {
    return await model_1.ActivitySchema.findById(id).exec();
}
exports.detail = detail;
async function edit(id, updates) {
    return await model_1.ActivitySchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
}
exports.edit = edit;
async function paginatedList(query = {}, page = 1, limit = 20) {
    return await model_1.ActivitySchema.paginate(query, { page, limit });
}
exports.paginatedList = paginatedList;
async function getTaskLogs(taskId, token, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `view-activity-log`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    const activities = await model_1.ActivitySchema.find({ taskId }).sort({ createdAt: 1 }).exec();
    const userIds = activities.reduce((p, activity) => [...p, ...((activity.addedUserIds || []).concat(activity.removedUserIds || []).concat([activity.activityBy]))
    ], []).filter((v) => v);
    const subTaskIds = activities.reduce((p, activity) => {
        p = p.concat([activity.subTask, ...(activity.linkedTasks || []), ...(activity.unlinkedTasks || [])]);
        return p;
    }, []).filter((v) => !!v);
    const [usersInfo, subTasks] = await Promise.all([
        users_1.userFindMany('_id', userIds, { firstName: 1, lastName: 1, middleName: 1, email: 1, phoneNumber: 1, countryCode: 1, profilePic: 1, phone: 1, is_active: 1 }),
        users_1.getTasksByIds(subTaskIds, token)
    ]);
    const tagObjects = await tag_model_1.tags.find({ _id: { $in: [...new Set(activities.reduce((main, curr) => [...main, ...(curr.tagsAdded || []), ...(curr.tagsRemoved || [])], []))] } }).exec();
    return activities.map((activity) => (Object.assign({}, activity.toJSON(), { subTask: subTasks.find((subTask) => subTask._id == activity.subTask), linkedTasks: subTasks.filter((subTask) => (activity.linkedTasks || []).includes(subTask._id)), unlinkedTasks: subTasks.filter((subTask) => (activity.unlinkedTasks || []).includes(subTask._id)), activityBy: usersInfo.find((user) => user._id == activity.activityBy), addedUserIds: usersInfo.filter((s) => (activity.addedUserIds || []).includes(s._id)), removedUserIds: usersInfo.filter((s) => (activity.removedUserIds || []).includes(s._id)), tagsAdded: tagObjects.filter(({ id }) => (activity.tagsAdded || []).includes(id)), tagsRemoved: tagObjects.filter(({ id }) => (activity.tagsRemoved || []).includes(id)) }))).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
}
exports.getTaskLogs = getTaskLogs;
;
async function getDocumentsLogs(docId, token, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `document-activity-log`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
        const select = { name: true, description: true };
        const activities = await model_1.ActivitySchema.find({ documentId: mongoose_1.Types.ObjectId(docId) }).populate([{ path: 'fromPublished', select }, { path: 'fromPublished', select }, { path: "documentId", select }]).exec();
        return await Promise.all(activities.map((activity) => {
            return activityFetchDetails(activity);
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getDocumentsLogs = getDocumentsLogs;
;
async function activityFetchDetails(activity) {
    const userObj = (activity.documentAddedUsers || []).concat(activity.documentRemovedUsers || []).filter(({ type }) => type == "user");
    const groupObj = (activity.documentAddedUsers || []).concat(activity.documentRemovedUsers || []).filter(({ type }) => type == "group");
    const userIds = userObj.reduce((main, curr) => main.concat(curr.id), []);
    const groupIds = groupObj.reduce((main, curr) => main.concat(curr.id), []);
    let groupsData = await users_1.groupPatternMatch({}, {}, { "_id": groupIds }, {});
    let usersData = await users_1.userFindMany('_id', userIds.concat(activity.activityBy), { firstName: 1, lastName: 1, middleName: 1, email: 1, phoneNumber: 1, countryCode: 1, profilePic: 1, phone: 1, is_active: 1 });
    usersData = groupsData.concat(usersData);
    const tagIds = (activity.tagsAdded || []).concat(activity.tagsRemoved || []);
    const tagsData = await tag_model_1.tags.find({ _id: { $in: tagIds } });
    try {
        return Object.assign({}, activity.toJSON(), { activityBy: usersData.find((users) => activity.activityBy == users._id), documentAddedUsers: usersData.filter((obj) => (activity.documentAddedUsers || []).map((d) => d.id).includes(obj._id)), documentRemovedUsers: usersData.filter((obj) => (activity.documentRemovedUsers || []).map((d) => d.id).includes(obj._id)), tagsAdded: tagsData.filter((obj) => (activity.tagsAdded || []).includes(obj.id)), tagsRemoved: tagsData.filter((obj) => (activity.tagsRemoved || []).includes(obj.id)) });
    }
    catch (err) {
        throw err;
    }
}
async function getProfileLogs(profileId, token) {
    try {
        const activities = await model_1.ActivitySchema.find({ profileId: mongoose_1.Types.ObjectId(profileId) }).exec();
        return await Promise.all(activities.map((activity) => {
            return profileFetchDetails(activity.toJSON());
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getProfileLogs = getProfileLogs;
;
async function profileFetchDetails(activity) {
    try {
        let userObj = (activity.profileId) ? await users_1.userFindMany("_id", [activity.activityBy, activity.profileId]) : await users_1.userFindMany("_id", [activity.activityBy]);
        return Object.assign({}, activity, { activityBy: userObj.find((users) => activity.activityBy == users._id), profileId: (activity.profileId) ? Object.assign({ firstName: '', lastName: '', middleName: '', email: '' }, userObj.find((users) => activity.profileId == users._id)) : "" });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function getMergedLogs() {
    try {
        const activities = await model_1.ActivitySchema.find({ activityType: "MERGED-TAG" }, { activityType: 1, activityBy: 1, mergedTag: 1, tagsToMerge: 1, updatedAt: 1, createdAt: 1 }).exec();
        return await Promise.all(activities.map((activity) => {
            return profileFetchDetails(activity.toJSON());
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getMergedLogs = getMergedLogs;
async function projectLogs(projectId, token, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `project-activity-log`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
        const activities = await model_1.ActivitySchema.find({ projectId }).populate({ path: 'projectId' }).exec();
        let taskObjects = await users_1.getTasksByIds([...new Set((activities.reduce((main, curr) => main.concat([curr.taskId]), [])).filter((id) => mongoose_1.Types.ObjectId(id)))], token);
        return await Promise.all(activities.map((activity) => {
            return fetchProjectLogDetails(activity.toJSON(), taskObjects);
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.projectLogs = projectLogs;
async function fetchProjectLogDetails(activity, taskObjects) {
    try {
        let userObj = await users_1.userFindMany("_id", [activity.activityBy, ...(activity.addedUserIds || []), ...(activity.removedUserIds || [])]);
        return Object.assign({}, activity, { activityBy: userObj.find(({ _id }) => _id == activity.activityBy), addedUserIds: userObj.filter(({ _id }) => (activity.addedUserIds || []).includes(_id)), removedUserIds: userObj.filter(({ _id }) => (activity.removedUserIds || []).includes(_id)), taskId: taskObjects.find(({ _id }) => activity.taskId == _id) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
function getFormantedDocLogs(activityLog) {
    switch (activityLog.activityType) {
        case 'DOCUMENT_CREATED':
            return `${UserFullName(activityLog.activityBy)} created the document`;
        case 'DOCUMENT_UPDATED':
            return `${UserFullName(activityLog.activityBy)} updated the document`;
        case 'CANCEL_UPDATED':
            return `${UserFullName(activityLog.activityBy)} canceled the document update`;
        case 'TAGS_ADDED':
            return `${UserFullName(activityLog.activityBy)} added tags ${getTagName(activityLog.tagsAdded)} to the document`;
        case 'TAGS_REMOVED':
            return `${UserFullName(activityLog.activityBy)} removed tags ${getTagName(activityLog.tagsRemoved)} to the document`;
        case 'MODIFIED_USER_SHARED_AS_VIEWER':
            return `${UserFullName(activityLog.activityBy)} modified document access from collaborator to viewer to ${getNamesFromIds(activityLog.documentAddedUsers)}`;
        case 'MODIFIED_USER_SHARED_AS_COLLABORATOR':
            return `${UserFullName(activityLog.activityBy)} modified document access from viewer to collaborator to ${getNamesFromIds(activityLog.documentAddedUsers)}`;
        case 'MODIFIED_GROUP_SHARED_AS_VIEWER':
            return `${UserFullName(activityLog.activityBy)} modified document access from collaborator to viewer to ${getNamesFromIds(activityLog.documentAddedUsers)}`;
        case 'MODIFIED_GROUP_SHARED_AS_COLLABORATOR':
            return `${UserFullName(activityLog.activityBy)} modified document access from viewer to collaborator to ${getNamesFromIds(activityLog.documentAddedUsers)}`;
        case 'DOCUMENT_SHARED_AS_VIEWER':
            return `${UserFullName(activityLog.activityBy)} shared document to ${getNamesFromIds(activityLog.documentAddedUsers)} with view access`;
        case 'DOCUMENT_SHARED_AS_COLLABORATOR':
            return `${UserFullName(activityLog.activityBy)} shared document to ${getNamesFromIds(activityLog.documentAddedUsers)} with edit access`;
        case 'REMOVED_USER_FROM_DOCUMENT':
            return `${UserFullName(activityLog.activityBy)} removed access to the document to ${getNamesFromIds(activityLog.documentRemovedUsers)}`;
        case 'REMOVED_GROUP_FROM_DOCUMENT':
            return `${UserFullName(activityLog.activityBy)} removed access to the document to ${getNamesFromIds(activityLog.documentRemovedUsers)}`;
        case 'DOUCMENT_PUBLISHED':
            return `${UserFullName(activityLog.activityBy)} published the document`;
        case 'DOUCMENT_UNPUBLISHED':
            return `${UserFullName(activityLog.activityBy)} unpublished the document`;
        case 'DOUCMENT_REPLACED':
            return `${UserFullName(activityLog.activityBy)} replaced the document`;
        case 'DOCUMENT_DELETED':
            return `${UserFullName(activityLog.activityBy)} deleted the document`;
        case 'DOCUMENT_VIEWED':
            return `${UserFullName(activityLog.activityBy)} viewed the document`;
        case 'DOCUMENT_COMMENT':
            return `${UserFullName(activityLog.activityBy)} added a comment`;
        case 'DOCUMENT_DOWNLOAD':
            return `${UserFullName(activityLog.activityBy)} Dowloaded a document`;
        case "TAGS_ADD_AND_REMOVED":
            return `${UserFullName(activityLog.activityBy)} added tags ${getTagName(activityLog.tagsAdded)} to the document and removed tags ${getTagName(activityLog.tagsRemoved)} to  the document`;
        default:
            return;
    }
}
function UserFullName({ firstName, middleName, lastName }) {
    return (firstName ? firstName + " " : "") + (middleName ? middleName + " " : "") + (lastName ? lastName : "");
}
function getTagName(tagsArr) {
    let namesArr = [];
    let namesStr;
    tagsArr.map(item => {
        namesArr.push(item.tag);
    });
    namesStr = namesArr.join();
    return namesStr;
}
function getNamesFromIds(userIdsArr) {
    let namesArr = [];
    let namesStr;
    userIdsArr.map((item) => {
        if (item.firstName && item.lastName) {
            namesArr.push(`${item.firstName} ${item.lastName} `);
        }
        else {
            namesArr.push(item.name);
        }
    });
    namesStr = namesArr.join();
    return namesStr;
}
