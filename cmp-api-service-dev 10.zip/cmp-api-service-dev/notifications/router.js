"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const custom_error_1 = require("../utils/custom-error");
const router = express_1.Router();
router.post("/update", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.notificationsUpdate(req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/list", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getNotifications());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/role/add", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addRoleNotification(req.body.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/template/add", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addTemplateNotification(req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/getNotification", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getRoleNotification(req.query.role, req.query.templateName));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/getNotification/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.userRolesNotification(req.params.id, req.query.templateName));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
