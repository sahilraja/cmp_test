"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    type: { type: String, enum: ["LOGIN", "LOGOUT"] },
    userId: { type: String },
    ip: { type: String }
}, { timestamps: true });
schema.index({ userId: 1 });
schema.plugin(mongoosePaginate);
exports.loginSchema = mongoose_1.model("login_time", schema);
