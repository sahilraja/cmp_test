"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    content: { type: String },
    templateName: { type: String, unique: true },
    displayName: { type: String },
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.smsTemplateSchema = mongoose_1.model("sms_template", schema);
