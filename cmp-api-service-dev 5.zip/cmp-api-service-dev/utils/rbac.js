"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const request = require("request-promise");
const urls_1 = require("./urls");
//  Add Roles In Rbac
async function addRole(userId, role, scope = "global") {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/add/${userId}`,
            method: "POST",
            body: {
                "role": role,
                "scope": scope
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.addRole = addRole;
;
async function updateRole(userId, updateRole, deleteRole, scope = "global") {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/update/${userId}`,
            method: "POST",
            body: {
                "updateRole": updateRole,
                "scope": scope,
                "deleteRole": deleteRole
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.updateRole = updateRole;
;
async function revokeRole(userId, revokeRole, scope = "global") {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/revoke/${userId}`,
            method: "PUT",
            body: {
                "scope": scope,
                "role": revokeRole
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.revokeRole = revokeRole;
;
//  Get Roles Of User
async function getRoles(userId) {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/list/${userId}`,
            method: "GET",
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getRoles = getRoles;
;
//  Get Role Capabilities
async function roleCapabilitylist(role) {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/capabilities/list`,
            method: "GET",
            qs: {
                role: role
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.roleCapabilitylist = roleCapabilitylist;
;
//  Check Capabilities
async function checkCapability(object) {
    try {
        const { role, scope, capability } = object;
        let Options = {
            uri: `${urls_1.RBAC_URL}/capabilities/check`,
            method: "GET",
            qs: {
                role: role,
                scope: scope,
                capability: capability
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.checkCapability = checkCapability;
;
//  Role Users List
async function roleUsersList(role) {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/user/list`,
            method: "GET",
            qs: {
                role: role,
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.roleUsersList = roleUsersList;
;
