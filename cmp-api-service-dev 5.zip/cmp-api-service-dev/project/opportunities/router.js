"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const custom_error_1 = require("../../utils/custom-error");
const router = express_1.Router();
router.post(`/:id/opportunity/create`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.create(req.body, req.params.id, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/opportunity/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/opportunity/edit/save-all`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.opportunitySaveAll(req.params.id, req.body.saveAll, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.get(`/:id/opportunity/:opportunity_id/edit-history/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.logList(req.params.id, req.params.opportunity_id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.get(`/:id/opportunity/:opportunity_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.detail(req.params.opportunity_id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/opportunity/:opportunity_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit(req.params.opportunity_id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.delete(`/:id/opportunity/:opportunity_id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit(req.params.opportunity_id, { deleted: true }, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
