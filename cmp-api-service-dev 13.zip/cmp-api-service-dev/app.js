"use strict";
const express = require("express");
const http_status_codes_1 = require("http-status-codes");
const bodyParser = require("body-parser");
const cors = require("cors");
const node_1 = require("@sentry/node");
node_1.init({ dsn: 'https://a5929734fe1748df85c79e15836e1c93@sentry.io/1878141' });
//  module imports
const usersRouter = require("./users/router");
const roleRouter = require("./role/router");
const projectRouter = require("./project/router");
const documentRouter = require("./documents/router");
const taskRouter = require("./task/router");
const tagRouter = require("./tags/router");
const templateRouter = require("./email-templates/router");
const commentRouter = require("./comments/router");
const pillarRouter = require("./pillars/router");
const stepRouter = require("./steps/router");
const privateGroup = require("./private-groups/router");
const activityRouter = require("./log/router");
const constantsRouter = require("./site-constants/router");
const phaseRouter = require("./phase/router");
const notificationsRouter = require("./notifications/router");
const patternRouter = require("./patterns/router");
const smsRouter = require("./sms/router");
const miscellaneousRouter = require("./miscellaneous/router");
const webNotificationRouter = require("./socket-notifications/router");
// implement multer
const multer = require("multer");
const utils_1 = require("./utils/utils");
var upload = multer({ dest: 'uploads/' });
const app = express();
//  implement cors
app.use(cors());
//  mongoose connection
require('./utils/mongoose');
//  swagger implementation
const swaggerUi = require("swagger-ui-express");
const YAML = require("yamljs");
const swaggerDocument = YAML.load("./compiled-swagger.yaml");
// body paser
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.use((req, res, next) => {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    res.header('Expires', '-1');
    res.header('Pragma', 'no-cache');
    next();
});
//  Hello world Router
app.get('/', (request, response) => {
    response.status(http_status_codes_1.OK).send("Hello World");
});
//  Middleware
app.use("/api-docs", swaggerUi.serve, swaggerUi.setup(swaggerDocument));
app.use('/user', usersRouter);
app.use("/role", roleRouter);
app.use("/project", utils_1.authenticate, projectRouter);
app.use("/docs", documentRouter);
app.use("/task", taskRouter);
app.use("/tag", tagRouter);
app.use("/pattern", patternRouter);
app.use("/template", templateRouter);
app.use("/comments", utils_1.authenticate, commentRouter);
app.use(`/pillars`, utils_1.authenticate, pillarRouter);
app.use(`/steps`, utils_1.authenticate, stepRouter);
app.use(`/private-group`, privateGroup);
app.use(`/activity`, activityRouter);
app.use('/constants', constantsRouter);
app.use('/phases', utils_1.authenticate, phaseRouter);
app.use('/notifications/', utils_1.authenticate, notificationsRouter);
app.use('/sms', smsRouter);
app.use(`/miscellaneous`, miscellaneousRouter);
app.use(`/web-notifications`, webNotificationRouter);
app.use((error, request, response, next) => {
    console.log(error.code, `Error Code`);
    if (error.code >= 500) {
        node_1.captureException(error);
    }
    response.status(error.code < 600 ? error.code : http_status_codes_1.INTERNAL_SERVER_ERROR || http_status_codes_1.INTERNAL_SERVER_ERROR).send({ errors: [{ error: error.message || error.error }] });
});
module.exports = app;
