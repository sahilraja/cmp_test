"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const error_msg_1 = require("../utils/error_msg");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const model_1 = require("./model");
;
const patternRegex = /%[A-Za-z0-9]{3,}%$/;
//  create pattern
async function patternCreate(body, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, "patterns-management");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.PATTERNS.UNAUTHORIZED, 403);
        if (!body.patternCode || !patternRegex.test(body.patternCode) || !body.patternName)
            throw new Error(error_msg_1.PATTERNS.INVALID_OR_MISSING_DATA);
        let existPattern = await model_1.patternSchema.find({ patternCode: body.patternCode, isDeleted: false });
        if (existPattern.length)
            throw new Error(error_msg_1.PATTERNS.PATTERN_WITH_SAME_NAME);
        return model_1.patternSchema.create(Object.assign({}, body, { createdBy: userObj._id }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.patternCreate = patternCreate;
;
//  edit Pattern
async function patternEdit(patternId, body, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, "patterns-management");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.PATTERNS.UNAUTHORIZED, 403);
        let patternDetails = await model_1.patternSchema.findById(patternId).exec();
        if (!patternDetails)
            throw new Error(error_msg_1.PATTERNS.PATTERNS_DETAILS_NOT_FOUND);
        if (!body.patternCode || !patternRegex.test(body.patternCode) || !body.patternName)
            throw new Error(error_msg_1.PATTERNS.INVALID_OR_MISSING_DATA);
        let existPattern = await model_1.patternSchema.findOne({ patternCode: body.patternCode, isDeleted: false });
        if (existPattern && existPattern._id != patternId)
            throw new Error(error_msg_1.PATTERNS.PATTERN_WITH_SAME_NAME);
        return await model_1.patternSchema.findByIdAndUpdate(patternId, { $set: Object.assign({}, body) });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.patternEdit = patternEdit;
;
//  change pattern status
async function patternDelete(patternId, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, "patterns-management");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.PATTERNS.UNAUTHORIZED, 403);
        let patternDetails = await model_1.patternSchema.findById(patternId).exec();
        if (!patternDetails)
            throw new Error(error_msg_1.PATTERNS.PATTERNS_DETAILS_NOT_FOUND);
        let data = await model_1.patternSchema.findByIdAndUpdate(patternId, { $set: { isDeleted: patternDetails.isDeleted ? false : true } });
        return { message: data.isDeleted ? error_msg_1.RESPONSE.INACTIVE : error_msg_1.RESPONSE.ACTIVE };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.patternDelete = patternDelete;
;
//  Get Group Detail
async function patternDetails(patternId) {
    try {
        return await model_1.patternSchema.findById(patternId).exec();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.patternDetails = patternDetails;
;
//  Get Group Detail
async function patternList(userObj, search) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, "patterns-management");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.PATTERNS.UNAUTHORIZED, 403);
        let searchQuery = search ? { name: new RegExp(search, "i"), isDeleted: false } : { isDeleted: false };
        return await model_1.patternSchema.find(Object.assign({}, searchQuery)).exec();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.patternList = patternList;
;
async function patternSubstitutions(message) {
    try {
        let allPatternCodes = message.match(/%(.*?)%/g);
        if (!allPatternCodes)
            return { message };
        var allPatterns = await model_1.patternSchema.find({ patternCode: { $in: allPatternCodes }, isDeleted: false }).exec();
        for (const { patternCode, patternName } of allPatterns) {
            message = replaceAll(message, patternCode, patternName);
        }
        return { message };
    }
    catch (err) {
        throw err;
    }
}
exports.patternSubstitutions = patternSubstitutions;
function replaceAll(message, search, replacement) {
    return message.split(search).join(replacement);
}
exports.replaceAll = replaceAll;
