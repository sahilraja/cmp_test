"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let SchemaDef = new mongoose_1.Schema({
    userId: { type: String },
    isParent: { type: Boolean, default: false },
    text: { type: String },
    projectId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'project' }
}, { timestamps: true });
SchemaDef.index({ userId: 1 });
SchemaDef.index({ projectId: 1 });
SchemaDef.index({ userId: 1, projectId: 1 });
exports.OpenCommentsModel = mongoose_1.model('open_comments', SchemaDef);
