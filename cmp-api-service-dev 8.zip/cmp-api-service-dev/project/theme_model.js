"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    theme: { type: String, unique: true, trim: true },
    description: { type: String, trim: true },
    is_active: { type: Boolean, default: true }
}, { timestamps: true });
exports.themes = mongoose_1.model("themes", schema);
