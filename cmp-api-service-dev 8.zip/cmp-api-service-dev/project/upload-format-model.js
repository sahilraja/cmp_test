"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let SchemaDef = new mongoose_1.Schema({
    name: { type: String },
    type: { type: String },
    fileId: { type: String }
});
SchemaDef.index({ type: 1 });
exports.UploadFormatSchema = mongoose_1.model('upload_formats', SchemaDef);
