"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    tag: { type: String, unique: true, trim: true },
    description: { type: String, trim: true },
    is_active: { type: Boolean, default: true },
    deleted: { type: Boolean, default: false }
}, { timestamps: true });
exports.tags = mongoose_1.model("tags", schema);
