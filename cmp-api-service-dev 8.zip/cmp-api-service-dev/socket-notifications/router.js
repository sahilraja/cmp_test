"use strict";
const express_1 = require("express");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const utils_1 = require("../utils/utils");
const socket_1 = require("../socket");
const router = express_1.Router();
router.post(`/create`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.create(req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/list`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list(res.locals.user._id, req.query.page, req.query.limit, req.token));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/unread-notifications`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.listUnreadNotifications(res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/unread-inbox`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await socket_1.emitLatestInboxCount(req.query.userId));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/detail`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send({});
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/mark-as-read`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.markAsRead(req.params.id, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
