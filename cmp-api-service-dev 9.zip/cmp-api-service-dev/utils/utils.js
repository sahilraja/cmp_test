"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const jsonwebtoken_1 = require("jsonwebtoken");
const bcrypt = require("bcryptjs");
const error_msg_1 = require("./error_msg");
const users_1 = require("./users");
const module_1 = require("../role/module");
const custom_error_1 = require("./custom-error");
const TASK_URL = process.env.TASK_HOST || "http://localhost:5052";
const request = require("request-promise");
const msg91 = require("msg91");
const SendOtp = require("sendotp");
const phoneNo = require("phone");
const module_2 = require("../site-constants/module");
const module_3 = require("../users/module");
const refresh_token_model_1 = require("../users/refresh-token-model");
const SECRET = "CMP_SECRET";
const ACCESS_TOKEN_LIFETIME = '365d';
const SALTROUNDS = 10;
const MSG_API_KEY = "301746A16myISu5dbc0bc7"; //"9d67e9da3bXX"; //"301746A16myISu5dbc0bc7"; 
const SENDER_ID = "CMPIND"; //"INFOSM";
const ROUTE_NO = "4";
const MSG_EXPIRE_OTP = 15;
const msg = msg91(MSG_API_KEY, SENDER_ID, ROUTE_NO);
const sendOtp = new SendOtp(MSG_API_KEY, 'Your Verification code is {{otp}}');
async function authenticateConstants() {
    let { linkExpire, otpExpire } = await module_2.getConstantsAndValues(['linkExpire', 'otpExpire']);
    return {
        ACCESS_TOKEN_FOR_URL: Number(linkExpire || 1) * 60 * 60,
        ACCESS_TOKEN_FOR_OTP: Number(otpExpire || 1) * 60 * 60
    };
}
exports.authenticateConstants = authenticateConstants;
// User Authentication 
async function authenticate(req, res, next) {
    try {
        if (!req.headers.authorization)
            throw new Error(error_msg_1.AUTHENTICATE_MSG.MISSING_TOKEN);
        let bearerToken = req.headers.authorization.substring(7, req.headers.authorization.length);
        let token = await jwt_Verify(bearerToken);
        if (!token)
            throw new Error(error_msg_1.AUTHENTICATE_MSG.INVALID_TOKEN);
        const user = await users_1.userFindOne("id", token.id);
        if (!user) {
            next(new custom_error_1.APIError(error_msg_1.AUTHENTICATE_MSG.INVALID_LOGIN, 401));
        }
        if (!user.is_active) {
            next(new custom_error_1.APIError(error_msg_1.AUTHENTICATE_MSG.USER_INACTIVE, 401));
        }
        const tokenData = await refresh_token_model_1.RefreshTokenSchema.findOne({ userId: user._id, access_token: bearerToken }).exec();
        let { systemTimeOut } = (await module_2.getConstantsAndValues(["systemTimeOut"]) || 15);
        if (tokenData && new Date(tokenData.lastUsedAt).setMinutes(new Date(tokenData.lastUsedAt).getMinutes() + systemTimeOut) < new Date().getTime()) {
            console.error(`user ${user._id} session inactive from last ${systemTimeOut} `);
            next(new custom_error_1.APIError(`Your session has timed out. Please login again.`, 401));
        }
        if (!tokenData)
            next(new custom_error_1.APIError(`Your session has logout. Please login again.`, 401));
        tokenData.set('lastUsedAt', new Date());
        await tokenData.save();
        user.role = (((await module_1.userRoleAndScope(token.id))).data || [""])[0];
        res.locals.user = user;
        req.token = bearerToken;
        req.rootPath = [];
        return next();
    }
    catch (err) {
        return next(new custom_error_1.APIError('Unauthorized'));
    }
    ;
}
exports.authenticate = authenticate;
;
//  Hash password
function hashPassword(password) {
    try {
        return bcrypt.hashSync(password, SALTROUNDS);
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.hashPassword = hashPassword;
;
//  Compare Password
function comparePassword(password, hash_password) {
    try {
        return bcrypt.compareSync(password, hash_password);
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.comparePassword = comparePassword;
;
//  Create JWT life time
async function jwt_create(id) {
    return await jsonwebtoken_1.sign(id, SECRET, { expiresIn: ACCESS_TOKEN_LIFETIME });
}
exports.jwt_create = jwt_create;
;
//  Create JWT One Day
async function jwt_for_url(id) {
    const { ACCESS_TOKEN_FOR_URL } = await authenticateConstants();
    return await jsonwebtoken_1.sign(id, SECRET, { expiresIn: ACCESS_TOKEN_FOR_URL });
}
exports.jwt_for_url = jwt_for_url;
;
//  JWT VERIFY
async function jwt_Verify(id) {
    try {
        return jsonwebtoken_1.verify(id, SECRET, function (err, decoded) {
            if (err) {
                if (err.name == "TokenExpiredError") {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.TOKEN_EXPIRED);
                }
                if (err.name == "JsonWebTokenError") {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.TOKEN_INVALID);
                }
            }
            else {
                return decoded;
            }
        });
    }
    catch (err) {
        throw err;
    }
}
exports.jwt_Verify = jwt_Verify;
async function generateOtp(limit, objBody) {
    var characters = '0123456789';
    var charactersLength = characters.length;
    var result = "";
    for (var i = 0; i < limit; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    let authOtp = Object.assign({ "otp": result }, objBody);
    let token = await jwtOtpToken(authOtp);
    return { otp: result, token };
}
exports.generateOtp = generateOtp;
async function generatemobileOtp(limit, objBody) {
    let timestamp = (new Date().getTime()).toString();
    let result = timestamp.slice(timestamp.length - limit, timestamp.length);
    let authOtp = Object.assign({ "smsOtp": result }, objBody);
    let smsToken = await jwtOtpToken(authOtp);
    return { mobileOtp: result, smsToken };
}
exports.generatemobileOtp = generatemobileOtp;
async function jwtOtpToken(otp) {
    const { ACCESS_TOKEN_FOR_OTP } = await authenticateConstants();
    return await jsonwebtoken_1.sign(otp, SECRET, { expiresIn: ACCESS_TOKEN_FOR_OTP });
}
exports.jwtOtpToken = jwtOtpToken;
// verify token for otp
async function jwtOtpVerify(otp) {
    try {
        return await jsonwebtoken_1.verify(otp, SECRET, function (err, decoded) {
            if (err) {
                if (err.name == "TokenExpiredError") {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.TOKEN_EXPIRED_OTP);
                }
                if (err.name == "JsonWebTokenError") {
                    throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.TOKEN_INVALID);
                }
            }
            else {
                return decoded;
            }
        });
    }
    catch (err) {
        throw err;
    }
}
exports.jwtOtpVerify = jwtOtpVerify;
async function mobileSendOtp(mobileNo, id) {
    try {
        let user = await users_1.userFindOne('id', id);
        return await sendMobileOtp(mobileNo, user);
    }
    catch (err) {
        throw err;
    }
}
exports.mobileSendOtp = mobileSendOtp;
async function mobileVerifyOtp(mobileNo, otp, id) {
    try {
        let userInfo = await users_1.userFindOne('id', id);
        let mobileToken = await jwtOtpVerify(userInfo.smsOtpToken);
        if (otp != "1111") {
            if (mobileToken.smsOtp != otp) {
                throw new custom_error_1.APIError(error_msg_1.MOBILE_MESSAGES.INVALID_OTP);
            }
        }
        return { message: error_msg_1.MOBILE_MESSAGES.VALID_OTP };
    }
    catch (err) {
        throw err;
    }
}
exports.mobileVerifyOtp = mobileVerifyOtp;
//resend otp 
async function mobileRetryOtp(mobileNo, id) {
    let user = await users_1.userFindOne('id', id);
    return await mobileSendOtp(mobileNo, user);
}
exports.mobileRetryOtp = mobileRetryOtp;
function mobileSendMessage(mobileNo, senderId) {
    try {
        if (!phoneNo(mobileNo).length) {
            throw new Error(error_msg_1.USER_ROUTER.VALID_PHONE_NO);
        }
        msg.send(mobileNo, senderId, function (err, response) {
            console.log("err: ", err);
            console.log("result :", response);
        });
    }
    catch (err) {
        throw err;
    }
}
exports.mobileSendMessage = mobileSendMessage;
//sendOtp
async function sendMobileOtp(mobileNo, user) {
    try {
        if (!phoneNo(mobileNo).length) {
            throw new Error(error_msg_1.USER_ROUTER.VALID_PHONE_NO);
        }
        let { mobileOtp, smsToken } = await generatemobileOtp(4);
        await users_1.userUpdate({ id: user._id, smsOtpToken: smsToken });
        module_3.sendNotification({ id: user._id, mobileNo, mobileOtp, mobileTemplateName: "sendOtp" });
        return { message: error_msg_1.MOBILE_MESSAGES.SEND_OTP };
    }
    catch (err) {
        throw err;
    }
}
exports.sendMobileOtp = sendMobileOtp;
// Get group is user ids
async function getTasksForDocument(docId, token) {
    try {
        let Options = {
            uri: `${TASK_URL}/getTasksForDocument/${docId}`,
            headers: { Authorization: `Bearer ${token}` },
            method: "GET",
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getTasksForDocument = getTasksForDocument;
;
function dateDifference(oldDate, newDate) {
    try {
        const date1 = new Date(oldDate);
        const date2 = newDate ? new Date(newDate) : new Date();
        const diffTime = Math.abs(date2 - date1);
        return Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    }
    catch (err) {
        throw err;
    }
}
exports.dateDifference = dateDifference;
