"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePagination = require("mongoose-paginate");
const uniqueValidator = require('mongoose-unique-validator');
const schema = new mongoose_1.Schema({
    name: { type: String, trim: true, required: true, unique: true, uniqueCaseInsensitive: true },
    description: { type: String, trim: true },
    members: { type: Array },
    createdBy: { type: String, required: true },
    is_active: { type: Boolean, default: true }
}, { timestamps: true });
schema.plugin(uniqueValidator, { message: 'Error, expected {PATH} to be unique.' });
schema.plugin(mongoosePagination);
exports.privateGroupSchema = mongoose_1.model("private_group", schema);
