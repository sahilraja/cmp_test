"use strict";
const express_1 = require("express");
const utils_1 = require("../utils/utils");
const custom_error_1 = require("../utils/custom-error");
const mongoose_1 = require("mongoose");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const router = express_1.Router();
//  Pattern Id Validation
router.param("id", async (req, res, next, value) => {
    const patternId = req.params.id;
    try {
        if (!mongoose_1.Types.ObjectId.isValid(patternId))
            throw new Error("Invalid pattern Id.");
        next();
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Create patterns
router.post("/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternCreate(req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get pattern list
router.get("/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternList(res.locals.user, req.query.search));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get pattern list
router.post("/message-modification", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternSubstitutions(req.body.message));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Edit pattern
router.post("/:id/edit", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternEdit(req.params.id, req.body, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Pattern Delete
router.put("/:id/delete", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternDelete(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get Pattern Details
router.get("/:id/details", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.patternDetails(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
module.exports = router;
