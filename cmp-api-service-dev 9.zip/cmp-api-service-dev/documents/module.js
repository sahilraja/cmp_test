"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const folder_model_1 = require("./folder-model");
const http = require("http");
const mongoose_1 = require("mongoose");
const module_1 = require("../role/module");
const tag_model_1 = require("../tags/tag_model");
const theme_model_1 = require("../project/theme_model");
const module_2 = require("../socket-notifications/module");
const web_notification_messages_1 = require("../utils/web-notification-messages");
const groups_1 = require("../utils/groups");
const error_msg_1 = require("../utils/error_msg");
const users_1 = require("../utils/users");
const role_management_1 = require("../utils/role_management");
const systemconfig_1 = require("../utils/systemconfig");
const urls_1 = require("../utils/urls");
const custom_error_1 = require("../utils/custom-error");
const module_3 = require("../log/module");
const module_4 = require("../users/module");
const document_request_model_1 = require("./document-request-model");
const utils_1 = require("../utils/utils");
const module_5 = require("../project/module");
const fs_1 = require("fs");
const path_1 = require("path");
const request = require("request");
const project_model_1 = require("../project/project_model");
var STATUS;
(function (STATUS) {
    STATUS[STATUS["DRAFT"] = 0] = "DRAFT";
    STATUS[STATUS["DONE"] = 1] = "DONE";
    STATUS[STATUS["PUBLISHED"] = 2] = "PUBLISHED";
    STATUS[STATUS["UNPUBLISHED"] = 3] = "UNPUBLISHED";
    //Added FOR backward compatibility
    STATUS[STATUS["APPROVED"] = -1] = "APPROVED";
    STATUS[STATUS["REJECTED"] = -2] = "REJECTED";
    STATUS[STATUS["PENDING"] = -3] = "PENDING";
})(STATUS || (STATUS = {}));
const es = require('elasticsearch');
const esClient = new es.Client({
    host: 'localhost:9200',
    log: 'trace'
});
esClient.ping({
    // ping usually has a 3000ms timeout
    requestTimeout: Infinity
}, function (error) {
    if (error) {
        console.trace('elasticsearch cluster is down!');
    }
    else {
        console.log('All is well');
    }
});
const ELASTIC_SEARCH_INDEX = process.env.ELASTIC_SEARCH_INDEX;
async function createIndex(index) {
    return await esClient.indices.create({ index: index });
}
exports.createIndex = createIndex;
async function removeIndex(index) {
    return await esClient.indices.delete({ index: index });
}
exports.removeIndex = removeIndex;
async function createNewDoc(body, userId, siteConstant, host) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "create-doc");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_PERMISSION, 403);
        }
        if (!Object.keys(body).length || body.upfile == "undefined")
            throw new Error(error_msg_1.DOCUMENT_ROUTER.UNABLE_TO_CREATE);
        const { id: fileId, name: fileName, size: fileSize } = body;
        if (!body.docName)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        // if (!/.*[A-Za-z0-9]{1}.*$/.test(body.docName)) throw new Error(DOCUMENT_ROUTER.NAME_ERROR)
        if (body.docName.length > Number(siteConstant.docNameLength || systemconfig_1.configLimit.name)) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_NAME_LENGTH(siteConstant.docNameLength));
        }
        if (body.description.length > Number(siteConstant.docDescriptionSize || systemconfig_1.configLimit.description)) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_DESCRIPTION_LENGTH(siteConstant.docDescriptionSize));
        }
        let data = await model_1.documents.find({ isDeleted: false, parentId: null, ownerId: userId, codeName: body.docName.toLowerCase() }).exec();
        if (data.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_NAME_UNIQUE(body.docName));
        body.tags = (Array.isArray(body.tags) ? body.tags : typeof (body.tags) == "string" && body.tags.length ? body.tags.includes("[") ? JSON.parse(body.tags) : body.tags = body.tags.split(',') : []).filter((tag) => mongoose_1.Types.ObjectId.isValid(tag));
        if (body.tags && body.tags.length) {
            let isEligible = await role_management_1.checkRoleScope(userRole, "add-tag-to-document");
            if (!isEligible)
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.ADD_TAG_PERMISSION, 403);
        }
        let doc = await insertDOC(body, userId, { fileId: fileId, fileName: fileName, fileSize: fileSize });
        //  Add user as Owner to this Document
        let role = await groups_1.groupsAddPolicy(`user/${userId}`, doc.id, "owner");
        if (!role.user) {
            await model_1.documents.findByIdAndRemove(doc.id);
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CREATE_ROLE_FAIL);
        }
        body.parentId = doc.id;
        let response = await insertDOC(body, userId, { fileId: fileId, fileName: fileName, fileSize: fileSize });
        if (body.folderId) {
            await folder_model_1.folders.update({ _id: body.folderId }, {
                $push: { doc_id: doc.id }
            });
        }
        await module_3.create({ activityType: "DOCUMENT_CREATED", activityBy: userId, tagsAdded: body.tags || [], documentId: doc._id });
        // const insertDoc = async function(indexName, _id, mappingType, data){
        let userDetails = await users_1.userFindOne("id", userId, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
        let userName;
        if (userDetails.firstName)
            userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        else {
            userName = userDetails.name;
        }
        let fileType = doc.fileName ? (doc.fileName.split(".")).pop() : "";
        let thumbnail = (fileType == "jpg" || fileType == "jpeg" || fileType == "png") ? `${host}/api/docs/get-document/${doc.fileId}` : "N/A";
        let tags = await getTags((body.tags && body.tags.length) ? body.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []);
        tags = tags.map((tagData) => { return tagData.tag; });
        let docObj = {
            accessedBy: [userId],
            userName: [userName],
            name: body.docName,
            description: body.description,
            tags: tags,
            thumbnail: thumbnail,
            status: doc.status,
            fileName: doc.fileName,
            updatedAt: doc.updatedAt,
            createdAt: doc.createdAt,
            id: doc.id,
            groupId: [],
            groupName: [],
            createdBy: userId,
            projectName: [],
            city: [],
            reference: [],
            phases: []
        };
        let result = esClient.index({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            body: docObj,
            id: doc.id
        });
        return doc;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.createNewDoc = createNewDoc;
;
//  Create Document
async function createDoc(body, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "create-doc");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_PERMISSION, 403);
        }
        if (!body.name)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        // if (body.name && (!/.*[A-Za-z0-9]{1}.*$/.test(body.name))) throw new Error("you have entered invalid name. please try again.")
        if (body.name.length > systemconfig_1.configLimit.name) { // added config
            throw new Error(error_msg_1.DOCUMENT_ROUTER.LIMIT_EXCEEDED);
        }
        if (body.description.length > systemconfig_1.configLimit.description) { // added config
            throw new Error(error_msg_1.DOCUMENT_ROUTER.LIMIT_EXCEEDED);
        }
        let doc = await insertDOC(body, userId);
        body.parentId = doc.id;
        let role = await groups_1.groupsAddPolicy(`user/${userId}`, doc.id, "owner");
        if (!role.user) {
            await model_1.documents.findByIdAndRemove(doc.id);
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CREATE_ROLE_FAIL);
        }
        let response = await insertDOC(body, userId);
        await module_3.create({ activityType: "DOCUMENT_CREATED", activityBy: userId, tagsAdded: body.tags || [], documentId: doc.id });
        return { doc_id: doc.id };
    }
    catch (error) {
        throw error;
    }
}
exports.createDoc = createDoc;
//  create Document module
async function insertDOC(body, userId, fileObj) {
    try {
        return await model_1.documents.create({
            name: body.docName || body.name,
            codeName: body.docName || body.name,
            description: body.description || null,
            tags: body.tags,
            versionNum: "1",
            status: fileObj ? STATUS.DONE : STATUS.DRAFT,
            ownerId: userId,
            parentId: body.parentId ? body.parentId : null,
            fileId: fileObj ? fileObj.fileId : null,
            fileName: fileObj ? fileObj.fileName : null,
            fileSize: fileObj ? fileObj.fileSize : null
        });
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
//  Get Document Public List
async function getDocList(page = 1, limit = 30, host, pagination = true) {
    try {
        let data = await model_1.documents.find({ parentId: null, status: STATUS.PUBLISHED }).sort({ updatedAt: -1 });
        const docList = await Promise.all(data.map(async (doc) => docData(doc, host)));
        if (pagination) {
            data = documentsSort(data, "name", false);
            return manualPagination(page, limit, docList);
        }
        return docList;
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getDocList = getDocList;
async function documentsList(docs) {
    docs = docs.map((id) => mongoose_1.Types.ObjectId(id));
    return await model_1.documents.find({ _id: { $in: docs } });
}
exports.documentsList = documentsList;
async function docData(docData, host) {
    try {
        let fileType = docData.fileName ? (docData.fileName.split(".")).pop() : "";
        return Object.assign({}, docData.toJSON(), { tags: await getTags((docData.tags && docData.tags.length) ? docData.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []), role: ((await module_1.userRoleAndScope(docData.ownerId)).data || [""])[0], owner: await users_1.userFindOne("id", docData.ownerId, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 }), thumbnail: (fileType == "jpg" || fileType == "jpeg" || fileType == "png") ? `${host}/api/docs/get-document/${docData.fileId}` : "N/A" });
    }
    catch (err) {
        throw err;
    }
}
//  Get My Documents
async function getDocListOfMe(userId, page = 1, limit = 30, host) {
    try {
        let folderList = await folder_model_1.folders.find({ ownerId: userId, isDeleted: false }, { _id: 0, doc_id: 1 });
        let folder_files = folderList.map(({ doc_id }) => doc_id);
        var merged = [].concat.apply([], folder_files);
        let folderDocIds = JSON.parse(JSON.stringify(merged));
        let docs = await model_1.documents.find({ ownerId: userId, parentId: null, isDeleted: false, status: { $ne: STATUS.DRAFT } }).collation({ locale: 'en' }).sort({ name: 1 });
        const docList = await Promise.all(docs.map((doc) => {
            return docData(doc, host);
        }));
        var result = docList.filter((docs) => {
            return !folderDocIds.some((folderDocs) => {
                return docs._id == folderDocs;
            });
        });
        result = documentsSort(result, "updatedAt", true);
        return manualPagination(page, limit, result);
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getDocListOfMe = getDocListOfMe;
//  Get Fianancial Doc List
async function getFinancialDocList(userId, page = 1, limit = 30, host) {
    try {
        let [isExist, docIds] = await Promise.all([
            role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [""])[0], "view-all-cmp-documents"),
            getAllFinancialDocIds()
        ]);
        let docs = await model_1.documents.find({ _id: { $in: docIds }, parentId: null, isDeleted: false, status: { $ne: STATUS.DRAFT } }).collation({ locale: 'en' }).sort({ name: 1 });
        const docList = await Promise.all(docs.map((doc) => {
            return docData(doc, host);
        }));
        let result = documentsSort(docList, "updatedAt", true);
        return manualPagination(page, limit, result);
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getFinancialDocList = getFinancialDocList;
async function getDocumentListOfMeWithOutFolders(userId, page = 1, limit = 30, host, pagination = true) {
    try {
        let docs = await model_1.documents.find({ ownerId: userId, parentId: null, isDeleted: false, status: { $ne: STATUS.DRAFT } }).collation({ locale: 'en' }).sort({ name: 1 });
        let docList = await Promise.all(docs.map((doc) => docData(doc, host)));
        if (pagination) {
            docList = documentsSort(docList, "updatedAt", true);
            return manualPagination(page, limit, docList);
        }
        return docList;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getDocumentListOfMeWithOutFolders = getDocumentListOfMeWithOutFolders;
;
//  Create File
async function createFile(docId, file) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        const { id, name } = JSON.parse(file);
        if (!id || !name)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        let [child, parent] = await Promise.all([
            model_1.documents.find({ parentId: docId, isDeleted: false }).sort({ createdAt: -1 }).exec(),
            model_1.documents.findByIdAndUpdate(docId, { fileId: id, fileName: name }, { new: true }).exec()
        ]);
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        await model_1.documents.findByIdAndUpdate(child[0].id, { fileId: id, fileName: name }, { new: true });
        return { doc_id: docId };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.createFile = createFile;
//  Submit for approval
async function submit(docId) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let [parent, child] = await Promise.all([
            model_1.documents.findById(docId).exec(),
            model_1.documents
                .find({ parentId: docId, isDeleted: false })
                .sort({ createdAt: -1 })
                .exec()
        ]);
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        child = await model_1.documents.findById(child[0].id);
        if (!child.fileId || !parent.fileId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.FILE_NOT_FOUND);
        let [childDoc, parentDoc] = await Promise.all([
            model_1.documents
                .findByIdAndUpdate(child.id, { status: STATUS.DONE }, { new: true })
                .exec(),
            model_1.documents
                .findByIdAndUpdate(docId, { status: STATUS.DONE }, { new: true })
                .exec()
        ]);
        return { docId: docId, fileId: parentDoc.fileId };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.submit = submit;
//  Create New Version
async function createNewVersion(docId, versionID, userId, obj) {
    try {
        if (!versionID)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let [docDetails, DocList] = await Promise.all([
            model_1.documents
                .findOne({
                _id: mongoose_1.Types.ObjectId(versionID),
                $or: [{ status: STATUS.APPROVED }, { status: STATUS.REJECTED }]
            })
                .exec(),
            model_1.documents
                .find({ parentId: docId })
                .sort({ createdAt: -1 })
                .exec()
        ]);
        if (!docDetails)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        let createNewDoc = await model_1.documents.create({
            name: obj.name,
            codeName: obj.name,
            description: obj.description,
            themes: obj.themes,
            tags: obj.tags,
            versionNum: Number(DocList[0].versionNum) + 1,
            status: STATUS.DRAFT,
            ownerId: userId,
            parentId: docDetails.parentId,
            fileName: docDetails.fileName,
            fileId: docDetails.fileId
        });
        return { doc_id: createNewDoc.parentid, versionID: createNewDoc.id };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.createNewVersion = createNewVersion;
//  Reject Document
async function RejectDoc(docId, versionId) {
    try {
        if (!docId || !versionId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        let [child, parentDoc] = await Promise.all([
            model_1.documents
                .findByIdAndUpdate(versionId, { status: STATUS.REJECTED }, { new: true })
                .exec(),
            model_1.documents.findById(docId).exec()
        ]);
        if (parentDoc.status != STATUS.APPROVED) {
            await model_1.documents.findByIdAndUpdate(parentDoc.id, {
                status: STATUS.REJECTED
            });
        }
        return { message: "Document Rejected." };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.RejectDoc = RejectDoc;
// Approve Document
async function ApproveDoc(docId, versionId) {
    try {
        if (!versionId || !docId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let [child, parent] = await Promise.all([
            model_1.documents
                .findByIdAndUpdate(versionId, { status: STATUS.APPROVED }, { new: true })
                .exec(),
            model_1.documents
                .findByIdAndUpdate(docId, { status: STATUS.APPROVED }, { new: true })
                .exec()
        ]);
        return { message: "Document Approved." };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.ApproveDoc = ApproveDoc;
//  Get Doc Details
async function getDocDetails(docId, userId, token, allCmp) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let publishDocs = await model_1.documents.findById(docId);
        const [allCmp, allFinancial] = await Promise.all([
            role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [""])[0], "view-all-cmp-documents"),
            role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [""])[0], "view-all-finanacial-documents")
        ]);
        if (!allCmp || !allFinancial) {
            if (publishDocs.isDeleted)
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_DELETED(publishDocs.name));
            if (publishDocs.status != 2 && publishDocs.parentId == null) {
                let userCapability = await documnetCapabilities(publishDocs.parentId || publishDocs._id, userId);
                if (!userCapability.length)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_HAVE_NO_ACCESS);
            }
        }
        let filteredDocs;
        let filteredDocsToRemove;
        const docList = publishDocs.toJSON();
        if (docList.parentId) {
            let parentDoc = await model_1.documents.findById(docList.parentId);
            docList.tags = parentDoc.tags;
            docList.suggestedTags = parentDoc.suggestedTags,
                docList.suggestTagsToAdd = parentDoc.suggestTagsToAdd,
                docList.suggestTagsToRemove = parentDoc.suggestTagsToRemove;
        }
        if (docList.ownerId == userId) {
            filteredDocs = docList.suggestTagsToAdd;
            filteredDocsToRemove = docList.suggestTagsToRemove;
        }
        else {
            filteredDocs = docList.suggestTagsToAdd.filter((tag) => tag.userId == userId);
            filteredDocsToRemove = docList.suggestTagsToRemove.filter((tag) => tag.userId == userId);
        }
        const userData = Array.from(new Set(filteredDocs.map((_respdata) => _respdata.userId))).map((userId) => ({
            userId,
            tags: filteredDocs
                .filter((_respdata) => _respdata.userId == userId)
                .reduce((resp, eachTag) => [...resp, ...eachTag.tags], [])
        }));
        let users = await Promise.all(userData.map((suggestedTagsInfo) => userInfo(suggestedTagsInfo)));
        docList.suggestTagsToAdd = users;
        const userDataForRemoveTag = Array.from(new Set(filteredDocsToRemove.map((_respdata) => _respdata.userId))).map((userId) => ({
            userId,
            tags: filteredDocsToRemove
                .filter((_respdata) => _respdata.userId == userId)
                .reduce((resp, eachTag) => [...resp, ...eachTag.tags], [])
        }));
        let usersDataForRemoveTag = await Promise.all(userDataForRemoveTag.map((suggestedTagsInfo) => userInfo(suggestedTagsInfo)));
        docList.suggestTagsToRemove = usersDataForRemoveTag;
        let [tagObjects, ownerRole, ownerObj, taskDetailsObj] = await Promise.all([
            getTags((docList.tags && docList.tags.length) ? docList.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []),
            module_1.userRoleAndScope(docList.ownerId),
            users_1.userFindOne("id", docList.ownerId, { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 }),
            utils_1.getTasksForDocument(docList.parentId || docList._id, token),
        ]);
        let projectIds = taskDetailsObj.filter(({ projectId }) => projectId).map(({ projectId }) => projectId);
        let projectDetails = await project_model_1.project.find({ $or: [{ _id: { $in: projectIds || [] } }, { "funds.released.documents": { $in: [docId] } }, { "funds.utilized.documents": { $in: [docId] } }] }, { name: 1 }).exec();
        await module_3.create({ activityType: `DOCUMENT_VIEWED`, activityBy: userId, documentId: docId });
        return Object.assign({}, docList, { tags: tagObjects, owner: Object.assign({}, ownerObj, { role: await module_4.formateRoles((ownerRole.data || [""])[0]) }), taskDetails: taskDetailsObj, projectDetails, sourceId: docList.sourceId ? await model_1.documents.findById(docList.sourceId).exec() : '' });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getDocDetails = getDocDetails;
async function getDocumentById(docId) {
    if (!mongoose_1.Types.ObjectId.isValid(docId))
        throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
    let details = await model_1.documents.findById(docId);
    if (!details)
        throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_NOT_FOUND);
    return details;
}
exports.getDocumentById = getDocumentById;
async function getDocumentVersionById(versionId) {
    if (!versionId) {
        throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
    }
    const doc = await model_1.documents.findById(versionId);
    if (!doc) {
        throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
    }
    return doc;
}
exports.getDocumentVersionById = getDocumentVersionById;
//  Get doc with Version
async function getDocWithVersion(docId, versionId) {
    try {
        if (!docId || !versionId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let docDetails = await model_1.documents.findById(versionId);
        const docList = docDetails.toJSON();
        docList.tags = await getTags(docList.tags);
        docList.themes = await getThemes(docList.themes);
        let role = await module_1.userRoleAndScope(docList.ownerId);
        docList.role = role.data[0];
        return docList;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getDocWithVersion = getDocWithVersion;
async function updateDoc(objBody, docId, userId) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let capability = await groups_1.GetDocCapabilitiesForUser(userId, docId);
        if (capability.includes("viewer"))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_UPDATE_USER);
        let obj = {};
        if (objBody.name) {
            if (objBody.name.length > systemconfig_1.configLimit.name) {
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_NAME_LENGTH(systemconfig_1.configLimit.name));
            }
            obj.name = objBody.name;
        }
        if (objBody.description) {
            if (objBody.description.length > systemconfig_1.configLimit.description) {
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_DESCRIPTION_LENGTH(systemconfig_1.configLimit.description));
            }
            obj.description = objBody.description;
        }
        if (objBody.tags) {
            obj.tags = objBody.tags;
        }
        let child = await model_1.documents.find({ parentId: docId, isDeleted: false }).sort({ createdAt: -1 }).exec();
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        obj.versionNum = Number(child[0].versionNum) + 1;
        let parent = await model_1.documents.findByIdAndUpdate(docId, obj, { new: true }).exec();
        await model_1.documents.create({
            name: parent.name,
            codeName: parent.name,
            description: parent.description,
            tags: parent.tags,
            versionNum: Number(child[0].versionNum) + 1,
            status: parent.status,
            ownerId: userId,
            parentId: parent.id,
            fileId: parent.fileId,
            fileName: parent.fileName
        });
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            let tags = await getTags(parent.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)));
            let tagNames = tags.map((tag) => { return tag.tag; });
            let updatedData = esClient.update({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                id: docId,
                body: {
                    "script": {
                        "source": "ctx._source.tags=(params.tags);ctx._source.name=(params.name);ctx._source.description=(params.description);ctx._source.fileName=(params.fileName);",
                        "lang": "painless",
                        "params": {
                            "tags": tagNames,
                            "name": parent.name,
                            "description": parent.description,
                            "fileName": parent.fileName
                        }
                    }
                }
            });
        }
        return parent;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.updateDoc = updateDoc;
;
async function cancelUpdate(docId, userId) {
    try {
        await module_3.create({ activityType: `CANCEL_UPDATED`, activityBy: userId, documentId: docId });
        return { success: true };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.cancelUpdate = cancelUpdate;
;
async function updateDocNew(objBody, docId, userId, siteConstants) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        // const isEligible = await checkRoleScope(userRole, "edit-document");
        // if (!isEligible) {
        //   throw new APIError(DOCUMENT_ROUTER.NO_PERMISSION, 403);
        // }
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let capability = await documnetCapabilities(docId, userId);
        if (capability.includes("viewer"))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_UPDATE_USER);
        let obj = {};
        if (objBody.docName) {
            // if (!/.*[A-Za-z0-9]{1}.*$/.test(objBody.docName)) throw new Error(DOCUMENT_ROUTER.NAME_ERROR)
            if (objBody.docName.length > Number(siteConstants.docNameLength || systemconfig_1.configLimit.name))
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_NAME_LENGTH(siteConstants.docNameLength));
            let data = await model_1.documents.findOne({ _id: { $ne: docId }, isDeleted: false, parentId: null, ownerId: userId, codeName: objBody.docName.toLowerCase() }).exec();
            if (data) {
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOC_ALREADY_EXIST);
            }
            obj.name = objBody.docName;
            obj.codeName = objBody.docName.toLowerCase();
        }
        if (objBody.description || objBody.description == "") {
            if (objBody.description.length > Number(siteConstants.docDescriptionSize || systemconfig_1.configLimit.description))
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_DESCRIPTION_LENGTH(siteConstants.docDescriptionSize));
            obj.description = objBody.description;
        }
        objBody.tags = (Array.isArray(objBody.tags) ? objBody.tags : typeof (objBody.tags) == "string" && objBody.tags.length ? objBody.tags.includes("[") ? JSON.parse(objBody.tags) : objBody.tags = objBody.tags.split(',') : []).filter((tag) => mongoose_1.Types.ObjectId.isValid(tag));
        let _document = await model_1.documents.findById(docId);
        if (objBody.tags && !objBody.docName && !objBody.description) {
            let userRoles = await module_1.userRoleAndScope(userId);
            let userRole = userRoles.data[0];
            const isEligible = _document.status == 2 ? await role_management_1.checkRoleScope(userRole, "add-tags-publish") : await role_management_1.checkRoleScope(userRole, "add-tag-to-document");
            if (!isEligible) {
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_TAGS_PERMISSION, 403);
            }
            let userCapabilities = await groups_1.GetDocCapabilitiesForUser(userId, docId);
            if (!userCapabilities.includes("owner") && _document.status != 2)
                throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_ACTION_PERFORMED);
            obj.tags = typeof (objBody.tags) == "string" ? JSON.parse(objBody.tags) : objBody.tags;
        }
        if (objBody.name && objBody.id) {
            obj.fileId = objBody.id;
            obj.fileName = objBody.name;
        }
        let child = await model_1.documents.find({ parentId: docId, isDeleted: false }).sort({ createdAt: -1 }).exec();
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        if (objBody.description || objBody.docName || objBody.id)
            obj.versionNum = Number(child[0].versionNum) + 1;
        let parent = await model_1.documents.findByIdAndUpdate(docId, obj, { new: true }).exec();
        if (objBody.description || objBody.docName || objBody.id) {
            await model_1.documents.create({
                name: parent.name,
                codeName: parent.name,
                description: parent.description,
                tags: parent.tags,
                versionNum: Number(child[0].versionNum) + 1,
                status: parent.status,
                ownerId: userId,
                parentId: parent.id,
                fileId: objBody.id || parent.fileId,
                fileName: objBody.name || parent.fileName,
                suggestedTags: parent.suggestedTags
            });
            const message = `${_document.name != parent.name ? "name" : ""}${(_document.description != null && _document.description != parent.description) ? _document.name != parent.name ? (_document.fileId != parent.fileId ? ", description" : " and description") : "description" : ""}${_document.fileId != parent.fileId ? (_document.description != null && _document.description != parent.description) ? " and file" : _document.name != parent.name ? " and file" : "file" : ""}`;
            mailAllCmpUsers("documentUpdate", parent, false, userId, message);
            await module_3.create({ activityType: `DOCUMENT_UPDATED`, activityBy: userId, documentId: docId, message });
        }
        else {
            await model_1.documents.findByIdAndUpdate(child[child.length - 1]._id, { tags: parent.tags, suggestedTags: parent.suggestedTags });
            let addtags = obj.tags.filter((tag) => !child[child.length - 1].tags.includes(tag));
            let removedtags = child[child.length - 1].tags.filter((tag) => !obj.tags.includes(tag));
            if (addtags.length && removedtags.length) {
                let tagObjs = await tag_model_1.tags.find({ "_id": { $in: [...addtags, ...removedtags] } });
                let addTagNames = tagObjs.filter(({ _id }) => addtags.includes(_id)).map(({ tag }) => tag).join(",");
                let removedTagNames = tagObjs.filter(({ _id }) => addtags.includes(_id)).map(({ tag }) => tag).join(",");
                const addMessage = addTagNames.lastIndexOf(",") == -1 ? `${addTagNames} tag added` : `${addTagNames.slice(0, addTagNames.lastIndexOf(",")) + " and " + addTagNames.slice(addTagNames.lastIndexOf(",") + 1)} tags added`;
                const removedMessage = removedTagNames.lastIndexOf(",") == -1 ? `${removedTagNames} tag removed` : `${removedTagNames.slice(0, removedTagNames.lastIndexOf(",")) + " and " + removedTagNames.slice(removedTagNames.lastIndexOf(",") + 1)} tags removed`;
                const message = addMessage + "and" + removedMessage;
                mailAllCmpUsers("documentUpdate", parent, false, userId, message);
                await module_3.create({ activityType: `TAGS_ADD_AND_REMOVED`, activityBy: userId, documentId: docId, tagsAdded: addtags, tagsRemoved: removedtags });
            }
            else {
                if (addtags.length) {
                    let tags = ((await tag_model_1.tags.find({ "_id": { $in: addtags } })).map(({ tag }) => tag)).join(",");
                    // const message = tags.lastIndexOf(",") == -1 ? `${tags} tag` : `${tags.slice(0, tags.lastIndexOf(",")) + " and " + tags.slice(tags.lastIndexOf(",") + 1)} tags`
                    const message = `tag`;
                    mailAllCmpUsers("documentUpdate", parent, false, userId, message);
                    await module_3.create({ activityType: `TAGS_ADDED`, activityBy: userId, documentId: docId, tagsAdded: addtags });
                }
                if (removedtags.length) {
                    let tags = ((await tag_model_1.tags.find({ "_id": { $in: removedtags } })).map(({ tag }) => tag)).join(",");
                    const message = tags.lastIndexOf(",") == -1 ? `${tags} tag` : `${tags.slice(0, tags.lastIndexOf(",")) + " and " + tags.slice(tags.lastIndexOf(",") + 1)} tags`;
                    // mailAllCmpUsers("documentUpdate", parent, false, userId, message)
                    await module_3.create({ activityType: `TAGS_REMOVED`, activityBy: userId, documentId: docId, tagsRemoved: removedtags });
                }
            }
        }
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            let tags = await getTags(parent.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)));
            let tagNames = tags.map((tag) => { return tag.tag; });
            let updatedData = esClient.update({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                id: docId,
                body: {
                    "script": {
                        "source": "ctx._source.tags=(params.tags);ctx._source.name=(params.name);ctx._source.description=(params.description);ctx._source.fileName=(params.fileName);",
                        "lang": "painless",
                        "params": {
                            "tags": tagNames,
                            "name": parent.name,
                            "description": parent.description,
                            "fileName": parent.fileName
                        }
                    }
                }
            });
        }
        return parent;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.updateDocNew = updateDocNew;
async function approvalList(host) {
    try {
        let docList = await model_1.documents.find({ parentId: { $ne: null }, status: STATUS.PUBLISHED, isDeleted: false }).collation({ locale: 'en' }).sort({ name: 1 });
        let parentDocsIdsArray = docList.map((doc) => {
            return doc.parentId;
        });
        let parentDocList = await model_1.documents.find({
            _id: { $in: parentDocsIdsArray }, isDeleted: false
        });
        return await Promise.all(parentDocList.map(async (doc) => {
            return await docData(doc, host);
        }));
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.approvalList = approvalList;
async function uploadToFileService(request, size) {
    const options = {
        hostname: process.env.FILE_SERVICE_HOST,
        port: process.env.FILE_SERVICE_PORT,
        path: `/files?size=${size}`,
        method: "POST",
        headers: request.headers
    };
    return new Promise((resolve, reject) => {
        const req = http.request(options, res => {
            // response.writeHead(200, res.headers);
            res.setEncoding("utf8");
            let content = "";
            res.on("data", chunk => {
                content += chunk;
            });
            res.on("end", () => {
                resolve(content);
            });
        });
        req.on("error", e => {
            console.error(e);
            reject(e);
        });
        request.pipe(req);
    });
}
exports.uploadToFileService = uploadToFileService;
async function getVersions(docId) {
    try {
        if (!docId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_ID_NOT_FOUND);
        let docVersions = await model_1.documents.find({ parentId: docId, status: { $ne: STATUS.DRAFT }, isDeleted: false }, { versionNum: 1, status: 1, createdAt: 1, updatedAt: 1 }).sort({ createdAt: -1 });
        if (!docVersions.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        return docVersions;
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getVersions = getVersions;
async function getApprovalDoc(docId) {
    try {
        if (!docId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_ID_NOT_FOUND);
        let [parent, pendingDoc] = await Promise.all([
            model_1.documents.findById(docId).exec(),
            model_1.documents
                .find({ parentId: docId, status: STATUS.PENDING, isDeleted: false })
                .sort({ createdAt: -1 })
                .exec()
        ]);
        const parentDoc = parent.toJSON();
        parentDoc.tags = await getTags(parentDoc.tags);
        parentDoc.themes = await getThemes(parentDoc.themes);
        let parentRole = await module_1.userRoleAndScope(parentDoc.ownerId);
        parentDoc.role = parentRole.data[0];
        const modifiedDoc = pendingDoc[0].toJSON();
        modifiedDoc.tags = await getTags(modifiedDoc.tags);
        modifiedDoc.themes = await getThemes(modifiedDoc.themes);
        let modifiedRole = await module_1.userRoleAndScope(parentDoc.ownerId);
        parentDoc.role = modifiedRole.data[0];
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getApprovalDoc = getApprovalDoc;
async function getTags(tagIds) {
    try {
        return await tag_model_1.tags.find({ _id: { $in: tagIds }, deleted: false }, { tag: 1 });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getTags = getTags;
async function getAllTags(tags) {
    try {
        let tagIds = (tags && tags.length) ? tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : [];
        return await tag_model_1.tags.find({ _id: { $in: tagIds }, deleted: false }, { tag: 1 });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getAllTags = getAllTags;
async function getThemes(themeIds) {
    try {
        return await theme_model_1.themes.find({ _id: { $in: themeIds } }, { theme: 1 });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
//  Add Collaborator
async function addCollaborator(docId, collaborators) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        if (!Array.isArray(collaborators))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MISSING_COLLABORATOR);
        await Promise.all([
            collaborators.map(async (user) => {
                let success = await groups_1.groupsAddPolicy(user, docId, "collaborator");
                if (!success.user)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_ALREADY_THIS_PERMISSION(user));
            })
        ]);
        return { message: "added collaborators successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.addCollaborator = addCollaborator;
//  remove Collaborator
async function removeCollaborator(docId, collaborators) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        if (!Array.isArray(collaborators))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MISSING_COLLABORATOR);
        await Promise.all([
            collaborators.map(async (user) => {
                let success = await groups_1.groupsRemovePolicy(user, docId, "collaborator");
                if (!success.user)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_ALREADY_THIS_PERMISSION(user));
            })
        ]);
        return { message: "Remove collaborators successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.removeCollaborator = removeCollaborator;
//  Add Viewers
async function addViewers(docId, viewers) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        if (!Array.isArray(viewers))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        await Promise.all([
            viewers.map(async (user) => {
                let success = await groups_1.groupsAddPolicy(user, docId, "viewer");
                if (!success.user)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_ALREADY_THIS_PERMISSION(user));
            })
        ]);
        return { message: "added viewers successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.addViewers = addViewers;
//  remove Viewers
async function removeViewers(docId, viewers) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        if (!Array.isArray(viewers))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        await Promise.all([
            viewers.map(async (user) => {
                let success = await groups_1.groupsRemovePolicy(user, docId, "viewer");
                if (!success.user)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_ALREADY_THIS_PERMISSION(user));
            })
        ]);
        return { message: "remove viewers successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.removeViewers = removeViewers;
async function collaboratorList(docId) {
    try {
        let users = await groups_1.GetUserIdsForDocWithRole(docId, "collaborator");
        return await users_1.userList({ _id: { $in: users } }, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
    }
    catch (err) {
        throw err;
    }
}
exports.collaboratorList = collaboratorList;
async function viewerList(docId) {
    try {
        let users = await groups_1.GetUserIdsForDocWithRole(docId, "viewer");
        return await users_1.userList({ _id: { $in: users } }, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 });
    }
    catch (err) {
        throw err;
    }
}
exports.viewerList = viewerList;
async function sharedList(userId, page = 1, limit = 30, host, pagination = true) {
    try {
        let docIds = [];
        let groups = await groups_1.userGroupsList(userId);
        docIds = await Promise.all(groups.map((groupId) => groups_1.GetDocIdsForUser(groupId, "group")));
        docIds = docIds.reduce((main, arr) => main.concat(arr), []);
        docIds = [...new Set(docIds.concat(await groups_1.GetDocIdsForUser(userId)))].filter((id) => mongoose_1.Types.ObjectId.isValid(id));
        let docs = await model_1.documents.find({ _id: { $in: docIds }, isDeleted: false }).collation({ locale: 'en' }).sort({ name: 1 });
        let data = await Promise.all(docs.map(async (doc) => {
            const filteredDocs = doc.suggestTagsToAdd ? doc.suggestTagsToAdd.filter((tag) => tag.userId == userId) : [];
            const filteredDocsForRemove = doc.suggestTagsToRemove ? doc.suggestTagsToRemove.filter((tag) => tag.userId == userId) : [];
            doc.suggestTagsToAdd = filteredDocs;
            doc.suggestedTagsToRemove = filteredDocsForRemove;
            return await docData(doc, host);
        }));
        data = data.filter(({ ownerId }) => ownerId != userId);
        if (pagination) {
            data = documentsSort(data, "name", false);
            return manualPagination(page, limit, data);
        }
        ;
        return data;
    }
    catch (err) {
        throw err;
    }
}
exports.sharedList = sharedList;
async function allDocuments(userId, page = 1, limit = 30, host, pagination = true) {
    try {
        let data = [
            ...await getDocList(page, limit, host, false),
            ...await sharedList(userId, page, limit, host, false),
            ...await getDocumentListOfMeWithOutFolders(userId, page, limit, host, false),
        ];
        if (pagination) {
            data = documentsSort(data, "name", false);
            return manualPagination(page, limit, data);
        }
        return data;
    }
    catch (err) {
        throw err;
    }
}
exports.allDocuments = allDocuments;
async function documnetCapabilities(docId, userId) {
    try {
        let groups = await groups_1.userGroupsList(userId);
        let viewer;
        let doc = await model_1.documents.findById(docId);
        if (doc.status == 2)
            return ["public"];
        let acceptCapabilities = ["owner", "collaborator", "viewer"];
        let capability = await groups_1.GetDocCapabilitiesForUser(userId, docId);
        if (capability.length) {
            let role = capability.filter((capability) => acceptCapabilities.includes(capability)).pop();
            if (role == "owner" || role == "collaborator")
                return [role];
            if (role == "viewer")
                viewer = role;
        }
        if (groups.length) {
            for (const groupId of groups) {
                let capability = await groups_1.GetDocCapabilitiesForUser(groupId, docId, "group");
                if (capability.length) {
                    let role = capability.filter((capability) => acceptCapabilities.includes(capability)).pop();
                    if (role == "collaborator")
                        return [role];
                    if (role == "viewer")
                        viewer = role;
                }
            }
            ;
        }
        let request = await document_request_model_1.docRequestModel.findOne({ docId, requestedBy: userId, isDelete: false });
        if (viewer) {
            return request ? ["viewer", true] : ["viewer"];
        }
        const [allCmp, allFinancial, allFinancialDocIds] = await Promise.all([
            role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [[]])[0], "view-all-cmp-documents"),
            role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [[]])[0], "view-all-finanacial-documents"),
            getAllFinancialDocIds()
        ]);
        if (allCmp)
            return request ? ["viewer", "all_cmp", true] : ["viewer", "all_cmp"];
        if (allFinancial && allFinancialDocIds.includes(docId))
            return request ? ["viewer", "all_financial", true] : ["viewer", "all_financial"];
        return request ? ["no_access", true] : ["no_access"];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.documnetCapabilities = documnetCapabilities;
;
async function getAllFinancialDocIds() {
    let all_projects = await project_model_1.project.find({}, { funds: 1 }).exec();
    return all_projects.reduce((main, curr) => {
        return main.concat((curr.funds && curr.funds.length) ? (curr.toJSON()).funds.map((fundObj) => {
            if (fundObj.released && fundObj.released.documents && fundObj.released.documents.length)
                return fundObj.released.documents;
            if (fundObj.utilized && fundObj.utilized.documents && fundObj.utilized.documents.length)
                return fundObj.utilized.documents;
            return [];
        }).reduce((main, curr) => main.concat(curr), []) : []);
    }, []).filter((id) => mongoose_1.Types.ObjectId(id));
}
function documentsSort(data, key, date = false) {
    try {
        if (date) {
            return data.sort((a, b) => new Date(b[key]) - new Date(a[key]));
        }
        return data.sort((a, b) => a[key].localeCompare(b[key]));
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function invite(user, docId, role, doc, actionUserId) {
    await groups_1.shareDoc(user._id, user.type, docId, role);
    if (user.type == "user") {
        inviteMail(user._id, doc, actionUserId);
    }
    else if (user.type == "group") {
        let userIds = await groups_1.groupUserList(user._id);
        userIds = userIds.filter(userId => userIds != doc.ownerId);
        await Promise.all(userIds.map(userId => inviteMail(userId, doc, actionUserId)));
    }
}
;
async function inviteMail(userId, doc, actionUserId) {
    try {
        let userData = await users_1.userFindOne("id", userId);
        let userName = `${userData.firstName} ${userData.middleName || ""} ${userData.lastName || ""}`;
        const { fullName, mobileNo } = module_4.getFullNameAndMobile(userData);
        module_2.create({ notificationType: `DOCUMENTS`, userId: userData._id, docId: doc._id, title: web_notification_messages_1.DOC_NOTIFICATIONS.inviteForDocument(doc.name), from: actionUserId });
        module_4.sendNotification({ id: userData._id, fullName, mobileNo, email: userData.email, documentName: doc.name, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${doc._id}`, templateName: "inviteForDocument", mobileTemplateName: "inviteForDocument" });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function invitePeople(docId, users, role, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let getUserRole = userRoles.data[0];
        // const isEligible = await checkRoleScope(getUserRole, "share-document");
        // if (!isEligible) {
        //   throw new APIError(DOCUMENT_ROUTER.NO_PERMISSION, 403);
        // }
        if (!docId || !Array.isArray(users) || !users.length || !role)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        let doc = await model_1.documents.findById(docId);
        if (doc.status == 2)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.SHARE_PUBLISHED_DOCUMENT);
        let userRole = await documnetCapabilities(docId, userId);
        if (userRole.includes("collaborator") && role != "viewer")
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_COLLABORATOR_ACTION);
        if (userRole.includes("viewer") || userRole.includes("no_access"))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_VIEWER_ACTION);
        let addUsers = [];
        let userIds = [];
        let userNames = [];
        let groupIds = [];
        let groupNames = [];
        await Promise.all(users.map(async (user) => {
            if (doc.ownerId != user._id) {
                addUsers.push({ id: user._id, type: user.type, role: role });
                if (user.type == 'user')
                    userIds.push(user._id);
                else if (user.type == 'group') {
                    groupIds.push(user._id);
                    let groupName = await users_1.groupFindOne('_id', user._id);
                    groupNames.push(groupName.name);
                    let groupUserIds = await groups_1.groupUserList(user._id);
                    groupUserIds = groupUserIds.filter(userId => userId != doc.ownerId);
                    userIds.push(...groupUserIds);
                }
                return await invite(user, docId, role, doc, userId);
            }
        }));
        await Promise.all(userIds.map(async (user) => {
            let userDetails = await users_1.userFindOne("id", user, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
            userNames.push(`${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`);
        }));
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            if (groupIds.length && groupNames.length) {
                let update = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "source": "ctx._source.accessedBy.addAll(params.userId);ctx._source.userName.addAll(params.userNames);ctx._source.groupId.addAll(params.groupId);ctx._source.groupName.addAll(params.groupName)",
                            "lang": "painless",
                            "params": {
                                "userId": userIds,
                                "userNames": userNames,
                                "groupId": groupIds,
                                "groupName": groupNames
                            }
                        }
                    }
                });
            }
            else {
                let updatedData = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "source": "ctx._source.accessedBy.addAll(params.userId);ctx._source.userName.addAll(params.userNames)",
                            "lang": "painless",
                            "params": {
                                "userId": userIds,
                                "userNames": userNames,
                            }
                        }
                    }
                });
            }
        }
        await module_3.create({ activityType: `DOCUMENT_SHARED_AS_${role}`.toUpperCase(), activityBy: userId, documentId: docId, documentAddedUsers: addUsers });
        mailAllCmpUsers("invitePeopleDoc", doc, false, userId, addUsers);
        return { message: "Shared successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.invitePeople = invitePeople;
async function invitePeopleEdit(docId, userId, type, role, userObj) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let getUserRole = userRoles.data[0];
        // const isEligible = await checkRoleScope(getUserRole, "share-document");
        // if (!isEligible) {
        //   throw new APIError(DOCUMENT_ROUTER.NO_PERMISSION, 403);
        // }
        if (!docId || !userId || !type || !role)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        let actionUserRole = await documnetCapabilities(docId, userObj._id);
        if (actionUserRole.includes("collaborator") && role != "viewer")
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_COLLABORATOR_ACTION);
        if (actionUserRole.includes("viewer") || actionUserRole.includes("no_access"))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_VIEWER_ACTION);
        let userRole = await groups_1.getRoleOfDoc(userId, docId, type);
        if (userRole && userRole.length) {
            await groups_1.groupsRemovePolicy(`${type}/${userId}`, docId, userRole[2]);
        }
        let request = await document_request_model_1.docRequestModel.findOne({ docId, requestedBy: userId, isDelete: false });
        if (request && role == "collaborator") {
            await document_request_model_1.docRequestModel.findByIdAndUpdate(request.id, { $set: { isDelete: true } }, {});
        }
        await groups_1.groupsAddPolicy(`${type}/${userId}`, docId, role);
        await module_3.create({ activityType: `MODIFIED_${type}_SHARED_AS_${role}`.toUpperCase(), activityBy: userObj._id, documentId: docId, documentAddedUsers: [{ id: userId, type: type, role: role }] });
        // mailAllCmpUsers("invitePeopleEditDoc", await documents.findById(docId), false, [{ id: userId, type: type, role: role }])
        return { message: "Edit user successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.invitePeopleEdit = invitePeopleEdit;
async function invitePeopleRemove(docId, userId, type, role, userObj) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let getUserRole = userRoles.data[0];
        // const isEligible = await checkRoleScope(getUserRole, "share-document");
        // if (!isEligible) {
        //   throw new APIError(DOCUMENT_ROUTER.NO_PERMISSION, 403);
        // }
        if (!docId || !userId || !type || !role)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        let userRole = await documnetCapabilities(docId, userObj._id);
        if (!userRole.includes("owner"))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_ACTION_TO_REMOVE_SHARE_CAPABILITY);
        await groups_1.groupsRemovePolicy(`${type}/${userId}`, docId, role);
        await module_3.create({ activityType: `REMOVED_${type}_FROM_DOCUMENT`.toUpperCase(), activityBy: userObj._id, documentId: docId, documentRemovedUsers: [{ id: userId, type: type, role: role }] });
        // mailAllCmpUsers("invitePeopleRemoveDoc", await documents.findById(docId), false, [{ id: userId, type: type, role: role }])
        if (type == 'user') {
            let userDetails = await users_1.userFindOne("id", userId, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
            let userName = (`${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`);
            let isDocExists = await checkDocIdExistsInEs(docId);
            if (isDocExists) {
                let updatedData = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "inline": "ctx._source.accessedBy.remove(ctx._source.accessedBy.indexOf(params.accessedBy));ctx._source.userName.remove(ctx._source.userName.indexOf(params.userName))",
                            "lang": "painless",
                            "params": {
                                "accessedBy": userId,
                                "userName": userName
                            }
                        }
                    }
                });
            }
        }
        if (type == 'group') {
            let groupData = await users_1.groupFindOne('_id', userId);
            let groupName = groupData.name;
            let groupUserIds = await groups_1.groupUserList(userId);
            let idsToUpdate = await Promise.all(groupUserIds.map(async (id) => {
                let userDetails = await users_1.userFindOne("id", id, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
                if (userDetails) {
                    if (userDetails.firstName)
                        userDetails = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
                    else
                        userDetails = userDetails.name;
                }
                return {
                    docId: docId,
                    userName: userDetails,
                    userId: id,
                    groupId: userId,
                    groupName: groupName
                };
            }));
            let isDocExists = await checkDocIdExistsInEs(docId);
            if (isDocExists) {
                let updateUsers = await Promise.all(idsToUpdate.map(async (user) => {
                    await await esClient.update({
                        index: `${ELASTIC_SEARCH_INDEX}_documents`,
                        id: user.docId,
                        body: {
                            "script": {
                                "inline": "ctx._source.accessedBy.remove(ctx._source.accessedBy.indexOf(params.userId));ctx._source.userName.remove(ctx._source.userName.indexOf(params.userName));ctx._source.groupName.remove(ctx._source.groupName.indexOf(params.groupName));ctx._source.groupId.remove(ctx._source.groupId.indexOf(params.groupId));",
                                "lang": "painless",
                                "params": {
                                    "userId": user.userId,
                                    "userName": user.userName,
                                    "groupName": user.groupName,
                                    "groupId": user.groupId
                                }
                            }
                        }
                    });
                }));
            }
        }
        return { message: `Removed ${type.toLowerCase()} successfully.` };
    }
    catch (err) {
        throw err;
    }
}
exports.invitePeopleRemove = invitePeopleRemove;
async function invitePeopleList(docId) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let users = await groups_1.GetUserIdsForDoc(docId);
        if (!users.length) {
            return [];
        }
        let total = [];
        let userGroup = {};
        (users || []).map((user) => {
            if (userGroup[user.split("/")[0]]) {
                userGroup[user.split("/")[0]].push(user.split("/")[1]);
            }
            else {
                userGroup[user.split("/")[0]] = [user.split("/")[1]];
            }
        });
        if (userGroup.user) {
            var userData = await users_1.userList({ _id: { $in: userGroup.user }, is_active: true }, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1, countryCode: 1 });
            userData = await Promise.all(userData.map(async (user) => {
                return {
                    is_active: user.is_active,
                    phone: user.phone,
                    countryCode: user.countryCode,
                    id: user._id,
                    firstName: user.firstName,
                    middleName: user.middleName,
                    lastName: user.lastName,
                    type: "user",
                    email: user.email,
                    role: await module_4.formateRoles(((await module_1.userRoleAndScope(user._id)).data || [""])[0]),
                    docRole: (await groups_1.getRoleOfDoc(user._id, docId) || Array(2))[2]
                };
            }));
            total = [...userData];
        }
        if (userGroup.group) {
            var groupData = await users_1.listGroup({ _id: { $in: userGroup.group }, is_active: true }, { name: 1 });
            groupData = await Promise.all(groupData.map((group) => groupUsers(group, docId)));
            total = !total.length ? [...groupData] : total.concat(groupData);
        }
        return total;
    }
    catch (err) {
        throw err;
    }
}
exports.invitePeopleList = invitePeopleList;
async function groupUsers(groupObj, docId) {
    try {
        let userId = await groups_1.groupUserList(groupObj._id) || [];
        return Object.assign({}, groupObj, { id: groupObj._id, name: groupObj.name, type: "group", email: "N/A", members: (await users_1.userFindMany("_id", userId, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 }) || []).map((obj) => { return Object.assign({}, obj, { type: "user" }); }), docRole: docId ? ((await groups_1.getRoleOfDoc(groupObj._id, docId, "group")) || Array(2))[2] : "" });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function docCapabilities(docId, userId) {
    try {
        return await groups_1.GetDocCapabilitiesForUser(userId, docId);
    }
    catch (err) {
        throw err;
    }
}
exports.docCapabilities = docCapabilities;
async function published(body, docId, userObj, host, withAuth = true) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        if (withAuth) {
            let admin_scope = await role_management_1.checkRoleScope(userObj.role, "publish-document");
            if (!admin_scope)
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.PUBLISH_CAPABILITY, 403);
        }
        ;
        let doc = await model_1.documents.findById(docId);
        if (!doc)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        if (body.tags && Array.isArray(body.tags) && (body.tags.some((tagId) => !doc.tags.includes(tagId)) || body.tags.length != doc.tags.length)) {
            let isEligible = await role_management_1.checkRoleScope(userObj.role, "add-tag-to-document");
            if (!isEligible) {
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_PERMISSION_TO_UPDATE_TAGS, 403);
            }
        }
        let publishedDoc = await publishedDocCreate(Object.assign({}, body, { status: STATUS.PUBLISHED }), userObj._id, doc, host, docId);
        await Promise.all([
            module_3.create({ activityType: `DOUCMENT_PUBLISHED`, activityBy: userObj._id, documentId: publishedDoc._id, fromPublished: docId }),
            module_3.create({ activityType: `DOUCMENT_PUBLISHED`, activityBy: userObj._id, documentId: docId, fromPublished: docId })
        ]);
        let role = await groups_1.groupsAddPolicy(`user/${userObj._id}`, publishedDoc._id, "owner");
        if (!role.user) {
            await model_1.documents.findByIdAndRemove(publishedDoc._id);
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CREATE_ROLE_FAIL);
        }
        let publishedChild = await publishedDocCreate(Object.assign({}, body, { parentId: publishedDoc._id, status: STATUS.DONE }), userObj._id, doc, host);
        if (withAuth)
            mailAllCmpUsers("publishDocument", publishedDoc, true, userObj._id);
        return publishedDoc;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.published = published;
;
async function publishedDocCreate(body, userId, doc, host, docId) {
    try {
        let createdDoc = await model_1.documents.create({
            sourceId: docId || null,
            name: body.name || doc.name,
            codeName: body.name || doc.name,
            description: body.description || doc.description,
            themes: body.themes || doc.theme,
            tags: body.tags || doc.tags,
            versionNum: 1,
            status: body.status,
            ownerId: userId,
            parentId: body.parentId ? body.parentId : null,
            fileName: body.fileName || doc.fileName,
            fileId: body.fileId || doc.fileId
        });
        if (!body.parentId) {
            let userDetails = await users_1.userFindOne("id", userId, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
            let userName;
            if (userDetails.firstName)
                userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
            else {
                userName = userDetails.name;
            }
            let fileType = createdDoc.fileName ? (createdDoc.fileName.split(".")).pop() : "";
            let thumbnail = (fileType == "jpg" || fileType == "jpeg" || fileType == "png") ? `${host}/api/docs/get-document/${createdDoc.fileId}` : "N/A";
            let tags = await getTags((createdDoc.tags && createdDoc.tags.length) ? createdDoc.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []);
            tags = tags.map((tagData) => { return tagData.tag; });
            let docObj = {
                accessedBy: [userId],
                userName: [userName],
                name: createdDoc.name,
                description: createdDoc.description,
                tags: tags,
                thumbnail: thumbnail,
                status: createdDoc.status,
                fileName: createdDoc.fileName,
                updatedAt: createdDoc.updatedAt,
                id: createdDoc.id || createdDoc._id,
                groupId: [],
                groupName: []
            };
            let result = esClient.index({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                body: docObj,
                id: createdDoc.id || createdDoc._id
            });
        }
        return createdDoc;
    }
    catch (err) {
        throw err;
    }
}
async function unPublished(docId, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let [isEligible, docDetail] = await Promise.all([
            role_management_1.checkRoleScope(userObj.role, "unpublish-document"),
            model_1.documents.findById(docId).exec()
        ]);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
        if (docDetail.isPublic) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNPUBLISH_PUBLIC_DOCUMENT);
        }
        let success = await model_1.documents.findByIdAndUpdate(docId, { status: STATUS.UNPUBLISHED }, { new: true });
        await module_3.create({ activityType: `DOUCMENT_UNPUBLISHED`, activityBy: userObj._id, documentId: docId });
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            let updatedData = esClient.update({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                id: docId,
                body: {
                    "script": {
                        "source": "ctx._source.status=(params.status)",
                        "lang": "painless",
                        "params": {
                            "status": STATUS.UNPUBLISHED,
                        }
                    }
                }
            });
        }
        mailAllCmpUsers("unPublishDocument", success, true, userObj._id);
        return success;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.unPublished = unPublished;
;
async function replaceDoc(docId, replaceDoc, userObj, siteConstants, payload, host) {
    try {
        if (siteConstants.replaceDoc == "true") {
            let admin_scope = await role_management_1.checkRoleScope(userObj.role, "replace-document");
            if (!admin_scope)
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
            let [doc, unPublished] = await Promise.all([model_1.documents.findById(replaceDoc).exec(),
                model_1.documents.findByIdAndUpdate(docId, { status: STATUS.UNPUBLISHED }, { new: true }).exec()]);
            let success = await published(Object.assign({}, doc, { name: payload.name || doc.name, description: payload.description || doc.description, versionNum: 1, status: STATUS.PUBLISHED, ownerId: userObj._id }), doc._id, userObj, host, false);
            await module_3.create({ activityType: `DOUCMENT_REPLACED`, activityBy: userObj._id, documentId: docId, replaceDoc: success._id });
            mailAllCmpUsers("replaceDocument", success, true, userObj._id);
            let isDocExists = checkDocIdExistsInEs(docId);
            if (isDocExists) {
                let updatedData = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "source": "ctx._source.status=(params.status)",
                            "lang": "painless",
                            "params": {
                                "status": STATUS.UNPUBLISHED,
                            }
                        }
                    }
                });
            }
            return success;
        }
        else {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.replaceDoc = replaceDoc;
;
async function publishList(userId, page = 1, limit = 30, host, pagination = true) {
    try {
        let docs = await model_1.documents.find({ ownerId: userId, status: STATUS.PUBLISHED }).sort({ updatedAt: -1 });
        let data = await Promise.all(docs.map(async (doc) => docData(doc, host)));
        if (pagination) {
            data = documentsSort(data, "updatedAt", true);
            return manualPagination(page, limit, data);
        }
        return data;
    }
    catch (err) {
        throw err;
    }
}
exports.publishList = publishList;
// Get Filterd Documents
async function docFilter(search, userId, page = 1, limit = 30, host, publish = true) {
    search = search.trim();
    try {
        let users = await users_1.getNamePatternMatch(search, { name: 1, firstName: 1, lastName: 1, middleName: 1, email: 1, emailVerified: 1, is_active: 1, phone: 1, countryCode: 1 });
        let userIds = users.map((user) => user._id);
        let collaboratedDocsIds = (await Promise.all(userIds.map((userId) => groups_1.GetDocIdsForUser(userId, "user", ["collaborator"])))).reduce((main, curr) => main.concat(curr), []);
        let [collaboratorDocs, searchGroupIds, groups, tags] = await Promise.all([
            model_1.documents.find({ _id: { $in: collaboratedDocsIds }, parentId: null, isDeleted: false, ownerId: userId }).exec(),
            users_1.groupPatternMatch({}, { name: search }, {}, {}, "updatedAt"),
            groups_1.userGroupsList(userId),
            tag_model_1.tags.find({ tag: new RegExp(search, "i") }).exec()
        ]);
        searchGroupIds = searchGroupIds.map(({ _id }) => _id);
        let docIds = await Promise.all(groups.map((groupId) => groups_1.GetDocIdsForUser(groupId, "group")));
        docIds = docIds.reduce((main, arr) => main.concat(arr), []);
        docIds = [...new Set(docIds.concat(await groups_1.GetDocIdsForUser(userId)))].filter((id) => mongoose_1.Types.ObjectId.isValid(id));
        let tagIds = tags.map((tag) => tag.id);
        let [sharedCollaboratorDocs, docsWithTag, sharedWithTag, docs, shared] = await Promise.all([
            model_1.documents.find({ _id: { $in: collaboratedDocsIds.filter((id) => docIds.includes(id)) }, parentId: null, isDeleted: false }).exec(),
            model_1.documents.find({ tags: { $in: tagIds }, parentId: null, isDeleted: false, ownerId: userId }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
            model_1.documents.find({ _id: { $in: docIds }, isDeleted: false, tags: { $in: tagIds } }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
            model_1.documents.find({ parentId: null, isDeleted: false, $or: [{ name: new RegExp(search, "i") }, { description: new RegExp(search, "i") }, { ownerId: { $in: userIds } }] }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
            model_1.documents.find({ _id: { $in: docIds }, isDeleted: false, $or: [{ name: new RegExp(search, "i") }, { description: new RegExp(search, "i") }, { ownerId: { $in: userIds } }] }).collation({ locale: 'en' }).sort({ name: 1 }).exec()
        ]);
        let groupSearchIds = await Promise.all(searchGroupIds.map((groupId) => groups_1.GetDocIdsForUser(groupId, "group")));
        groupSearchIds = groupSearchIds.reduce((main, arr) => main.concat(arr), []);
        let [groupSearchDocs, sharedGroupSearchDocs] = await Promise.all([
            model_1.documents.find({ _id: { $in: groupSearchIds }, parentId: null, isDeleted: false, ownerId: userId }).exec(),
            model_1.documents.find({ _id: { $in: groupSearchIds.filter((id) => docIds.includes(id)) }, parentId: null, isDeleted: false }).exec()
        ]);
        let myDocs = [...docs, ...docsWithTag, ...collaboratorDocs, ...groupSearchDocs];
        let shareDocs = [...shared, ...sharedWithTag, ...sharedCollaboratorDocs, ...sharedGroupSearchDocs];
        if (publish == true)
            docs = [...((docs.concat(docsWithTag)).filter((doc) => (doc.ownerId == userId && doc.status == STATUS.DONE) || doc.status == STATUS.PUBLISHED || (doc.ownerId == userId && doc.status == STATUS.UNPUBLISHED))), ...shareDocs];
        else
            docs = [...myDocs.filter((doc) => (doc.ownerId == userId && doc.status == STATUS.DONE) || (doc.ownerId == userId && doc.status == STATUS.UNPUBLISHED)), ...shareDocs].filter(({ status }) => status != 2);
        docs = Object.values(docs.reduce((acc, cur) => Object.assign(acc, { [cur._id]: cur }), {}));
        let filteredDocs = await Promise.all(docs.map((doc) => docData(doc, host)));
        filteredDocs = documentsSort(filteredDocs, "name", false);
        return manualPagination(page, limit, filteredDocs);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.docFilter = docFilter;
;
//  Manual Pagination for Doc Filter
function filterOrdersByPageAndLimit(page, limit, orders) {
    let skip = ((page - 1) * limit);
    return orders.slice(skip, skip + limit);
}
;
function manualPagination(page, limit, docs) {
    page = Number(page);
    limit = Number(limit);
    const skip = ((page - 1) * limit);
    return {
        page,
        pages: Math.ceil(docs.length / limit),
        docs: docs.slice(skip, skip + limit)
    };
}
exports.manualPagination = manualPagination;
async function createFolder(body, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "create-folder");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_FOLDER_PERMISSION, 403);
        }
        if (!body.name)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        // let data = await folders
        //   .find({ ownerId: userId, name: body.name });
        // if (data.length) {
        //   throw new Error(DOCUMENT_ROUTER.ALREADY_EXIST);
        // }
        let folder = await folder_model_1.folders.create({
            name: body.name,
            parentId: body.parentId || null,
            ownerId: userId
        });
        return { folder_id: folder._id };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.createFolder = createFolder;
async function moveToFolder(folderId, body, userId) {
    if (!folderId || (!body.docId && !body.subFolderId))
        throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
    try {
        if (body.oldFolderId) {
            if (body.docId) {
                await folder_model_1.folders.update({ _id: body.oldFolderId }, {
                    $pull: { doc_id: body.docId }
                });
            }
            else if (body.subFolderId) {
                await folder_model_1.folders.update({ _id: body.subFolderId }, {
                    parentId: null
                });
            }
        }
        if (body.docId) {
            await folder_model_1.folders.update({ _id: folderId }, {
                $push: { doc_id: body.docId }
            });
        }
        else if (body.subFolderId) {
            await folder_model_1.folders.update({ _id: body.subFolderId }, {
                parentId: folderId
            });
        }
        return {
            sucess: true
        };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.moveToFolder = moveToFolder;
async function listFolders(userId) {
    try {
        let data = await folder_model_1.folders.find({ ownerId: userId, parentId: null }).collation({ locale: 'en' }).sort({ name: 1 });
        let folderList = data.map((folder) => {
            return {
                folderId: folder._id,
                name: folder.name,
                date: folder.createdAt
            };
        });
        return { folders: folderList };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.listFolders = listFolders;
async function getFolderDetails(folderId, userId, page = 1, limit = 30, host, root) {
    if (!folderId)
        throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
    const [fetchedDoc, subfolders] = await Promise.all([
        folder_model_1.folders.aggregate([
            {
                $match: {
                    ownerId: userId,
                    _id: mongoose_1.Types.ObjectId(folderId)
                }
            },
            // { "$unwind": "$doc_id" },
            {
                $lookup: {
                    from: "documents",
                    localField: "doc_id",
                    foreignField: "_id",
                    as: "doc_id"
                }
            },
            { $sort: { name: 1 } },
            { $unwind: { path: "$doc_id" } },
            {
                $project: {
                    name: 1,
                    doc_id: 1,
                    createdAt: 1,
                    ownerId: 1,
                    parentId: 1
                }
            }
        ]).exec(),
        folder_model_1.folders.find({ ownerId: userId, parentId: folderId }).collation({ locale: 'en' }).sort({ name: 1 }).exec()
    ]);
    let subFolderList = subfolders.map((folder) => {
        return {
            type: 'SUB_FOLDER',
            folderId: folder._id,
            name: folder.name,
            date: folder.createdAt,
            parentId: folder.parentId
        };
    });
    const docs = await Promise.all(fetchedDoc.map((folder) => {
        return userData(folder, host);
    }));
    const docsList = docs.map((folder) => {
        return folder[0];
    });
    const filteredDocs = docsList.filter(doc => doc.isDeleted == false);
    const folderName = await folder_model_1.folders.findById(folderId);
    const docsData = manualPagination(page, limit, [...subFolderList, ...filteredDocs]);
    const filteredSubFolders = docsData.docs.filter(doc => doc.type == 'SUB_FOLDER');
    docsData.docs = docsData.docs.filter(doc => doc.type != 'SUB_FOLDER');
    // let rootPath:any = [];
    let checkFolderData = await folder_model_1.folders.findById(folderId);
    // let checkParent = false
    let rootPath = [];
    if (checkFolderData.parentId) {
        let path = await getParentFolderDetails(checkFolderData.parentId, userId, root);
        path = path.reverse();
        rootPath.push(...path);
    }
    rootPath.push({ id: checkFolderData._id, name: checkFolderData.name });
    return { page: docsData.page, pages: docsData.pages, folderName: folderName.name, subFoldersList: filteredSubFolders, docsList: docsData.docs, path: rootPath };
}
exports.getFolderDetails = getFolderDetails;
async function getParentFolderDetails(parentId, userId, root) {
    let parentData = await folder_model_1.folders.findById(parentId);
    root.push({ id: parentData._id, name: parentData.name });
    if (parentData.parentId) {
        await getParentFolderDetails(parentData.parentId, userId, root);
    }
    return root;
}
async function userData(folder, host) {
    try {
        let fileType = folder.doc_id.fileName ? (folder.doc_id.fileName.split(".")).pop() : "";
        const [tags, userRole, owner] = await Promise.all([
            // getTags(folder.doc_id.tags),
            getTags((folder.doc_id.tags && folder.doc_id.tags.length) ? folder.doc_id.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []),
            module_1.userRoleAndScope(folder.doc_id.ownerId),
            users_1.userFindOne("id", folder.doc_id.ownerId, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 })
        ]);
        const data = await Promise.all([{
                _id: folder.doc_id._id,
                name: folder.doc_id.name,
                fileId: folder.doc_id.fileId,
                fileName: folder.doc_id.fileName,
                description: folder.doc_id.description,
                tags,
                role: (userRole.data || [""])[0],
                owner,
                thumbnail: (fileType == "jpg" || fileType == "jpeg" || fileType == "png") ? `${host}/api/docs/get-document/${folder.doc_id.fileId}` : "N/A",
                date: folder.doc_id.createdAt,
                isDeleted: folder.doc_id.isDeleted
            }]);
        return data;
    }
    catch (err) {
        throw err;
    }
}
async function deleteFolder(folderId, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "create-folder");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_FOLDER_DELETE_PERMISSION, 403);
        }
        if (!folderId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        const folderDetails = await folder_model_1.folders.find({ _id: folderId });
        if (!folderDetails.length) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.FOLDER_NOT_FOUND);
        }
        let folderData = folderDetails.map((folder) => {
            return {
                parentId: folder.parentId,
                doc_id: folder.doc_id
            };
        });
        const parentId = folderData[0].parentId ? folderData[0].parentId : null;
        let doc_id = folderData[0].doc_id.length ? folderData[0].doc_id : [];
        doc_id = JSON.parse(JSON.stringify(doc_id));
        const data = await Promise.all([
            folder_model_1.folders.remove({ _id: folderId, ownerId: userId }).exec(),
            folder_model_1.folders.update({ parentId: folderId }, {
                parentId: parentId
            }, { "multi": true }).exec(),
            folder_model_1.folders.update({ _id: parentId }, {
                $addToSet: { doc_id: doc_id },
            }, { "multi": true }).exec()
        ]);
        if (data) {
            return { success: true };
        }
    }
    catch (err) {
        throw err;
    }
}
exports.deleteFolder = deleteFolder;
async function removeFromFolder(folderId, body, userId) {
    if (!folderId || (!body.docId && !body.subFolderId))
        throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
    try {
        if (body.docId) {
            await folder_model_1.folders.update({ _id: folderId }, {
                $pull: { doc_id: body.docId }
            });
        }
        else if (body.subFolderId) {
            await folder_model_1.folders.update({ _id: body.subFolderId }, {
                parentId: null
            });
        }
        return {
            sucess: true
        };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.removeFromFolder = removeFromFolder;
async function deleteDoc(docId, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "delete-doc");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.NO_DELETE_PERMISSION, 403);
        }
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let findDoc = await model_1.documents.findOne({ _id: docId, ownerId: userId });
        if (!findDoc) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_FILE_ID);
        }
        if (findDoc.status == 2)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.PUBLISH_CANT_BE_DELETE);
        let deletedDoc = await model_1.documents.update({ _id: docId, ownerId: userId }, { isDeleted: true }).exec();
        await module_3.create({ activityType: "DOCUMENT_DELETED", activityBy: userId, documentId: docId });
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            let deleted = esClient.delete({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                id: docId,
            });
        }
        if (deletedDoc) {
            return {
                success: true,
                mesage: "File deleted successfully"
            };
        }
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.deleteDoc = deleteDoc;
;
async function getListOfFoldersAndFiles(userId, page = 1, limit = 30, host) {
    const [foldersData, folderDocs, fetchedDoc] = await Promise.all([
        folder_model_1.folders.find({ ownerId: userId, parentId: null }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
        folder_model_1.folders.find({ ownerId: userId }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
        model_1.documents.find({ ownerId: userId, parentId: null, isDeleted: false, status: { $ne: STATUS.DRAFT } }).collation({ locale: 'en' }).sort({ name: 1 }).exec(),
    ]);
    let folder_files = folderDocs.map((folder) => {
        return folder.doc_id;
    });
    var merged = [].concat.apply([], folder_files);
    let folderDocIds = JSON.parse(JSON.stringify(merged));
    let foldersList = foldersData.map((folder) => {
        return {
            type: 'FOLDER',
            folderId: folder._id,
            name: folder.name,
            date: folder.createdAt,
            parentId: folder.parentId
        };
    });
    const docList = await Promise.all(fetchedDoc.map((doc) => {
        return docData(doc, host);
    }));
    var docsList = docList.filter((docs) => {
        return !folderDocIds.some((folderDocs) => {
            return docs._id == folderDocs;
        });
    });
    const docsData = manualPagination(page, limit, [...foldersList, ...docsList]);
    const filteredFolders = docsData.docs.filter(doc => doc.type == 'FOLDER');
    docsData.docs = docsData.docs.filter(doc => doc.type != 'FOLDER');
    docsData.docs = documentsSort(docsData.docs, "name", false);
    return { page: docsData.page, pages: docsData.pages, foldersList: filteredFolders, docsList: docsData.docs };
}
exports.getListOfFoldersAndFiles = getListOfFoldersAndFiles;
async function checkCapabilitiesForUserNew(objBody, userId) {
    try {
        let { docIds, userIds } = objBody;
        if (!Array.isArray(docIds) || !Array.isArray(userIds))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        // if (objBody.unique) {
        //   if (userIds.some((user) => userIds.indexOf(user) !== userIds.lastIndexOf(user))) {
        //     throw new Error("Duplicate user ids found.");
        //   };
        // };
        let userObjects = (await users_1.userFindMany("_id", [...new Set(userIds.concat(userId))]) || []).map((user) => { return Object.assign({}, user, { type: "user" }); });
        return await Promise.all(docIds.map(docId => loopUsersAndFetchDataNew(docId, userIds, userId, userObjects)));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.checkCapabilitiesForUserNew = checkCapabilitiesForUserNew;
;
async function checkCapabilitiesForUser(objBody, userId) {
    try {
        let { docIds, userIds } = objBody;
        if (!Array.isArray(docIds) || !Array.isArray(userIds))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        // if (objBody.unique) {
        //   if (userIds.some((user) => userIds.indexOf(user) !== userIds.lastIndexOf(user))) {
        //     throw new Error("Duplicate user ids found.");
        //   };
        // };
        let obj = await Promise.all(docIds.map(docId => loopUsersAndFetchData(docId, userIds, userId)));
        let mainObj = obj.reduce((main, curr) => Object.assign({}, main, curr), {});
        let noAccessDocs = docIds.filter(docid => !Object.keys(mainObj).includes(docid));
        return Object.assign(mainObj, { noAccessDocuments: noAccessDocs, documents: await model_1.documents.find({ _id: { $in: Object.keys(mainObj).concat(noAccessDocs) } }) });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.checkCapabilitiesForUser = checkCapabilitiesForUser;
;
async function loopUsersAndFetchDataNew(docId, userIds, userId, userObjects) {
    try {
        return {
            document: await model_1.documents.findById(docId).exec(),
            attachedBy: Object.assign({}, (userObjects.find(user => user._id == userId)), { docRole: (await documnetCapabilities(docId, userId) || [""])[0], type: "user" }),
            users: await Promise.all(userIds.map(userId => userWithDocRole(docId, userId, userObjects)))
        };
    }
    catch (err) {
        throw err;
    }
}
;
async function loopUsersAndFetchData(docId, userIds, userId) {
    let userCapabilities = await documnetCapabilities(docId, userId);
    if (["no_access", "viewer"].includes(userCapabilities[0]))
        return {};
    const s = await Promise.all(userIds.map(user => documnetCapabilities(docId, user)));
    let users = await users_1.userFindMany("_id", userIds);
    const filteredusers = users.map((user) => user._id);
    let groupIds = userIds.filter(id => !filteredusers.includes(id));
    return {
        [docId]: s.map((s1, i) => {
            if (s1.includes('no_access')) {
                return { _id: userIds[i], type: groupIds.includes(userIds[i]) ? "group" : "user" };
            }
            return { _id: false };
        }).filter(({ _id }) => mongoose_1.Types.ObjectId.isValid(_id))
    };
}
;
async function userWithDocRole(docId, userId, usersObjects) {
    try {
        let acceptCapabilities = ["owner", "collaborator", "viewer", "no_access"];
        let user = usersObjects.find(user => user._id == userId);
        let docRole;
        if (!user) {
            user = Object.assign({}, (await users_1.groupFindOne("_id", userId)), { type: "group" });
            docRole = ((await groups_1.GetDocCapabilitiesForUser(userId, docId, "group")).filter((capability) => acceptCapabilities.includes(capability))).pop();
        }
        else {
            docRole = ((await documnetCapabilities(docId, userId) || [""]).filter((capability, index, array) => {
                return (array.includes("all_cmp")) ? (capability == "all_cmp") ? "no_access" : false : acceptCapabilities.includes(capability);
            })).pop();
        }
        return Object.assign({}, (user), { docRole: (!docRole || docRole == "all_cmp") ? "no_access" : docRole });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function shareDocForUsersNew(obj, userObj) {
    try {
        if ("add" in obj && obj.add.length) {
            await Promise.all(obj.add.map((obj) => invitePeople(obj.docId, [{ _id: obj.userId, type: obj.type }], obj.role, userObj._id)));
        }
        if ("edit" in obj && obj.edit.length) {
            await Promise.all(obj.edit.map((obj) => invitePeopleEdit(obj.docId, obj.userId, obj.type, obj.role, userObj)));
        }
        if ("remove" in obj && obj.remove.length) {
            await Promise.all(obj.remove.map((obj) => invitePeopleRemove(obj.docId, obj.userId, obj.type, obj.role, userObj)));
        }
        return { message: "successfully updated the roles." };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.shareDocForUsersNew = shareDocForUsersNew;
;
async function shareDocForUsers(obj) {
    try {
        if (!obj)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        if (Object.keys(obj).length) {
            if (obj.noAccessDocuments)
                delete obj.noAccessDocuments;
            if (obj.documents)
                delete obj.documents;
            await Promise.all((Object.keys(obj)).map((docId) => loopForAddCapability(docId, obj[docId])));
        }
        return { message: "shared successfully" };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.shareDocForUsers = shareDocForUsers;
;
async function loopForAddCapability(docId, users) {
    try {
        const role = "viewer";
        let doc = await model_1.documents.findById(docId);
        await Promise.all(users.map(userObj => invite(userObj, docId, role, doc, "")));
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function suggestTags(docId, body, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "suggest-tag");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
        }
        if (!body.tags) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.TAG_REQUIRED);
        }
        let [docData, child] = await Promise.all([model_1.documents.findById(docId).exec(), model_1.documents.find({ parentId: docId, isDeleted: false }).sort({ createdAt: -1 }).exec()]);
        if (!docData)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        let usersData = await users_1.userFindMany("_id", [docData.ownerId, userId], { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
        let ownerDetails = usersData.find((user) => docData.ownerId == user._id);
        let ownerName = `${ownerDetails.firstName} ${ownerDetails.middleName || ""} ${ownerDetails.lastName || ""}`;
        let userDetails = usersData.find((user) => userId == user._id);
        let userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        let [doc, childUpdate] = await Promise.all([
            model_1.documents.findByIdAndUpdate(docId, { "$push": { suggestedTags: { userId: userId, tags: body.tags } } }).exec(),
            model_1.documents.findByIdAndUpdate(child[child.length - 1]._id, { "$push": { suggestedTags: { userId: userId, tags: body.tags } } }).exec()
        ]);
        if (doc) {
            const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
            await module_3.create({ activityType: "SUGGEST_TAGS", activityBy: userId, documentId: docId, tagsAdded: body.tags });
            module_2.create({ notificationType: `DOCUMENTS`, userId: doc.ownerId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.suggestTagNotification(doc.name), from: userId });
            module_4.sendNotification({ id: doc.ownerId, fullName: ownerName, userName, mobileNo, email: ownerDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "suggestTagNotification", mobileTemplateName: "suggestTagNotification" });
            return {
                sucess: true,
                message: "Tag suggested successfully"
            };
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.suggestTags = suggestTags;
;
async function userInfo(docData) {
    try {
        return Object.assign({}, docData, { tags: await getTags((docData.tags && docData.tags.length) ? docData.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []), user: await users_1.userFindOne("id", docData.userId, { firstName: 1, middleName: 1, lastName: 1, email: 1, is_active: 1 }), role: (await module_1.userRoleAndScope(docData.userId)).data[0] });
    }
    catch (err) {
        throw err;
    }
}
async function approveTags(docId, body, userId) {
    try {
        if (!docId || !body.userId || (!body.tagIdToAdd && !body.tagIdToRemove)) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        }
        let docdetails = await model_1.documents.findById(docId);
        if (!docdetails) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        }
        let usersData = await users_1.userFindMany("_id", [userId, body.userId], { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
        let ownerDetails = usersData.find((user) => userId == user._id);
        let ownerName = `${ownerDetails.firstName} ${ownerDetails.middleName || ""} ${ownerDetails.lastName || ""}`;
        let userDetails = usersData.find((user) => body.userId == user._id);
        let userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        if (body.tagIdToAdd) {
            let [filteredDoc, filteredDoc1] = await Promise.all([
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId == body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToAdd)
                    };
                }),
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId != body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocs = [...filteredDoc, ...filteredDoc1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, { suggestTagsToAdd: filteredDocs, "$push": { tags: body.tagIdToAdd } });
            let tags = await getTags([body.tagIdToAdd]);
            let tagNames = tags.map((tag) => { return tag.tag; });
            let isDocExists = await checkDocIdExistsInEs(docId);
            if (isDocExists) {
                let updatedData = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "source": "ctx._source.tags.addAll(params.tags)",
                            "lang": "painless",
                            "params": {
                                "tags": tagNames,
                            }
                        }
                    }
                });
            }
            if (doc) {
                const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
                await module_3.create({ activityType: "SUGGEST_TAGS_ADD_APPROVED", activityBy: userId, documentId: docId, tagsAdded: body.tagIdToAdd });
                module_2.create({ notificationType: `DOCUMENTS`, userId: body.userId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.approveTagNotification(docdetails.name), from: userId });
                module_4.sendNotification({ id: body.userId, fullName: ownerName, userName, mobileNo, email: userDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "approveTagNotification", mobileTemplateName: "approveTagNotification" });
                return {
                    sucess: true,
                    message: "Tag Adding approved successfully"
                };
            }
        }
        if (body.tagIdToRemove) {
            let [suggestedToRemove, suggestedToRemove1] = await Promise.all([
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId == body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToRemove)
                    };
                }),
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId != body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocsRemove = [...suggestedToRemove, ...suggestedToRemove1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, { suggestTagsToRemove: filteredDocsRemove, "$pull": { tags: body.tagIdToRemove } });
            let tags = await getTags([body.tagIdToRemove]);
            let tagNames = tags[0].tag;
            let isDocExists = await checkDocIdExistsInEs(docId);
            if (isDocExists) {
                let updatedData = esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "inline": "ctx._source.tags.remove(ctx._source.tags.indexOf(params.tags))",
                            // "source": "ctx._source.tags.addAll(params.tags)",
                            "lang": "painless",
                            "params": {
                                "tags": tagNames,
                            }
                        }
                    }
                });
            }
            if (doc) {
                const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
                await module_3.create({ activityType: "SUGGEST_TAGS_REMOVE_APPROVED", activityBy: userId, documentId: docId, tagsRemoved: body.tags });
                module_2.create({ notificationType: `DOCUMENTS`, userId: body.userId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.approveRemoveTagNotification(docdetails.name), from: userId });
                module_4.sendNotification({ id: body.userId, fullName: ownerName, userName, mobileNo, email: userDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "approveTagNotification", mobileTemplateName: "approveTagNotification" });
                return {
                    sucess: true,
                    message: "Tag Removal approved successfully"
                };
            }
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.approveTags = approveTags;
;
async function rejectTags(docId, body, userId) {
    try {
        if (!docId || !body.userId || (!body.tagIdToAdd && !body.tagIdToRemove)) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        }
        let docdetails = await model_1.documents.findById(docId);
        if (!docdetails) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        }
        let usersData = await users_1.userFindMany("_id", [userId, body.userId], { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
        let ownerDetails = usersData.find((user) => userId == user._id);
        let ownerName = `${ownerDetails.firstName} ${ownerDetails.middleName || ""} ${ownerDetails.lastName || ""}`;
        let userDetails = usersData.find((user) => body.userId == user._id);
        let userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        if (body.tagIdToAdd) {
            let [filteredDoc, filteredDoc1] = await Promise.all([
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId == body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToAdd)
                    };
                }),
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId != body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocs = [...filteredDoc, ...filteredDoc1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, {
                suggestTagsToAdd: filteredDocs,
                "$push": {
                    rejectedTags: { userId: body.userId, tags: body.tagId }
                }
            });
            if (doc) {
                const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
                await module_3.create({ activityType: "SUGGEST_TAGS_ADD_REJECTED", activityBy: userId, documentId: docId, tagsRemoved: body.tagIdToAdd });
                module_2.create({ notificationType: `DOCUMENTS`, userId: body.userId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.rejectTagNotification(docdetails.name), from: userId });
                module_4.sendNotification({ id: body.userId, fullName: ownerName, userName, mobileNo, email: userDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "rejectTagNotification", mobileTemplateName: "rejectTagNotification" });
                return {
                    sucess: true,
                    message: "Tag Adding Rejected"
                };
            }
        }
        if (body.tagIdToRemove) {
            let [filteredDoc, filteredDoc1] = await Promise.all([
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId == body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToRemove)
                    };
                }),
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId != body.userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocs = [...filteredDoc, ...filteredDoc1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, {
                suggestTagsToRemove: filteredDocs,
            });
            if (doc) {
                const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
                await module_3.create({ activityType: "SUGGEST_TAGS_REMOVE_REJECTED", activityBy: userId, documentId: docId, tagsRemoved: body.tagIdToAdd });
                module_2.create({ notificationType: `DOCUMENTS`, userId: body.userId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.rejectRemoveTagNotification(docdetails.name), from: userId });
                module_4.sendNotification({ id: body.userId, fullName: ownerName, userName, mobileNo, email: userDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "rejectTagNotification", mobileTemplateName: "rejectTagNotification" });
                return {
                    sucess: true,
                    message: "Tag Removing Rejected"
                };
            }
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.rejectTags = rejectTags;
;
async function mailAllCmpUsers(type, docDetails, allcmp = true, actionUser, text) {
    try {
        let selectFields = { email: true, firstName: true, middleName: true, lastName: true, phone: true, is_active: true, countryCode: true };
        let users, sharedUsers, role;
        if (allcmp) {
            users = await users_1.userList({ is_active: true, emailVerified: true }, selectFields);
        }
        else {
            let docInvited = await invitePeopleList(docDetails._id);
            if (Array.isArray(text))
                docInvited.concat(text);
            let userIds = docInvited.filter((obj) => obj.type == "user").map(({ id }) => id);
            let groupIds = docInvited.filter((obj) => obj.type == "group").map(({ id }) => id);
            let groupUsers = await Promise.all(groupIds.map((group) => groups_1.groupUserList(group)));
            userIds = userIds.concat(groupUsers.reduce((main, curr) => main.concat(curr), []));
            users = await users_1.userFindMany("_id", userIds, selectFields);
            if (type == "invitePeopleDoc" || type == "invitePeopleEditDoc" || type == "invitePeopleRemoveDoc") {
                let actionedUsers = users.filter((user) => text.some((acUser) => acUser.id == user._id)).map((user) => `${user.firstName} ${user.middleName || ""} ${user.lastName || ""}`);
                users = users.filter((user) => docDetails.ownerId == user._id);
                sharedUsers = actionedUsers.length == 1 ? actionedUsers[0] : `${actionedUsers.slice(0, actionedUsers.lastIndexOf(",")) + " and " + actionedUsers.slice(actionedUsers.lastIndexOf(",") + 1)}`;
                role = text[0].role;
            }
        }
        if (users.length) {
            let allMailContent = await Promise.all(users.map(async (user) => {
                let fullName = `${user.firstName} ${user.middleName || ""} ${user.lastName || ""}`;
                let notificationMessage = web_notification_messages_1.DOC_NOTIFICATIONS[type](docDetails.name);
                if (type == "invitePeopleDoc")
                    notificationMessage = web_notification_messages_1.DOC_NOTIFICATIONS.invitePeopleDoc(sharedUsers, role, docDetails.name);
                if (type == "documentUpdate")
                    notificationMessage = web_notification_messages_1.DOC_NOTIFICATIONS.documentUpdate(text, docDetails.name);
                module_2.create({ notificationType: `DOCUMENTS`, userId: user._id, docId: docDetails._id, title: notificationMessage, from: actionUser });
                module_4.sendNotification({
                    id: user._id,
                    fullName, text,
                    userName: fullName,
                    sharedUsers, role,
                    mobileNo: user.phone,
                    email: user.email,
                    documentName: docDetails.name,
                    documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docDetails._id}`,
                    templateName: type,
                    mobileTemplateName: type
                });
            }));
            return true;
        }
        return false;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.mailAllCmpUsers = mailAllCmpUsers;
;
async function deleteSuggestedTag(docId, body, userId) {
    try {
        if (!docId || (!body.tagIdToAdd && !body.tagIdToRemove)) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        }
        let docdetails = await model_1.documents.findById(docId);
        if (!docdetails) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        }
        if (body.tagIdToAdd) {
            let [filteredDoc, filteredDoc1] = await Promise.all([
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId == userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToAdd)
                    };
                }),
                docdetails.suggestTagsToAdd.filter((tag) => tag.userId != userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocs = [...filteredDoc, ...filteredDoc1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, {
                suggestTagsToAdd: filteredDocs
            });
            if (doc) {
                await module_3.create({ activityType: "SUGGEST_TAGS_ADDED_MODIFIED", activityBy: userId, documentId: docId, tagsRemoved: body.tagIdToAdd });
                return {
                    sucess: true,
                    message: "Tag removed Successfully"
                };
            }
        }
        if (body.tagIdToRemove) {
            let [filteredDoc, filteredDoc1] = await Promise.all([
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId == userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags.filter((tag) => tag != body.tagIdToRemove)
                    };
                }),
                docdetails.suggestTagsToRemove.filter((tag) => tag.userId != userId).map((_respdata) => {
                    return {
                        userId: _respdata.userId,
                        tags: _respdata.tags
                    };
                })
            ]);
            let filteredDocs = [...filteredDoc, ...filteredDoc1];
            let doc = await model_1.documents.findByIdAndUpdate(docId, {
                suggestTagsToRemove: filteredDocs
            });
            if (doc) {
                await module_3.create({ activityType: "SUGGEST_TAGS_ADDED_MODIFIED", activityBy: userId, documentId: docId, tagsRemoved: body.tagIdToAdd || body.tagIdToRemove });
                return {
                    sucess: true,
                    message: "Tag removed Successfully"
                };
            }
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.deleteSuggestedTag = deleteSuggestedTag;
;
async function getAllRequest(docId) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let requestData = await document_request_model_1.docRequestModel.find({ docId: mongoose_1.Types.ObjectId(docId), isDelete: false }).populate(docId);
        return await Promise.all(requestData.map((request) => RequestList(request.toJSON())));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getAllRequest = getAllRequest;
;
async function RequestList(request) {
    try {
        return Object.assign({}, request, { requestedBy: await users_1.userFindOne("id", request.requestedBy, {}) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function requestAccept(requestId, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(requestId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let requestDetails = await document_request_model_1.docRequestModel.findById(requestId).populate("docId").exec();
        if (userObj._id != requestDetails.docId.ownerId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED);
        let capability = await documnetCapabilities(requestDetails.docId.id, requestDetails.requestedBy);
        let addedCapability;
        if (capability.includes("no_access")) {
            addedCapability = await groups_1.shareDoc(requestDetails.requestedBy, "user", requestDetails.docId.id, "viewer");
        }
        else if (capability.includes("viewer")) {
            let userCapability = await groups_1.GetDocCapabilitiesForUser(requestDetails.requestedBy, requestDetails.docId.id);
            if (userCapability.length)
                await groups_1.groupsRemovePolicy(`user/${requestDetails.requestedBy}`, requestDetails.docId.id, "viewer");
            addedCapability = await groups_1.groupsAddPolicy(`user/${requestDetails.requestedBy}`, requestDetails.docId.id, "collaborator");
        }
        else {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_ACTION_PERFORMED);
        }
        await module_3.create({ activityType: "REQUEST_APPROVED", activityBy: userObj._id, documentId: requestDetails.docId.id, requestUserId: requestDetails.requestedBy });
        module_2.create({ notificationType: `DOCUMENTS`, userId: requestDetails.requestedBy, docId: requestDetails.docId.id, title: web_notification_messages_1.DOC_NOTIFICATIONS.documentRequestApproved(requestDetails.docId.name), from: userObj._id });
        if (addedCapability && addedCapability.user.length) {
            await document_request_model_1.docRequestModel.findByIdAndUpdate(requestId, { $set: { isDelete: true } });
            return { message: "Shared successfully." };
        }
        throw new Error(error_msg_1.DOCUMENT_ROUTER.SOMETHING_WENT_WRONG);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.requestAccept = requestAccept;
;
async function requestDenied(requestId, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(requestId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let requestDetails = await document_request_model_1.docRequestModel.findById(requestId).populate("docId").exec();
        if (userObj._id != requestDetails.docId.ownerId)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED);
        let success = await document_request_model_1.docRequestModel.findByIdAndUpdate(requestId, { $set: { isDelete: true } }, {});
        await module_3.create({ activityType: "REQUEST_DENIED", activityBy: userObj._id, documentId: requestDetails.docId.id, requestUserId: requestDetails.requestedBy });
        module_2.create({ notificationType: `DOCUMENTS`, userId: requestDetails.requestedBy, docId: requestDetails.docId.id, title: web_notification_messages_1.DOC_NOTIFICATIONS.documentRequestRejected(requestDetails.docId.name), from: userObj._id });
        return success;
    }
    catch (err) {
        throw err;
    }
}
exports.requestDenied = requestDenied;
async function requestRaise(docId, userId) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId) || !mongoose_1.Types.ObjectId.isValid(userId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_OR_MISSING_DATA);
        let docDetails = await model_1.documents.findById(docId);
        if (!docDetails || docDetails.parentId || docDetails.status == 2)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.INVALID_FILE_ID);
        let existRequest = await document_request_model_1.docRequestModel.findOne({ requestedBy: userId, docId: docId, isDelete: false });
        if (existRequest)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.ALREADY_REQUEST_EXIST);
        await module_3.create({ activityType: "REQUEST_DOCUMENT", activityBy: userId, documentId: docId });
        module_2.create({ notificationType: `DOCUMENTS`, userId: docDetails.owner, docId: docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.documentRequest(docDetails.name), from: userId });
        return await document_request_model_1.docRequestModel.create({ requestedBy: userId, docId: docId });
    }
    catch (err) {
        throw err;
    }
}
exports.requestRaise = requestRaise;
//  Get All Cmp Documents List
async function getAllCmpDocs(page = 1, limit = 30, host, userId, pagination = true) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "view-all-cmp-documents");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
        }
        let data = await model_1.documents.find({ parentId: null, status: { $ne: STATUS.DRAFT } }).collation({ locale: 'en' }).sort({ name: 1 });
        const docList = await Promise.all(data.map(async (doc) => docData(doc, host)));
        if (pagination)
            return manualPagination(page, limit, docList);
        return docList;
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getAllCmpDocs = getAllCmpDocs;
async function replaceDocumentUser(ownerId, newOwnerId, userObj) {
    try {
        let userDetails = await users_1.userFindOne("id", newOwnerId, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
        let userName;
        if (userDetails.firstName)
            userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        else {
            userName = userDetails.name;
        }
        let sharedDocIds = (await groups_1.GetDocIdsForUser(ownerId)).filter(id => mongoose_1.Types.ObjectId.isValid(id));
        let [mydocs, sharedDocs] = await Promise.all([
            model_1.documents.find({ ownerId: ownerId, parentId: null, isDeleted: false, status: { $ne: STATUS.DRAFT } }).exec(),
            model_1.documents.find({ _id: { $in: sharedDocIds }, isDeleted: false }).exec()
        ]);
        await Promise.all(mydocs.map((doc) => {
            changeOwnerShip(doc, ownerId, newOwnerId, userObj),
                replaceUserInES(doc.id, newOwnerId, userName);
        }));
        // await Promise.all(sharedDocs.map((doc: any) => changeSharedOwnerShip(doc, ownerId, newOwnerId, userObj)))
        return { success: true };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.replaceDocumentUser = replaceDocumentUser;
;
async function changeOwnerShip(doc, ownerId, newOwnerId, userObj) {
    try {
        let capability = await documnetCapabilities(doc._id, newOwnerId);
        if (["no_access", "publish", "viewer"].includes(capability[0])) {
            let document = await groups_1.groupsAddPolicy(`user/${newOwnerId}`, doc._id, "collaborator");
            // await create({
            //   activityType: "CHANGE_OWNERSHIP",
            //   activityBy: userObj._id,
            //   documentId: doc._id,
            //   documentAddedUsers: [{ id: newOwnerId, type: "user", role: "owner" }],
            //   documentRemovedUsers: [{ id: ownerId, type: "user", role: "owner" }]
            // })
        }
        return { success: true, doc: doc._id };
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function changeSharedOwnerShip(doc, ownerId, newOwnerId, userObj) {
    try {
        let [addingUserCapability, existingUserCapability] = await Promise.all([
            documnetCapabilities(doc._id, newOwnerId),
            documnetCapabilities(doc._id, ownerId)
        ]);
        const newOwnerCapabilityNumber = getCapabilityPriority(addingUserCapability[0]);
        const oldOwnerCapabilityNumber = getCapabilityPriority(existingUserCapability[0]);
        // Removing existing user capability for the doc
        await groups_1.groupsRemovePolicy(`user/${ownerId}`, doc._id, existingUserCapability[0]);
        // If the Old user capability is higher than adding user capability
        if (oldOwnerCapabilityNumber > newOwnerCapabilityNumber) {
            if (newOwnerCapabilityNumber)
                await groups_1.groupsRemovePolicy(`user/${newOwnerId}`, doc._id, addingUserCapability[0]);
            await groups_1.groupsAddPolicy(`user/${newOwnerId}`, doc._id, existingUserCapability[0]);
        }
        await module_3.create({
            activityType: "REPLACE_USER",
            activityBy: userObj._id,
            documentId: doc._id,
            documentAddedUsers: [{ id: newOwnerId, type: "user", role: existingUserCapability[0] }],
            documentRemovedUsers: [{ id: ownerId, type: "user", role: existingUserCapability[0] }]
        });
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
;
function getCapabilityPriority(capability) {
    let capabilityNumber = 1;
    switch (capability) {
        case 'collaborator':
            capabilityNumber = 2;
            break;
        case 'owner':
            capabilityNumber = 3;
            break;
        case 'no_access':
            capabilityNumber = 0;
            break;
        default:
            break;
    }
    return capabilityNumber;
}
async function getAllPublicDocuments(currentPage = 1, limit = 20, host) {
    // const isEligible = await checkRoleScope(userRole, 'view-all-public-documents')
    // if(!isEligible){
    //   throw new APIError(DOCUMENT_ROUTER.VIEW_PUBLIC_DOCS_DENIED)
    // }
    let { docs, page, pages } = await model_1.documents.paginate({ isPublic: true }, { page: currentPage, limit });
    docs = await Promise.all(docs.map(doc => docData(doc, host)));
    return {
        docs,
        page,
        pages
    };
}
exports.getAllPublicDocuments = getAllPublicDocuments;
async function markDocumentAsPublic(docId, userRole) {
    const [isEligible, docDetail] = await Promise.all([
        role_management_1.checkRoleScope(userRole, 'mark-as-public-document'),
        model_1.documents.findById(docId).exec()
    ]);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.VIEW_PUBLIC_DOCS_DENIED);
    }
    if (docDetail.status != 2) {
        throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNABLE_TO_MAKE_PUBLIC_DOCUMENT);
    }
    await model_1.documents.findByIdAndUpdate(docId, { $set: { isPublic: true } }).exec();
    await model_1.documents.updateMany({ parentId: docId }, { $set: { isPublic: true } }).exec();
    return { message: 'success' };
}
exports.markDocumentAsPublic = markDocumentAsPublic;
async function markDocumentAsUnPublic(docId, userRole) {
    const [isEligible, docDetail] = await Promise.all([
        role_management_1.checkRoleScope(userRole, 'mark-as-unpublic-document'),
        model_1.documents.findById(docId).exec()
    ]);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.VIEW_PUBLIC_DOCS_DENIED);
    }
    await model_1.documents.findByIdAndUpdate(docId, { $set: { isPublic: false } }).exec();
    await model_1.documents.updateMany({ parentId: docId }, { $set: { isPublic: false } }).exec();
    return { message: 'success' };
}
exports.markDocumentAsUnPublic = markDocumentAsUnPublic;
async function suggestTagsToAddOrRemove(docId, body, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "suggest-tag");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UNAUTHORIZED, 403);
        }
        if (!body.addTags && !body.removeTags) {
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        }
        let [docData, child] = await Promise.all([
            model_1.documents.findById(docId).exec(),
            model_1.documents.find({ parentId: docId, isDeleted: false }).sort({ createdAt: -1 }).exec()
        ]);
        if (!docData)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENTS_NOT_THERE);
        if (!child.length)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.CHILD_NOT_FOUND);
        let usersData = await users_1.userFindMany("_id", [docData.ownerId, userId], { firstName: 1, middleName: 1, lastName: 1, email: 1 });
        let ownerDetails = usersData.find((user) => docData.ownerId == user._id);
        let ownerName = `${ownerDetails.firstName} ${ownerDetails.middleName || ""} ${ownerDetails.lastName || ""}`;
        let userDetails = usersData.find((user) => userId == user._id);
        let userName = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
        let addSuggestedTagsExist = docData.suggestTagsToAdd.filter(({ userId: user }) => user == userId).map(({ tags }) => tags).reduce((main, curr) => main.concat(curr), []);
        let removeSuggestedTagsExist = docData.suggestTagsToRemove.filter(({ userId: user }) => user == userId).map(({ tags }) => tags).reduce((main, curr) => main.concat(curr), []);
        let [doc, childUpdate] = await Promise.all([
            model_1.documents.findByIdAndUpdate(docId, {
                "$push": {
                    suggestTagsToAdd: { userId: userId, tags: body.addTags },
                    suggestTagsToRemove: { userId: userId, tags: body.removeTags }
                }
            }).exec(),
            model_1.documents.findByIdAndUpdate(child[child.length - 1]._id, {
                "$push": {
                    suggestTagsToAdd: { userId: userId, tags: body.addTags },
                    suggestedTagsToRemove: { userId: userId, tags: body.removeTags }
                }
            }).exec()
        ]);
        if (doc) {
            const { mobileNo, fullName } = module_4.getFullNameAndMobile(userDetails);
            let addedTags = body.addTags.filter((tag) => !addSuggestedTagsExist.includes(tag));
            let removedTags = body.removeTags.filter((tag) => !removeSuggestedTagsExist.includes(tag));
            if (addedTags.length || removedTags.length) {
                await module_3.create({ activityType: "SUGGEST_MODIFIED_TAGS", activityBy: userId, documentId: docId, tagsAdded: body.addTags, tagsRemoved: body.removeTags });
                module_2.create({ notificationType: `DOCUMENTS`, userId: doc.ownerId, docId, title: web_notification_messages_1.DOC_NOTIFICATIONS.suggestTagNotification(doc.name), from: userId });
                module_4.sendNotification({ id: userId, fullName: ownerName, userName, mobileNo, email: ownerDetails.email, documentUrl: `${urls_1.ANGULAR_URL}/home/resources/doc/${docId}`, templateName: "suggestTagNotification", mobileTemplateName: "suggestTagNotification" });
            }
            return {
                sucess: true,
                message: "Tag suggested successfully"
            };
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.suggestTagsToAddOrRemove = suggestTagsToAddOrRemove;
;
async function renameFolder(folderId, body, userId) {
    try {
        // let folderId =  Types.ObjectId(id)
        if (!body.name)
            throw new Error(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
        let folder = await folder_model_1.folders.findByIdAndUpdate({ _id: folderId, ownerId: userId }, { name: body.name }, { new: true }).exec();
        return { success: true, folder: folder };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.renameFolder = renameFolder;
async function searchDoc(search, userId, page = 1, limit = 30, pagination = true, searchAllCmp = false) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        let data;
        const isEligible = await role_management_1.checkRoleScope(userRole, "view-all-cmp-documents");
        if (isEligible && searchAllCmp) {
            if (search == (null || "")) {
                data = {
                    query: {
                        "match_all": {}
                    }
                };
            }
            else {
                data = {
                    query: {
                        multi_match: {
                            "query": search,
                            "fields": ['name', 'description', 'userName', 'tags', 'type', 'groupName', 'fileName'],
                            "type": 'bool_prefix'
                        }
                    }
                };
            }
        }
        else {
            if (search == (null || "")) {
                data = {
                    query: {
                        multi_match: { "query": `${userId} 2`, "fields": ['accessedBy', 'status'] },
                    }
                };
            }
            else {
                data = {
                    query: {
                        bool: {
                            "should": [
                                {
                                    "bool": {
                                        "must": [
                                            { multi_match: { "query": search, "fields": ['name', 'description', 'userName', 'tags', 'type', 'fileName', 'groupName'], type: 'bool_prefix' } },
                                            { multi_match: { "query": `${userId} 2`, "fields": ['accessedBy', 'status'] } },
                                        ]
                                    }
                                }
                            ]
                        }
                    }
                };
            }
        }
        let searchdoc = await esClient.search({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            size: 1000,
            body: data
        });
        let searchResult = searchdoc.hits.hits.map((doc) => {
            return {
                _id: doc._source.id,
                accessedBy: doc._source.accessedBy,
                userName: doc._source.userName,
                name: doc._source.name,
                description: doc._source.description,
                tags: doc._source.tags,
                thumbnail: doc._source.thumbnail,
                status: doc._source.status,
                fileName: doc._source.fileName,
                updatedAt: doc._source.updatedAt,
                createdAt: doc._source.createdAt,
                groupId: doc._source.groupId,
                groupName: doc._source.groupName,
                createdByMe: doc._source.createdBy == userId
            };
        });
        if (pagination == true)
            return manualPagination(page, limit, searchResult);
        else
            return { docs: searchResult };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.searchDoc = searchDoc;
async function updateUserInDOcs(id, userId) {
    try {
        // let userIds, userNames;
        let collaboratedDocsIds = await groups_1.GetDocIdsForUser(id, "user", ["collaborator", "owner"]);
        let userIds = await Promise.all(collaboratedDocsIds.map(async (docId) => {
            return {
                docId: docId,
                collaboratorIds: await groups_1.GetUserIdsForDocWithRole(docId, "collaborator"),
                ownerIds: await groups_1.GetUserIdsForDocWithRole(docId, "owner"),
                viewerIds: await groups_1.GetUserIdsForDocWithRole(docId, "viewer")
            };
        }));
        let idsToUpdate = await Promise.all(userIds.map(async (user) => {
            return {
                docId: user.docId,
                userNames: await Promise.all([...user.collaboratorIds, ...user.ownerIds].map(async (eachuser) => {
                    let userId = eachuser.split('/')[1];
                    let userDetails = await users_1.userFindOne("id", userId, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
                    if (userDetails) {
                        if (userDetails.firstName)
                            return `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
                        else
                            return userDetails.name;
                    }
                })),
                userIds: [...user.collaboratorIds, ...user.ownerIds, ...user.viewerIds].map((eachuser) => {
                    return eachuser.split('/')[1];
                })
            };
        }));
        let allDocs = await esClient.search({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            size: 1000,
            body: {
                query: {
                    "match_all": {}
                }
            }
        });
        let docIds = allDocs.hits.hits.map((doc) => { return doc._id; });
        let updateUsers = await Promise.all(idsToUpdate.map(async (user) => {
            if (docIds.includes(user.docId)) {
                return await esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: user.docId,
                    body: {
                        "script": {
                            "source": "ctx._source.accessedBy=(params.userId);ctx._source.userName=(params.userNames)",
                            "lang": "painless",
                            "params": {
                                "userId": user.userIds,
                                "userNames": user.userNames
                            }
                        }
                    }
                });
            }
        }));
        return { userIds, collaboratedDocsIds, idsToUpdate, updateUsers };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.updateUserInDOcs = updateUserInDOcs;
async function updateTagsInDOcs(bodyObj, userId) {
    try {
        let allDocs = await esClient.search({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            size: 1000,
            body: {
                query: {
                    "match_all": {}
                }
            }
        });
        let docIds = allDocs.hits.hits.map((doc) => { return doc._id; });
        let updateTags = await Promise.all(bodyObj.map(async (tag) => {
            if (docIds.includes(tag.docId)) {
                return await esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: tag.docId,
                    body: {
                        "script": {
                            "source": "ctx._source.tags=(params.tags)",
                            "lang": "painless",
                            "params": {
                                "tags": tag.tags
                            }
                        }
                    }
                });
            }
        }));
        return { updateTags };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.updateTagsInDOcs = updateTagsInDOcs;
async function checkDocIdExistsInEs(docId) {
    let checkDoc = await esClient.search({
        index: `${ELASTIC_SEARCH_INDEX}_documents`,
        size: 1000,
        body: {
            query: {
                "match": { id: docId }
            }
        }
    });
    if (checkDoc.hits.hits.length) {
        return true;
    }
    else {
        return false;
    }
}
async function addGroupMembersInDocs(id, groupUserIds, userId) {
    try {
        let groupDocIds = await groups_1.GetDocIdsForUser(id, "group", ["collaborator", "viewer", "owner"]);
        let idsToUpdate = await Promise.all(groupDocIds.map(async (docId) => {
            return {
                docId: docId,
                userNames: await Promise.all(groupUserIds.map(async (eachuser) => {
                    let userDetails = await users_1.userFindOne("id", eachuser, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
                    if (userDetails) {
                        if (userDetails.firstName)
                            return `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
                        else
                            return userDetails.name;
                    }
                })),
                userIds: groupUserIds
            };
        }));
        let allDocs = await esClient.search({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            size: 1000,
            body: {
                query: {
                    "match_all": {}
                }
            }
        });
        let docIds = allDocs.hits.hits.map((doc) => { return doc._id; });
        let updateUsers = Promise.all(idsToUpdate.map(async (user) => {
            if (docIds.includes(user.docId)) {
                return esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: user.docId,
                    body: {
                        "script": {
                            "source": "ctx._source.accessedBy.addAll(params.userId);ctx._source.userName.addAll(params.userNames)",
                            "lang": "painless",
                            "params": {
                                "userId": user.userIds,
                                "userNames": user.userNames
                            }
                        }
                    }
                });
            }
        }));
        return { idsToUpdate, updateUsers };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.addGroupMembersInDocs = addGroupMembersInDocs;
async function removeGroupMembersInDocs(id, groupUserId, userId) {
    try {
        let groupDocIds = await groups_1.GetDocIdsForUser(id, "group", ["collaborator", "viewer", "owner"]);
        let idsToUpdate = await Promise.all(groupDocIds.map(async (docId) => {
            let userDetails = await users_1.userFindOne("id", groupUserId, { firstName: 1, middleName: 1, lastName: 1, name: 1 });
            if (userDetails) {
                if (userDetails.firstName)
                    userDetails = `${userDetails.firstName} ${userDetails.middleName || ""} ${userDetails.lastName || ""}`;
                else
                    userDetails = userDetails.name;
            }
            return {
                docId: docId,
                userName: userDetails,
                userId: groupUserId
            };
        }));
        let allDocs = await esClient.search({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            size: 1000,
            body: {
                query: {
                    "match_all": {}
                }
            }
        });
        let docIds = allDocs.hits.hits.map((doc) => { return doc._id; });
        let updateUsers = await Promise.all(idsToUpdate.map(async (user) => {
            if (docIds.includes(user.docId)) {
                return esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: user.docId,
                    body: {
                        "script": {
                            "inline": "ctx._source.accessedBy.remove(ctx._source.accessedBy.indexOf(params.userId));ctx._source.userName.remove(ctx._source.userName.indexOf(params.userName))",
                            "lang": "painless",
                            "params": {
                                "userId": user.userId,
                                "userName": user.userName
                            }
                        }
                    }
                });
            }
        }));
        return { idsToUpdate, updateUsers };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.removeGroupMembersInDocs = removeGroupMembersInDocs;
async function getDocsAndInsertInCasbin(host) {
    const docs = await model_1.documents.find({ status: { $ne: 0 }, parentId: null, isDeleted: false }).exec();
    const finalData = await Promise.all(docs.map(doc => getShareInfoForEachDocument(doc, host)));
    let insert = await Promise.all(finalData.map(async (doc) => {
        return esClient.index({
            index: `${process.env.ELASTIC_SEARCH_INDEX}_documents`,
            body: doc,
            id: doc.id
        });
    }));
    return insert;
    // return doc;
    // connect to elastic search, remove old doc data & add finalData
}
exports.getDocsAndInsertInCasbin = getDocsAndInsertInCasbin;
async function getShareInfoForEachDocument(doc, host) {
    const [collaboratorIds, viewerIds, ownerIds] = await Promise.all([
        groups_1.GetUserIdsForDocWithRole(doc.id, 'collaborator'),
        groups_1.GetUserIdsForDocWithRole(doc.id, 'viewer'),
        groups_1.GetUserIdsForDocWithRole(doc.id, 'owner')
    ]);
    const userIds = Array.from(new Set([
        ...collaboratorIds.map((collaboratorId) => collaboratorId.split(`/`)[1]),
        ...ownerIds.map((ownerId) => ownerId.split(`/`)[1]),
        ...viewerIds.map((viewerId) => viewerId.split(`/`)[1])
    ]));
    const usersInfo = await users_1.userFindMany(`_id`, userIds, { firstName: 1, middleName: 1, lastName: 1 });
    const fetchedUserIds = usersInfo.map(user => user._id);
    const groupIds = userIds.filter(userId => !fetchedUserIds.includes(userId));
    let groupMembers = await Promise.all(groupIds.map(groupId => groups_1.groupUserList(groupId)));
    groupMembers = groupMembers.reduce((p, c) => [...p, ...c], []);
    const [groupMembersInfo, groupsInfo, tagsData] = await Promise.all([
        users_1.userFindMany(`_id`, groupMembers),
        users_1.groupsFindMany('_id', groupIds),
        tag_model_1.tags.find({ _id: { $in: doc.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) } }).exec()
    ]);
    const userNames = Array.from(new Set(usersInfo.concat(groupMembersInfo))).map(userInfo => (`${userInfo.firstName} ${userInfo.middleName || ``} ${userInfo.lastName}`) || `${userInfo.name}`);
    let fileType = doc.fileName ? (doc.fileName.split(".")).pop() : "";
    return {
        docId: doc.id,
        accessedBy: userIds,
        userName: userNames,
        name: doc.name,
        description: doc.description,
        tags: tagsData.map((tag) => tag.tag),
        thumbnail: (fileType == "jpg" || fileType == "jpeg" || fileType == "png") ? `${host}/api/docs/get-document/${doc.fileId}` : "N/A",
        status: doc.status,
        fileName: doc.fileName,
        updatedAt: doc.updatedAt,
        createdAt: doc.createdAt,
        id: doc.id,
        groupId: groupIds,
        groupName: groupsInfo.map((group) => group.name),
        createdBy: doc.ownerId
    };
}
//  Get Doc Details
async function getDocDetailsForSuccessResp(docId, userId, token, allCmp) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(docId))
            throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCID_NOT_VALID);
        let publishDocs = await model_1.documents.findById(docId);
        const allCmp = await role_management_1.checkRoleScope(((await module_1.userRoleAndScope(userId)).data || [""])[0], "view-all-cmp-documents");
        if (!allCmp) {
            if (publishDocs.isDeleted)
                throw new Error(error_msg_1.DOCUMENT_ROUTER.DOCUMENT_DELETED(publishDocs.name));
            if (publishDocs.status != 2 && publishDocs.parentId == null) {
                let userCapability = await documnetCapabilities(publishDocs.parentId || publishDocs._id, userId);
                if (!userCapability.length)
                    throw new Error(error_msg_1.DOCUMENT_ROUTER.USER_HAVE_NO_ACCESS);
            }
        }
        let filteredDocs;
        let filteredDocsToRemove;
        const docList = publishDocs.toJSON();
        if (docList.parentId) {
            let parentDoc = await model_1.documents.findById(docList.parentId);
            docList.tags = parentDoc.tags;
            docList.suggestedTags = parentDoc.suggestedTags,
                docList.suggestTagsToAdd = parentDoc.suggestTagsToAdd,
                docList.suggestTagsToRemove = parentDoc.suggestTagsToRemove;
        }
        if (docList.ownerId == userId) {
            filteredDocs = docList.suggestTagsToAdd;
            filteredDocsToRemove = docList.suggestTagsToRemove;
        }
        else {
            filteredDocs = docList.suggestTagsToAdd.filter((tag) => tag.userId == userId);
            filteredDocsToRemove = docList.suggestTagsToRemove.filter((tag) => tag.userId == userId);
        }
        const userData = Array.from(new Set(filteredDocs.map((_respdata) => _respdata.userId))).map((userId) => ({
            userId,
            tags: filteredDocs
                .filter((_respdata) => _respdata.userId == userId)
                .reduce((resp, eachTag) => [...resp, ...eachTag.tags], [])
        }));
        let users = await Promise.all(userData.map((suggestedTagsInfo) => userInfo(suggestedTagsInfo)));
        docList.suggestTagsToAdd = users;
        const userDataForRemoveTag = Array.from(new Set(filteredDocsToRemove.map((_respdata) => _respdata.userId))).map((userId) => ({
            userId,
            tags: filteredDocsToRemove
                .filter((_respdata) => _respdata.userId == userId)
                .reduce((resp, eachTag) => [...resp, ...eachTag.tags], [])
        }));
        let usersDataForRemoveTag = await Promise.all(userDataForRemoveTag.map((suggestedTagsInfo) => userInfo(suggestedTagsInfo)));
        docList.suggestTagsToRemove = usersDataForRemoveTag;
        let [tagObjects, ownerRole, ownerObj, taskDetailsObj] = await Promise.all([
            getTags((docList.tags && docList.tags.length) ? docList.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []),
            module_1.userRoleAndScope(docList.ownerId),
            users_1.userFindOne("id", docList.ownerId, { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 }),
            utils_1.getTasksForDocument(docList.parentId || docList._id, token)
        ]);
        // await create({ activityType: `DOCUMENT_VIEWED`, activityBy: userId, documentId: docId })
        return Object.assign({}, docList, { tags: tagObjects, role: (ownerRole.data || [""])[0], owner: Object.assign({}, ownerObj, { role: (ownerRole.data || [""])[0] }), taskDetails: taskDetailsObj, sourceId: docList.sourceId ? await model_1.documents.findById(docList.sourceId).exec() : '' });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.getDocDetailsForSuccessResp = getDocDetailsForSuccessResp;
async function replaceUserInES(docId, newUserId, newUserName) {
    try {
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            let data = esClient.update({
                index: `${ELASTIC_SEARCH_INDEX}_documents`,
                id: docId,
                body: {
                    "script": {
                        "source": "ctx._source.accessedBy.add(params.userId);ctx._source.userName.add(params.userName)",
                        "lang": "painless",
                        "params": {
                            "userId": newUserId,
                            "userName": newUserName
                        }
                    }
                }
            });
            return data;
        }
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.replaceUserInES = replaceUserInES;
async function bulkUploadDocument(filePath, userObj, siteConstants, token) {
    try {
        const excelFormattedData = module_5.importExcelAndFormatData(filePath);
        if (!excelFormattedData.length) {
            throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.UPLOAD_EMPTY_FOLDER);
        }
        let formateExcel = await bulkValidation(excelFormattedData, userObj, siteConstants);
        await Promise.all(formateExcel.map((excelObj) => documentCreateApi(excelObj["Document Name"], path_1.join(__dirname, excelObj.Location, excelObj.Filename), excelObj.Tags ? excelObj.Tags.split() : [], token, userObj)));
        return { success: true, message: "documents created successfully" };
    }
    catch (error) {
        throw error;
    }
}
exports.bulkUploadDocument = bulkUploadDocument;
async function bulkValidation(excelFormattedData, userObj, siteConstants) {
    try {
        let EXCEL_KEYS = ["Document Name", "Access", "Edit Access", "Filename", "Location", "Ownership", "View Access", "Tags"];
        let ACCESS = ["Public Document"];
        let [existDocuments, userObjs] = await Promise.all([
            model_1.documents.find({ isDeleted: false, parentId: null, ownerId: userObj._id }).exec(),
            users_1.userList({ is_active: true, emailVerified: true }, { email: true })
        ]);
        let currentUsers = userObjs.map(({ email }) => email);
        let formateExcel = excelFormattedData.reduce((main, curr) => {
            let currObj = Object.keys(curr).reduce((main, currStr) => (Object.assign({}, main, { [currStr.trim()]: typeof (curr[currStr]) == "string" ? (curr[currStr]).trim() : curr[currStr] })), {});
            return main.concat([currObj]);
        }, []);
        let newDocumentsNames = formateExcel.map((obj) => obj["Document Name"]);
        if (newDocumentsNames.some((name) => newDocumentsNames.indexOf(name) != newDocumentsNames.lastIndexOf(name))) {
            throw new Error("Duplicate document names found.");
        }
        let oldDocsNames = existDocuments.map(({ name }) => name);
        if (newDocumentsNames.some((name) => oldDocsNames.includes(name))) {
            throw new Error("A document found with same name.");
        }
        if (formateExcel.some(({ "Document Name": name }) => name.length > siteConstants.docNameLength)) {
            throw new Error(`Document Name length should less than ${siteConstants.docNameLength}`);
        }
        if (formateExcel.some(({ Access }) => Access && !ACCESS.includes(Access))) {
            throw new Error("Invalid key found in access column");
        }
        if (formateExcel.some(({ Location, Filename }) => !fs_1.existsSync(path_1.join(__dirname, Location, Filename)))) {
            throw new Error("File not Found.");
        }
        if (formateExcel.some(({ Ownership, "View Access": Access, "Edit Access": Edit }) => (!currentUsers.includes(Ownership) || (Access.split()).some((viewer) => !currentUsers.includes(viewer)) ||
            (Edit.split()).some((editor) => !currentUsers.includes(editor))))) {
            throw new Error("user mail not exists in db.");
        }
        if (formateExcel.some(({ Ownership, "View Access": Access, "Edit Access": Edit }) => {
            let docMails = [Ownership, ...(Access.split()), ...(Edit.split())];
            return docMails.some(mail => docMails.indexOf(mail) != docMails.lastIndexOf(mail));
        })) {
            throw new Error("Duplicate mails found in document.");
        }
        return formateExcel;
    }
    catch (err) {
        throw err;
    }
}
async function getTagIdWithNames(tagNames, userObj) {
    let arrayTagObjs = await Promise.all(tagNames.map(tag => getTag(tag)));
    let unCreatedTags = arrayTagObjs.filter((anything) => typeof (anything) == "string");
    unCreatedTags = await Promise.all(unCreatedTags.map((tag) => module_5.add_tag({ tag }, userObj)));
    arrayTagObjs = arrayTagObjs.filter((anything) => typeof (anything) != "string");
    return [...arrayTagObjs, ...unCreatedTags].map(obj => obj.id || typeof (obj._id) != "string" ? obj._id.toString() : obj._id).filter(id => mongoose_1.Types.ObjectId(id));
}
async function getTag(tag) {
    return await tag_model_1.tags.find({ tag }) || tag;
}
async function documentCreateApi(name, filepath, tags, token, userObj) {
    let tagId = await getTagIdWithNames(tags, userObj);
    await request({
        method: "POST",
        url: process.env.CMP_URL || "http://localhost:3000",
        port: 3000,
        headers: {
            "Authorization": "Basic " + token,
            "Content-Type": "multipart/form-data"
        },
        form: {
            "docName": name,
            "upfile": fs_1.readFileSync(filepath),
            "tags": tags
        }
    });
}
//update project names, cities, reference in documents for search.
async function getProjectNamesForES(docId, token) {
    let publishDocs = await model_1.documents.findById(docId);
    const docList = publishDocs.toJSON();
    let taskDetailsObj = utils_1.getTasksForDocument(docList.parentId || docList._id, token);
    let projectIds = taskDetailsObj.filter(({ projectId }) => projectId).map(({ projectId }) => projectId);
    let projectDetails = await project_model_1.project.find({ $or: [{ _id: { $in: projectIds || [] } }, { "funds.released.documents": { $in: [docId] } }, { "funds.utilized.documents": { $in: [docId] } }] }).exec();
    let projectName = [];
    let city = [];
    let reference = [];
    let projects = projectDetails.map((project) => {
        projectName.push(project.name);
        city.push(project.city);
        reference.push(project.reference);
    });
    if (projectName.length) {
        let updatedData = esClient.update({
            index: `${ELASTIC_SEARCH_INDEX}_documents`,
            id: docId,
            body: {
                "script": {
                    "source": "ctx._source.projectName.addAll(params.projectName);ctx._source.city.addAll(params.city);ctx._source.reference.addAll(params.reference);",
                    "lang": "painless",
                    "params": {
                        "projectName": projectName,
                        "city": city,
                        "reference": reference
                    }
                }
            }
        });
    }
}
exports.getProjectNamesForES = getProjectNamesForES;
async function updateGroupInElasticSearch(groupId) {
    let docIds = await groups_1.GetDocIdsForUser(groupId, "group");
    let update = await Promise.all(docIds.map(async (docId) => {
        let groupDetails = await invitePeopleList(docId);
        let groupData = groupDetails && groupDetails.length ? groupDetails.filter((group) => group.type == 'group') : [];
        let groupNames = groupData && groupData.length ? (groupData.map((group) => { return group.Name; })) : [];
        console.log(groupDetails, 'groupDetails');
        console.log(groupData, 'groupData');
        console.log(groupNames, 'groupNames');
        let isDocExists = await checkDocIdExistsInEs(docId);
        if (isDocExists) {
            if (groupNames && groupNames.length) {
                let updatedData = await esClient.update({
                    index: `${ELASTIC_SEARCH_INDEX}_documents`,
                    id: docId,
                    body: {
                        "script": {
                            "source": "ctx._source.groupName=(params.groupName);",
                            "lang": "painless",
                            "params": {
                                "groupName": groupNames
                            }
                        }
                    }
                });
            }
        }
    }));
}
exports.updateGroupInElasticSearch = updateGroupInElasticSearch;
