"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const http_status_codes_1 = require("http-status-codes");
const custom_error_1 = require("../utils/custom-error");
const router = express_1.Router();
const complianceRouter = require("./compliances/router");
const riskRouter = require("../risks/router");
const opportunityRouter = require("./opportunities/router");
const financialRouter = require("./financial-info/router");
//  Add Project
router.post("/create", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createProject(req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Reference code already exists`;
        }
        next(new custom_error_1.FormattedAPIError(err.message, false));
    }
});
// get projects list
router.get("/list", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getProjectsList(res.locals.user._id, req.token, res.locals.user.role, req.query.page, req.query.limit));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//get project details
router.get("/:id/detail", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getProjectDetail(req.params.id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.post(`/:id/add-phases`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addPhaseToProject(req.params.id, req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/list-phases`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.listPhasesOfProject(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-released-installment`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addReleasedInstallment(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-utilized-installment`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addUtilizedInstallment(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/installments`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getInstallments(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/gantt-chart`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.ganttChart(req.params.id, req.token));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  Edit Project
router.post("/:id/edit", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editProject(req.params.id, req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Reference code already exists`;
        }
        next(new custom_error_1.APIError(err.message));
    }
});
router.get("/:id/get-member-roles", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.projectMembers(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Manage Project members
router.post(`/:id/manage-members`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.manageProjectMembers(req.params.id, req.body.members, res.locals.user._id, res.locals.user.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
}).get(`/:id/members`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getProjectMembers(req.params.id, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get("/:id/manage-members/:userId/remove", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.RemoveProjectMembers(req.params.id, req.params.userId, req.token));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.post("/:id/manage-members/replace", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.replaceProjectMember(req.params.id, req.body, req.token));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
    ;
});
router.post(`/:id/add-open-comment`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addOpenComment(req.params.id, res.locals.user, req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/my-open-comments`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.myCommentDetail(req.params.id, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/my-open-comment-history`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getMyOpenCommentsHistory(req.params.id, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/view-commented-users`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getCommentedUsers(req.params.id, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/miscompliance/edit`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editProjectMiscompliance(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/view-all-open-comments`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getAllOpenCOmments(res.locals.user, req.params.id, req.query.userId));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
//  edit status of Project
router.put("/city/code/status/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.city_code_status(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  add tag
router.post("/tag/add", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.add_tag(req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Tag already exists`;
        }
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  edit tag
router.post("/tag/edit/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit_tag(req.params.id, req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Tag already exists`;
        }
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
router.post(`/getTagByIds`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getTagByIds(req.body.ids));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  edit status of tag
router.put("/tag/status/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.tag_status(req.params.id, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  add theme
router.post("/theme/add", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.add_theme(req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  edit tag
router.post("/theme/edit/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.edit_theme(req.params.id, req.body));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  list of tag
router.get("/theme/list", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.theme_list());
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
//  edit status of tag
router.put("/theme/status/:id", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.theme_status(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
        ;
    }
});
// add task
router.post("/:id/create-task", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createTask(req.body, req.params.id, req.token, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// add task
router.get("/:id/task-list", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getProjectTasks(req.params.id, req.token));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
router.get(`/:id/task/:task_id/view`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getTaskDetail(req.params.id, req.params.task_id, res.locals.user._id, req.token));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/task/:task_id/edit-date`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editTask(req.params.id, req.params.task_id, res.locals.user, req.token, req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/link-task`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.linkTask(req.params.id, req.body.taskId, req.token, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/task-project-detail`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.taskProjectDetails(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/financial-info`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getFinancialInfo(req.params.id, res.locals.user._id, res.locals.user.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-released-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addFundReleased(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-utilized-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addFundsUtilized(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/update-released-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.updateReleasedFund(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/update-utilized-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.updateUtilizedFund(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/delete-released-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.deleteReleasedFund(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/delete-utilized-fund`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.deleteUtilizedFund(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.use(`/`, complianceRouter);
router.use(`/`, riskRouter);
router.use(`/`, opportunityRouter);
router.use('/', financialRouter);
const multer = require("multer");
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        console.log("Dest");
        cb(null, (__dirname + '/uploads/'));
    },
    filename: function (req, file, cb) {
        cb(null, file.fieldname + '-' + Date.now() + file.originalname);
    }
});
const upload = multer({ storage });
router.post(`/:id/upload-task-excel`, upload.single('upfile'), async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.uploadTasksExcel(req.file.path, req.params.id, req.token, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put("/:id/project-cost", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.projectCostInfo(req.params.id, req.body.projectCost, res.locals.user.role, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put("/:id/citiis-grants", async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.citiisGrantsInfo(req.params.id, req.body.citiisGrants, res.locals.user.role, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/edit-tripartite`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editTriPartiteDate(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-installments`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addInstallments(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-funds`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addFunds(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/financial-info/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getFinancialInfoNew(req.params.id, res.locals.user._id, res.locals.user.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/update-released-fund/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.updateReleasedFundNew(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/update-utilized-fund/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.updateUtilizedFundNew(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/delete-released-fund/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.deleteReleasedFundNew(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/delete-utilized-fund/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.deleteUtilizedFundNew(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/:id/add-installments/new`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.addInstallmentsNew(req.params.id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
