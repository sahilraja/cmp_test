"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const error_msg_1 = require("../utils/error_msg");
const project_model_1 = require("./project_model");
const mongoose_1 = require("mongoose");
const tag_model_1 = require("../tags/tag_model");
const theme_model_1 = require("./theme_model");
const module_1 = require("../role/module");
const role_management_1 = require("../utils/role_management");
const urls_1 = require("../utils/urls");
const module_2 = require("../users/module");
const users_1 = require("../utils/users");
const custom_error_1 = require("../utils/custom-error");
const module_3 = require("../log/module");
const module_4 = require("../documents/module");
const fs_1 = require("fs");
const path_1 = require("path");
const xlsx = require("xlsx");
const open_comments_model_1 = require("./open-comments-model");
const model_1 = require("../phase/model");
const model_2 = require("../pillars/model");
const model_3 = require("../steps/model");
//  Create Project 
async function createProject(reqObject, user) {
    try {
        if (!reqObject.reference || !reqObject.name /*|| !reqObject.startDate || !reqObject.endDate*/) {
            throw new Error(error_msg_1.MISSING);
        }
        // if (new Date(reqObject.startDate) > new Date(reqObject.endDate)) {
        //   throw new Error("Start date must less than end date.")
        // }
        let isEligible = await role_management_1.checkRoleScope(user.role, "manage-project");
        if (!isEligible) {
            throw new custom_error_1.APIError("Unauthorized Action.", 403);
        }
        // if (reqObject.name && (/[ ]{2,}/.test(reqObject.name) || !/[A-Za-z0-9  -]+$/.test(reqObject.name))) throw new Error("you have entered invalid name. please try again.")
        const createdProject = await project_model_1.project.create({
            createdBy: user._id,
            name: reqObject.name,
            startDate: reqObject.startDate,
            endDate: reqObject.endDate,
            reference: reqObject.reference,
            city: reqObject.cityname,
            summary: reqObject.description || "N/A",
            maturationStartDate: { date: reqObject.maturationStartDate, modifiedBy: user._id },
            maturationEndDate: { date: reqObject.maturationEndDate, modifiedBy: user._id },
            fundsReleased: [],
            fundsUtilised: [],
            funds: []
            // phases: reqObject.phases
        });
        module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.PROJECT_CREATED, projectId: createdProject.id, activityBy: user._id });
        return createdProject;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.createProject = createProject;
//  Edit city Code
async function editProject(id, reqObject, user) {
    try {
        if (!id || !user)
            throw new Error(error_msg_1.MISSING);
        let obj = {};
        let modifiedFields = [];
        let [preProjectRecord, isEligible] = await Promise.all([
            project_model_1.project.findById(id).exec(),
            role_management_1.checkRoleScope(user.role, "manage-project")
        ]);
        // let isEligible = await checkRoleScope(user.role, "manage-project");
        if (!isEligible)
            throw new custom_error_1.APIError("Unauthorized Action.", 403);
        if (reqObject.startDate || reqObject.endDate) {
            if (new Date(reqObject.startDate) > new Date(reqObject.endDate))
                throw new Error("Start date must less than end date.");
            obj.startDate = reqObject.startDate;
            obj.endDate = reqObject.endDate;
        }
        ;
        if (reqObject.reference) {
            if (preProjectRecord.name != reqObject.name)
                modifiedFields.push("Reference Id");
            obj.reference = reqObject.reference;
        }
        if (reqObject.name) {
            if (reqObject.name && (/[ ]{2,}/.test(reqObject.name) || !/[A-Za-z0-9  -]+$/.test(reqObject.name)))
                throw new Error("you have entered invalid name. please try again.");
            if (preProjectRecord.name != reqObject.name)
                modifiedFields.push("Name");
            obj.name = reqObject.name;
        }
        if (reqObject.cityname) {
            obj.city = reqObject.cityname;
        }
        if (reqObject.description) {
            obj.summary = reqObject.description;
        }
        if (reqObject.maturationStartDate) {
            obj.maturationStartDate = { date: reqObject.maturationStartDate, modifiedBy: user._id };
        }
        if (reqObject.phases) {
            obj.phases = reqObject.phases;
        }
        const updatedProject = await project_model_1.project.findByIdAndUpdate(id, { $set: obj }, { new: true }).exec();
        return updatedProject;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.editProject = editProject;
async function RemoveProjectMembers(projectId, userId, token) {
    try {
        let projectTasks = await memberExistInProjectTask(projectId, userId, token);
        if (projectTasks.success)
            return { success: false, tasks: projectTasks.tasks };
        const previousProjectData = await project_model_1.project.findById(projectId).exec();
        let members = previousProjectData.members.filter((id) => id != userId);
        const updatedProject = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { members } }, { new: true }).exec();
        return { success: true, project: updatedProject };
    }
    catch (err) {
        throw err;
    }
}
exports.RemoveProjectMembers = RemoveProjectMembers;
async function replaceProjectMember(projectId, objBody, token) {
    try {
        if (!objBody || !objBody.oldUser || !objBody.newUser || !projectId)
            throw new Error("Required mandatory fields.");
        const ProjectData = await project_model_1.project.findById(projectId).exec();
        // if (!ProjectData.members.includes(objBody.newUser)) throw new Error("member is not a project member.")
        let success = await replaceProjectTaskUser(projectId, objBody.oldUser, objBody.newUser, token);
        if (success && !success.success)
            throw new Error(success);
        let members = [...new Set((ProjectData.members.filter((id) => id != objBody.oldUser)).concat([objBody.newUser]))];
        const updatedProject = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { members } }, { new: true }).exec();
        return { message: "Replaced new user successfully." };
    }
    catch (err) {
        throw err;
    }
}
exports.replaceProjectMember = replaceProjectMember;
async function replaceProjectTaskUser(projectId, userId, replaceTo, userToken) {
    const options = {
        url: `${urls_1.TASKS_URL}/task/replace-user/?projectId=${projectId}`,
        body: { oldUser: userId, updatedUser: replaceTo },
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    return await role_management_1.httpRequest(options);
}
exports.replaceProjectTaskUser = replaceProjectTaskUser;
async function memberExistInProjectTask(projectId, userId, userToken) {
    const options = {
        url: `${urls_1.TASKS_URL}/task/memberExistInProjectTask`,
        body: { projectId, userId },
        headers: { 'Authorization': `Bearer ${userToken}` },
        method: 'POST',
        json: true
    };
    return await role_management_1.httpRequest(options);
}
exports.memberExistInProjectTask = memberExistInProjectTask;
async function manageProjectMembers(id, members, userId, userRole) {
    members = Array.from(new Set(members));
    const isEligible = await role_management_1.checkRoleScope(userRole, `project-add-core-team`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    const previousProjectData = await project_model_1.project.findById(id).exec();
    if (members.includes(userId) && !previousProjectData.members.includes(userId)) {
        throw new custom_error_1.APIError(`You are trying to add yourself as project member`);
    }
    const updatedProject = await project_model_1.project.findByIdAndUpdate(id, { $set: { members } }, { new: true }).exec();
    const removedUserIds = previousProjectData.members.filter((member) => !updatedProject.members.includes(member));
    const addedUserIds = updatedProject.members.filter((member) => !previousProjectData.members.includes(member));
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.PROJECT_MEMBERS_UPDATED, activityBy: userId, projectId: id, addedUserIds, removedUserIds });
    return updatedProject;
}
exports.manageProjectMembers = manageProjectMembers;
async function getProjectMembers(id, userId) {
    let userRoles = await module_1.userRoleAndScope(userId);
    let userRole = userRoles.data[0];
    const [viewMyAccess, viewAllAccess, manageAccess] = await Promise.all([
        role_management_1.checkRoleScope(userRole, "view-my-project"),
        role_management_1.checkRoleScope(userRole, "view-all-projects"),
        role_management_1.checkRoleScope(userRole, "manage-project")
    ]);
    if (!viewMyAccess && !viewAllAccess && !manageAccess) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { members } = await project_model_1.project.findById(id).exec();
    const [users, formattedRoleObjs] = await Promise.all([
        users_1.userFindMany('_id', members, { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, is_active: 1 }),
        module_1.role_list()
    ]);
    const usersRoles = await Promise.all(members.map((user) => module_1.userRoleAndScope(user)));
    return members.map((user, i) => (Object.assign({}, (users.find((_user) => _user._id == user)), { role: formatUserRole(usersRoles.find((role) => role.user == user).data[0], formattedRoleObjs.roles) })));
    // return users.map((user: any, i: number) => ({ ...user, role: formatUserRole((usersRoles.find((role: any) => role.user == user._id) as any).data[0], formattedRoleObjs.roles) }))
}
exports.getProjectMembers = getProjectMembers;
function formatUserRole(role, formattedRoleObjs) {
    // let userRole: any = formattedRoleObjs.find((roleObj: any) => roleObj.role === role);
    // return userRole ? userRole.roleName : role;
    return role ? role.map((userRole) => {
        let roleObj = formattedRoleObjs.find(({ role: rolecode }) => rolecode == userRole);
        return roleObj ? roleObj.roleName : userRole;
    }) : ["N/A"];
}
//  Get List of city Codes
async function projectList() {
    try {
        return await project_model_1.project.find({ is_active: true }).exec();
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.projectList = projectList;
//  edit status of city code
async function city_code_status(id, userObj) {
    try {
        if (!id)
            throw new Error(error_msg_1.MISSING);
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "manage-project");
        if (!isEligible)
            throw new custom_error_1.APIError("Unauthorized Action.", 403);
        let projectData = await project_model_1.project.findById(id).exec();
        if (!projectData) {
            throw new Error("project not there");
        }
        return await project_model_1.project.findByIdAndUpdate({ id }, { is_active: projectData.is_active ? false : true }, { new: true }).exec();
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.city_code_status = city_code_status;
//  add tag
async function add_tag(reqObject, userObj) {
    try {
        if (!reqObject.tag) {
            throw new Error(error_msg_1.MISSING);
        }
        // let isEligible = await checkRoleScope(userObj.role, "create-tag");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        let { firstName, lastName, middleName, countryCode, phone } = userObj;
        let fullName = (firstName ? firstName + " " : "") + (middleName ? middleName + " " : "") + (lastName ? lastName : "");
        // let userNotification = await userRolesNotification(userObj._id,"tagAdd");
        // if(userNotification.email){
        //   let templatInfo = await getTemplateBySubstitutions('tagAdd', { fullName, otp: authOtp.otp });
        //   nodemail({
        //     email: userObj.email,
        //     subject: templatInfo.subject,
        //     html: templatInfo.content
        //   })
        // }
        return await tag_model_1.tags.create({
            tag: reqObject.tag,
            description: reqObject.description || "N/A"
        });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.add_tag = add_tag;
//  edit tag
async function edit_tag(id, reqObject, userObj) {
    try {
        // let isEligible = await checkRoleScope(userObj.role, "edit-tag");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        let obj = {};
        if (reqObject.tag) {
            obj.tag = reqObject.tag;
        }
        if (reqObject.description) {
            obj.description = reqObject.description;
        }
        return await tag_model_1.tags.findByIdAndUpdate(id, obj, { new: true });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.edit_tag = edit_tag;
async function getTagByIds(ids) {
    return await tag_model_1.tags.find({ _id: { $in: ids } }).exec();
}
exports.getTagByIds = getTagByIds;
//  edit status of tag
async function tag_status(id, userObj) {
    try {
        // let isEligible = await checkRoleScope(userObj.role, "edit-tag");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        let city = await tag_model_1.tags.findById(id);
        if (!city) {
            throw new Error(error_msg_1.MISSING);
        }
        return await tag_model_1.tags.findByIdAndUpdate({ id }, { is_active: city.is_active == true ? false : true });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.tag_status = tag_status;
//  add theme
async function add_theme(reqObject) {
    try {
        if (!reqObject.theme) {
            throw new Error(error_msg_1.MISSING);
        }
        return await theme_model_1.themes.create({
            theme: reqObject.theme,
            description: reqObject.description || "N/A"
        });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.add_theme = add_theme;
//  edit theme
async function edit_theme(id, reqObject) {
    try {
        let obj = {};
        if (reqObject.theme) {
            obj.theme = reqObject.theme;
        }
        if (reqObject.description) {
            obj.description = reqObject.description;
        }
        return await theme_model_1.themes.findByIdAndUpdate(id, obj, { new: true });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.edit_theme = edit_theme;
//  get list of theme
async function theme_list() {
    try {
        return await theme_model_1.themes.find({ is_active: true });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.theme_list = theme_list;
//  edit status of theme
async function theme_status(id) {
    try {
        let city = await theme_model_1.themes.findById(id);
        if (!city) {
            throw new Error(error_msg_1.MISSING);
        }
        return await theme_model_1.themes.findByIdAndUpdate({ id }, { is_active: city.is_active == true ? false : true });
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.theme_status = theme_status;
//get projects list
async function getProjectsList(userId, userToken, userRole, currentPage, limit = 30) {
    try {
        let query = { members: { $in: [userId] } };
        // let userProjects: any = await userRoleAndScope(userId);
        // if (!userProjects) throw new Error("user have no projects");
        //const { docs: list, page, pages } = await ProjectSchema.paginate({ $or: [{ createdBy: userId }, { members: { $in: [userId] } }] })
        const [isEligible1, isEligible2] = await Promise.all([
            role_management_1.checkRoleScope(userRole, `view-all-projects`),
            role_management_1.checkRoleScope(userRole, `manage-project`),
        ]);
        if (isEligible1 || isEligible2) {
            query = {};
        }
        let { docs: list, page, pages } = await project_model_1.project.paginate(query, { page: Number(currentPage), limit: Number(limit), sort: { createdAt: -1 } });
        const projectIds = (list || []).map((_list) => _list.id);
        list = await Promise.all(list.map((proObj) => mapPhases(proObj)));
        return { docs: await mapProgressPercentageForProjects(projectIds, userToken, list), page, pages };
    }
    catch (error) {
        console.error(error);
        throw error;
    }
}
exports.getProjectsList = getProjectsList;
async function mapPhases(projectObj) {
    return Object.assign({}, projectObj.toJSON(), { phases: await listPhasesOfProject(projectObj._id) });
}
function getCurrentPhase(projectObj) {
    return (projectObj.phases && projectObj.phases.length ? projectObj.phases.find((phaseObj) => (new Date(phaseObj.startDate) <= new Date() && new Date(phaseObj.endDate) >= new Date())) : {});
}
async function mapProgressPercentageForProjects(projectIds, userToken, list) {
    const projectRelatedTasks = await role_management_1.httpRequest({
        url: `${urls_1.TASKS_URL}/task/getTasksByProjectIds`,
        body: { projectIds },
        json: true,
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` }
    });
    return (list || []).map((_list) => {
        const tasksForTheProject = projectRelatedTasks.filter((task) => task.projectId == _list.id && task.status != 8);
        return (Object.assign({}, _list, { progressPercentage: tasksForTheProject.length ? (tasksForTheProject.reduce((p, c) => p + (c.progressPercentage || 0), 0) / tasksForTheProject.length).toFixed(0) : 0, phase: getCurrentPhase(_list) || {} }));
    });
}
// get project details
async function getProjectDetail(projectId, userToken) {
    try {
        let projectDetail = await project_model_1.project.findById(projectId).populate({ path: 'phases' }).exec();
        return (await mapProgressPercentageForProjects([projectId], userToken, [projectDetail.toJSON()]))[0];
    }
    catch (error) {
        console.error(error);
        throw error;
    }
    ;
}
exports.getProjectDetail = getProjectDetail;
;
async function createTask(payload, projectId, userToken, userObj) {
    let isEligible = await role_management_1.checkRoleScope(userObj.role, "project-create-task");
    if (!isEligible)
        throw new custom_error_1.APIError("Unauthorized Action.", 403);
    const taskPayload = await formatTaskPayload(payload, projectId);
    // if (!payload.isCompliance && (payload.assignee == userObj._id)) {
    //   throw new APIError(TASK_ERROR.CREATOR_CANT_BE_ASSIGNEE)
    // }
    if (payload.isCompliance && (!payload.approvers || !payload.approvers.length)) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.APPROVERS_REQUIRED);
    }
    const options = {
        url: `${urls_1.TASKS_URL}/task/create`,
        body: Object.assign({}, taskPayload),
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    const createdTask = await role_management_1.httpRequest(options);
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.CREATE_TASK_FROM_PROJECT, taskId: createdTask._id, projectId, activityBy: userObj._id });
    return createdTask;
}
exports.createTask = createTask;
async function formatTaskPayload(payload, projectId) {
    return Object.assign({}, payload, { projectId });
    const projectInfo = await project_model_1.project.findById(projectId).exec();
    const memberRoles = await Promise.all(projectInfo.members.map((member) => module_1.userRoleAndScope(member)));
    let approvers = [];
    let endorsers = [];
    let viewers = [];
    let supporters = [];
    let assignee;
    if (payload.assignee && !mongoose_1.Types.ObjectId.isValid(payload.assignee)) {
        const filteredAssignees = memberRoles.filter((role) => (role.data[0] == payload.assignee));
        if (filteredAssignees.length > 1) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.MORE_THAN_ONE_RESULT_FOUND);
        }
        else {
            assignee = filteredAssignees[0];
        }
    }
    else {
        assignee = payload.assignee;
    }
    approvers = memberRoles.filter((role) => (payload.approvers || []).includes(role.data[0]));
    endorsers = memberRoles.filter((role) => (payload.endorsers || []).includes(role.data[0]));
    viewers = memberRoles.filter((role) => (payload.viewers || []).includes(role.data[0]));
    supporters = memberRoles.filter((role) => (payload.supporters || []).includes(role.data[0]));
    return Object.assign({}, payload, { assignee, approvers, endorsers, viewers, supporters });
}
async function getProjectTasks(projectId, userToken) {
    const options = {
        url: `${urls_1.TASKS_URL}/task/getTasksByProject`,
        body: { projectId },
        headers: { 'Authorization': `Bearer ${userToken}` },
        method: 'POST',
        json: true
    };
    return await role_management_1.httpRequest(options);
}
exports.getProjectTasks = getProjectTasks;
async function editTask(projectId, taskId, userObj, userToken, payload) {
    let isEligible = await role_management_1.checkRoleScope(userObj.role, "edit-task-progress-dates");
    if (!isEligible)
        throw new custom_error_1.APIError("Unauthorized Action.", 403);
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    if (!projectDetail) {
        throw new Error(error_msg_1.PROJECT_ROUTER.PROJECT_NOT_EXISTS);
    }
    if (!(projectDetail.members || []).includes(userObj._id)) {
        throw new Error(error_msg_1.PROJECT_ROUTER.NOT_MEMBER_OF_PROJECT);
    }
    const options = {
        url: `${urls_1.TASKS_URL}/task/${taskId}/soft-edit`,
        body: payload,
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    const updatedTask = await role_management_1.httpRequest(options);
    module_3.create({ activityBy: userObj._id, activityType: error_msg_1.ACTIVITY_LOG.TASK_DATES_UPDATED, taskId, projectId });
    return updatedTask;
}
exports.editTask = editTask;
async function taskProjectDetails(projectId) {
    return project_model_1.project.findById(projectId).exec();
}
exports.taskProjectDetails = taskProjectDetails;
;
async function linkTask(projectId, taskId, userToken, userId) {
    if (!taskId) {
        throw new Error(error_msg_1.PROJECT_ROUTER.TASK_REQUIRED_FOR_LINKING);
    }
    const options = {
        url: `${urls_1.TASKS_URL}/task/${taskId}/soft-edit`,
        body: { projectId },
        method: 'POST',
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    const updatedTask = await role_management_1.httpRequest(options);
    module_3.create({ activityBy: userId, activityType: error_msg_1.ACTIVITY_LOG.TASK_LINKED_TO_PROJECT, taskId, projectId });
    return updatedTask;
}
exports.linkTask = linkTask;
async function addReleasedInstallment(projectId, payload, user) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    // if(!payload.installment){
    //   throw new APIError('Installment is required') 
    // }
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const finalPayload = payload.fundsReleased.map((fund, index) => {
        if (!fund.phase) {
            throw new custom_error_1.APIError(`Phase is required`);
        }
        if (!fund.percentage) {
            throw new custom_error_1.APIError(`Percentage is required`);
        }
        return Object.assign({}, fund, { installment: index + 1 });
        return {
            installment: index + 1,
            phase: fund.phase,
            percentage: fund.percentage
        };
    });
    const overAllPercentage = finalPayload.reduce((p, fund) => p + Number(fund.percentage), 0);
    // if(projectDetail.fundsReleased.some((fund: any) => fund.installment == payload.installment)){
    //   throw new APIError(`Installment already exists`)
    // }
    if (overAllPercentage > 100) {
        throw new custom_error_1.APIError(`Percentage should not exceed 100`);
    }
    const updated = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { fundsReleased: finalPayload } }, { new: true }).exec();
    return updated;
}
exports.addReleasedInstallment = addReleasedInstallment;
async function addUtilizedInstallment(projectId, payload, user) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const finalPayload = payload.fundsUtilised.map((fund, index) => {
        if (!fund.phase) {
            throw new custom_error_1.APIError(`Phase is required`);
        }
        if (!fund.percentage) {
            throw new custom_error_1.APIError(`Percentage is required`);
        }
        return Object.assign({}, fund, { installment: index + 1 });
        // return {
        //   installment: index + 1,
        //   phase: fund.phase,
        //   percentage: fund.percentage
        // }
    });
    const overAllPercentage = finalPayload.reduce((p, fund) => p + Number(fund.percentage), 0);
    if (overAllPercentage > 100) {
        throw new custom_error_1.APIError(`Percentage should not exceed 100`);
    }
    // if(projectDetail.fundsUtilised.some((fund: any) => fund.installment == payload.installment)){
    //   throw new APIError(`Installment already exists`)
    // }
    const updated = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { fundsUtilised: finalPayload } }, { new: true }).exec();
    return updated;
}
exports.addUtilizedInstallment = addUtilizedInstallment;
async function getInstallments(projectId) {
    const [projectDetail, phases] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        model_1.phaseSchema.find({}).exec()
    ]);
    let s1 = [];
    let m = (projectDetail['funds'] || []).map((s) => {
        if (!s1.includes(s.installment)) {
            s1.push(s.installment);
            return {
                deletedReleased: s.deletedReleased,
                deletedUtilised: s.deletedUtilised,
                subInstallment: s.subInstallment,
                releasedCost: !(s.deletedReleased) ? s.releasedCost : null,
                utilisedCost: !(s.deletedUtilised) ? s.utilisedCost : null,
                releasedDocuments: !(s.deletedReleased) ? s.releasedDocuments : null,
                utilisedDocuments: !(s.deletedUtilised) ? s.utilisedDocuments : null,
                phase: phases.find((phase) => phase._id == s.phase),
                percentage: s.percentage
            };
        }
    });
    return m.filter((v) => !!v);
}
exports.getInstallments = getInstallments;
async function ganttChart(projectId, userToken) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const options = {
        url: `${urls_1.TASKS_URL}/task/getTasksWithSubTasks`,
        method: 'POST',
        body: { projectIds: [projectId] },
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    const tasks = await role_management_1.httpRequest(options);
    return Object.assign({}, projectDetail.toJSON(), { tasks });
}
exports.ganttChart = ganttChart;
async function projectMembers(id, currntUser) {
    let [project, formattedRoleObjs] = await Promise.all([
        project_model_1.project.findById(id).exec(),
        module_1.role_list()
    ]);
    if (!project)
        throw new Error("Project Not Found.");
    const userIds = Array.from(new Set([...project.members, currntUser ? currntUser._id : ''].filter(v => v)));
    let userObjs = (await users_1.userFindMany("_id", userIds)).map((user) => { return Object.assign({}, user, { fullName: (user.firstName ? user.firstName + " " : "") + (user.middleName ? user.middleName + " " : "") + (user.lastName ? user.lastName : "") }); });
    // const userIds = project.members
    const usersRoles = await Promise.all(userIds.map((userId) => module_1.userRoleAndScope(userId)));
    return userIds.map((user, i) => ({
        isMember: project.members.includes(user),
        value: user,
        fullName: (userObjs.find(({ _id }) => _id == user)).fullName,
        key: formatUserRole(usersRoles.find((role) => role.user == user).data[0], formattedRoleObjs.roles)
    }));
}
exports.projectMembers = projectMembers;
async function getTaskDetail(projectId, id, userId, userToken) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    // if (!projectDetail.members.includes(userId) && projectDetail.createdBy != userId) {
    //   throw new APIError(`You dont have access to this project`)
    // }
    const options = {
        url: `${urls_1.TASKS_URL}/task/${id}/detail?isFromProject=${true}`,
        method: 'GET',
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    };
    return await role_management_1.httpRequest(options);
}
exports.getTaskDetail = getTaskDetail;
function getPercentageByInstallment(installment) {
    let percentage = 10, installmentType, phase;
    switch (installment) {
        case 1:
            percentage = 10;
            installmentType = `1st Installment`;
            phase = `Maturation`;
            break;
        case 2:
            phase = `Implementation`;
            percentage = 40;
            installmentType = `2nd Installment`;
            break;
        case 3:
            phase = `Implementation`;
            percentage = 40;
            installmentType = `3rd Installment`;
            break;
        case 4:
            percentage = 10;
            phase = `Implementation`;
            installmentType = `4th Installment`;
            break;
        default:
            installmentType = `${installment}th Installment`;
            break;
    }
    return { percentage, installmentType, phase };
}
async function getFinancialInfo(projectId, userId, userRole) {
    const [isEligible1, isEligible2, canSeeMyProject, canSeeAllProjects, canManageProject] = await Promise.all([
        role_management_1.checkRoleScope(userRole, `manage-project-released-fund`),
        role_management_1.checkRoleScope(userRole, `manage-project-utilized-fund`),
        role_management_1.checkRoleScope(userRole, `view-my-project`),
        role_management_1.checkRoleScope(userRole, `view-all-projects`),
        role_management_1.checkRoleScope(userRole, `manage-project`)
    ]);
    if (!isEligible1 && !isEligible2 && !canSeeMyProject && !canSeeAllProjects && !canManageProject) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.FINANCIAL_INFO_NO_ACCESS);
    }
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const { fundsReleased, fundsUtilised, projectCost, citiisGrants } = projectDetail;
    const documentIds = fundsReleased.map((fund) => (fund.documents || [])).concat(fundsUtilised.map((fund) => (fund.documents || []))).reduce((p, c) => [...p, ...c], []).filter((v) => (!!v && mongoose_1.Types.ObjectId.isValid(v)));
    const documents = await module_4.documentsList(documentIds);
    let phases = await model_1.phaseSchema.find({}).exec();
    let fundsReleasedData = fundsReleased.reduce((p, fund) => {
        const { installmentType } = getPercentageByInstallment(fund.installment);
        const items = fundsReleased.filter((_fund) => (!_fund.deleted && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { documents: documents.filter((d) => (item.documents || []).includes(d.id)) })));
        p.push({
            fundsPlanned: Math.round(citiisGrants * (fund.percentage / 100)),
            phase: phases.find(phase => phase.id == fund.phase),
            installment: installmentType,
            percentage: fund.percentage,
            // Filter empty data
            items,
            installmentLevelTotal: items.reduce((p, item) => p + (item.cost || 0), 0)
        });
        return p;
    }, []);
    let ins = [];
    fundsReleasedData = fundsReleasedData.filter((f) => {
        if (!ins.includes(f.installment)) {
            ins.push(f.installment);
            return f;
        }
    });
    let fundsUtilisedData = fundsUtilised.reduce((p, fund) => {
        const { installmentType } = getPercentageByInstallment(fund.installment);
        const items = fundsUtilised.filter((_fund) => (!_fund.deleted && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { documents: documents.filter((d) => (item.documents || []).includes(d.id)) })));
        p.push({
            fundsPlanned: Math.round(citiisGrants * (fund.percentage / 100)),
            phase: phases.find(phase => phase.id == fund.phase),
            installment: installmentType,
            percentage: fund.percentage,
            // Filter empty data
            items,
            installmentLevelTotal: items.reduce((p, item) => p + (item.cost || 0), 0)
        });
        return p;
    }, []);
    let _ins = [];
    fundsUtilisedData = fundsUtilisedData.filter((f) => {
        if (!_ins.includes(f.installment)) {
            _ins.push(f.installment);
            return f;
        }
    });
    return {
        isMember: projectDetail.members.includes(userId) || (projectDetail.createdBy == userId),
        projectCost: projectCost,
        citiisGrants: citiisGrants,
        fundsReleased: {
            info: fundsReleasedData,
            total: fundsReleasedData.reduce((p, c) => p + c.installmentLevelTotal, 0)
        },
        fundsUtilised: {
            info: fundsUtilisedData,
            total: fundsUtilisedData.reduce((p, c) => p + c.installmentLevelTotal, 0)
        }
    };
}
exports.getFinancialInfo = getFinancialInfo;
async function addFundReleased(projectId, payload, user) {
    if (!payload.installment) {
        throw new custom_error_1.APIError(`Installment is required`);
    }
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const fund = await project_model_1.project.findById(projectId).exec();
    const { fundsReleased } = fund;
    const otherFunds = fundsReleased.filter((fund) => fund.installment != payload.installment);
    const matchedFunds = fundsReleased.filter((fund) => fund.installment == payload.installment);
    let matchedFundsWithData = matchedFunds.length == 1 && !matchedFunds[0].cost ? [] : matchedFunds;
    const updates = {
        fundsReleased: otherFunds.concat(matchedFundsWithData).concat([
            {
                phase: matchedFunds[0].phase,
                percentage: matchedFunds[0].percentage,
                subInstallment: matchedFundsWithData.length + 1,
                installment: payload.installment, documents: payload.documents, cost: payload.cost,
                createdAt: new Date(), modifiedAt: new Date(), modifiedBy: user._id
            }
        ]).sort((a, b) => a.installment - b.installment)
    };
    const updatedFund = await project_model_1.project.findByIdAndUpdate(projectId, { $set: updates }, { new: true }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.ADDED_FUND_RELEASE, projectId, updatedCost: payload.cost, activityBy: user._id });
    return updatedFund;
}
exports.addFundReleased = addFundReleased;
async function addFundsUtilized(projectId, payload, user) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`)
    ]);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    if (!payload.installment) {
        throw new Error(`Installment is required`);
    }
    const { fundsUtilised } = projectDetail;
    const otherFunds = fundsUtilised.filter((fund) => fund.installment != payload.installment);
    const matchedFunds = fundsUtilised.filter((fund) => fund.installment == payload.installment);
    let matchedFundsWithData = matchedFunds.length == 1 && !matchedFunds[0].cost ? [] : matchedFunds;
    const updates = {
        fundsUtilised: otherFunds.concat(matchedFundsWithData).concat([
            {
                phase: matchedFunds[0].phase,
                percentage: matchedFunds[0].percentage,
                subInstallment: matchedFundsWithData.length + 1,
                installment: payload.installment, documents: payload.documents, cost: payload.cost,
                createdAt: new Date(), modifiedAt: new Date(), modifiedBy: user._id
            }
        ]).sort((a, b) => a.installment - b.installment)
    };
    const updatedProject = await project_model_1.project.findByIdAndUpdate(projectId, { $set: updates }, { new: true }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.ADDED_FUND_UTILIZATION, projectId, updatedCost: payload.cost, activityBy: user._id });
    return updatedProject;
}
exports.addFundsUtilized = addFundsUtilized;
async function updateReleasedFund(projectId, payload, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { documents, cost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), modifiedBy: user._id });
    updates['fundsReleased.$.documents'] = documents;
    updates['fundsReleased.$.cost'] = cost;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'fundsReleased._id': _id }, { $set: updates }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.UPDATED_FUND_RELEASE, oldCost: updatedProject.cost, updatedCost: payload.cost, projectId, activityBy: user._id });
    return updatedProject;
    // if(!payload.installment || !payload.subInstallment){
    //   throw new APIError(`Installment is required`)
    // }
    // const project: any = await ProjectSchema.findById(projectId).exec()
    // const { fundsReleased } = project.toJSON()
    // const otherFunds = fundsReleased.filter((fund: any) => fund.installment != payload.installment)
    // const matchedFunds = fundsReleased.filter((fund: any) => fund.installment == payload.installment)
    // const matchedSubFund = matchedFunds.find((fund: any) => fund.subInstallment == payload.installment)
    // const updates = {fundsReleased: otherFunds.concat(matchedFunds.filter((fund: any) => fund.subInstallment != payload.installment)).concat([
    //   {
    //     ...matchedSubFund, document: payload.document, cost: payload.cost, modifiedAt: new Date(), modifiedBy: userId
    //   }
    // ]).sort((a: any, b: any) => a.installment - b.installment)}
    // return await ProjectSchema.findByIdAndUpdate(projectId, { $set: updates }, {new: true}).exec()
}
exports.updateReleasedFund = updateReleasedFund;
async function updateUtilizedFund(projectId, payload, user) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`)
    ]);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    // if(!payload.installment || !payload.subInstallment){
    //   throw new Error(`Installment is required`)
    // }
    // const project: any = await ProjectSchema.findById(projectId).exec()
    // const { fundsUtilised } = project.toJSON()
    // const otherFunds = fundsUtilised.filter((fund: any) => fund.installment != payload.installment)
    // const matchedFunds = fundsUtilised.filter((fund: any) => fund.installment == payload.installment)
    // const matchedSubFund = matchedFunds.find((fund: any) => fund.subInstallment == payload.installment)
    // const updates = {fundsUtilised: otherFunds.concat(matchedFunds.filter((fund: any) => fund.subInstallment != payload.installment)).concat([
    //   {
    //     ...matchedSubFund, document: payload.document, cost: payload.cost, modifiedAt: new Date(), modifiedBy: userId
    //   }
    // ]).sort((a: any, b: any) => a.installment - b.installment)}
    // return await ProjectSchema.findByIdAndUpdate(projectId, { $set: updates }, {new: true}).exec()
    const { documents, cost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), modifiedBy: user._id });
    updates['fundsUtilised.$.documents'] = documents;
    updates['fundsUtilised.$.cost'] = cost;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'fundsUtilised._id': _id }, { $set: updates }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.UPDATED_FUND_UTILIZATION, projectId, oldCost: updatedProject.cost, updatedCost: payload.cost, activityBy: user._id });
    return updatedProject;
}
exports.updateUtilizedFund = updateUtilizedFund;
async function deleteReleasedFund(projectId, payload, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { document, cost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), modifiedBy: user._id });
    updates['fundsReleased.$.deleted'] = true;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'fundsReleased._id': _id }, { $set: updates }).exec();
    // createLog({activityType: ACTIVITY_LOG.UPDATED_FUND_RELEASE, oldCost: updatedProject.cost, updatedCost: payload.cost, projectId, activityBy: userId})
    return updatedProject;
}
exports.deleteReleasedFund = deleteReleasedFund;
async function deleteUtilizedFund(projectId, payload, user) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`)
    ]);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { document, cost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), modifiedBy: user._id });
    updates['fundsUtilised.$.deleted'] = true;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'fundsUtilised._id': _id }, { $set: updates }).exec();
    // createLog({activityType: ACTIVITY_LOG.UPDATED_FUND_UTILIZATION, projectId, oldCost: updatedProject.cost, updatedCost: payload.cost, activityBy: userId})
    return updatedProject;
}
exports.deleteUtilizedFund = deleteUtilizedFund;
function importExcelAndFormatData(filePath) {
    if (!['.xlsx', ".csv"].includes(path_1.extname(filePath))) {
        fs_1.unlinkSync(filePath);
        throw new custom_error_1.APIError(`please upload valid xlsx/csv file`);
    }
    let workBook = xlsx.readFile(filePath, {
        type: 'binary',
        cellDates: true,
        cellNF: false,
        cellText: false
    });
    xlsx.writeFile(workBook, filePath);
    fs_1.unlinkSync(filePath);
    if (!workBook.SheetNames) {
        throw new custom_error_1.APIError("not a valid sheet");
    }
    var excelFormattedData = xlsx.utils.sheet_to_json(workBook.Sheets[workBook.SheetNames[0]]);
    return excelFormattedData;
}
exports.importExcelAndFormatData = importExcelAndFormatData;
async function uploadTasksExcel(filePath, projectId, userToken, userObj) {
    const roleData = await module_1.role_list();
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `upload-task-excel`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    const roleNames = roleData.roles.map((role) => role.roleName);
    const excelFormattedData = importExcelAndFormatData(filePath);
    if (!excelFormattedData.length) {
        throw new custom_error_1.APIError(`Uploaded empty document`);
    }
    const validatedTaskData = excelFormattedData.map(data => validateObject(data, roleNames));
    const tasksDataWithIds = await Promise.all(validatedTaskData.map(taskData => formatTasksWithIds(taskData, projectId, userObj)));
    for (let taskData of tasksDataWithIds) {
        await createTask(taskData, projectId, userToken, userObj);
    }
    // await Promise.all(tasksDataWithIds.map(taskData => createTask(taskData, projectId, userToken, userObj)))
    return { message: 'success' };
}
exports.uploadTasksExcel = uploadTasksExcel;
async function formatTasksWithIds(taskObj, projectId, userObj) {
    const [projectData, memberRoles] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        projectMembers(projectId, userObj)
    ]);
    // if ((tags && !Array.isArray(tags)) || (taskObj.approvers && !Array.isArray(taskObj.approvers)) || (taskObj.viewers && !Array.isArray(taskObj.viewers)) || (taskObj.supporters && !Array.isArray(taskObj.supporters))) {
    //   throw new APIError(TASK_ERROR.INVALID_ARRAY);
    // }
    // taskObj.approvers = Object.keys(taskObj).filter(key => key == `approvers`).map
    const approverIds = memberRoles.filter((memberRole) => memberRole.key.some((role) => taskObj.approvers.includes(role))).map((val) => val.value);
    const endorserIds = memberRoles.filter((memberRole) => memberRole.key.some((role) => taskObj.endorsers.includes(role))).map((val) => val.value);
    const viewerIds = memberRoles.filter((memberRole) => memberRole.key.some((role) => taskObj.viewers.includes(role))).map((val) => val.value);
    const assigneeId = memberRoles.filter((memberRole) => memberRole.key.some((role) => [taskObj.assignee].includes(role))).map((val) => val.value).pop();
    if (approverIds.length != taskObj.approvers.length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.USER_NOT_PART_OF_PROJECT);
    }
    if (endorserIds.length != taskObj.endorsers.length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.USER_NOT_PART_OF_PROJECT);
    }
    if (viewerIds.length != taskObj.viewers.length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.USER_NOT_PART_OF_PROJECT);
    }
    if (!assigneeId) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.ASSIGNEE_REQUIRED);
    }
    if (taskObj.pillarId)
        taskObj.pillarId = (await model_2.PillarSchema.findOne({ name: new RegExp(taskObj.pillarId) }).exec() || { _id: undefined })._id || undefined;
    if (taskObj.stepId)
        taskObj.stepId = (await model_3.StepsSchema.findOne({ name: new RegExp(taskObj.stepId) }).exec() || { _id: undefined })._id || undefined;
    taskObj = Object.assign({}, taskObj, { projectId, assignee: assigneeId, approvers: approverIds, endorsers: endorserIds, viewers: viewerIds, pillarId: taskObj.pillarId, stepId: taskObj.stepId, startDate: new Date(taskObj.initialStartDate || taskObj.startDate), dueDate: new Date(taskObj.initialDueDate || taskObj.dueDate) });
    const { assignee, approvers, endorsers } = taskObj;
    if (Array.from(new Set(taskObj.approvers || [])).length != (taskObj.approvers || []).length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.DUPLICATE_APPROVERS_FOUND);
    }
    if (Array.from(new Set(taskObj.endorsers || [])).length != (taskObj.endorsers || []).length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.DUPLICATE_ENDORSERS_FOUND);
    }
    if (assignee && ((taskObj.approvers || []).concat(taskObj.endorsers || [])).includes(assignee)) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.ASSIGNEE_ERROR);
    }
    if ((taskObj.approvers || []).some((approver) => (taskObj.endorsers || []).includes(approver))) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.APPROVERS_EXISTS);
    }
    return taskObj;
}
function validateObject(data, roleNames, projectMembersData) {
    let errorRole;
    if (!data.name || !data.name.trim().length) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.TASK_NAME_REQUIRED);
    }
    const approvers = Object.keys(data).filter(key => ['approver1', `approver2`, `approver3`].includes(key)).reduce((p, c) => p.concat([data[c].trim()]), []);
    const endorsers = Object.keys(data).filter(key => ['endorser1', `endorser2`, `endorser3`].includes(key)).reduce((p, c) => p.concat([data[c].trim()]), []);
    const viewers = Object.keys(data).filter(key => ['viewer1', `viewer2`, `viewer3`].includes(key)).reduce((p, c) => p.concat([data[c].trim()]), []);
    if (!data.assignee || !data.assignee.trim().length) {
        throw new custom_error_1.APIError(`Assignee is required for task ${data.name}`);
    }
    // const approvers = data.approvers.split(',').map((value: string) => value.trim()).filter((v: string) => !!v)
    // const endorsers = data.endorsers.split(',').map((value: string) => value.trim()).filter((v: string) => !!v)
    // const viewers = data.endorsers.split(',').map((value: string) => value.trim()).filter((v: string) => !!v)
    if (!roleNames.includes(data.assignee.trim())) {
        throw new custom_error_1.APIError(`Assignee not exists for task ${data.name}`);
    }
    // Validate Approvers
    if (approvers.some((approver) => {
        errorRole = approver;
        return !roleNames.includes(approver);
    })) {
        throw new custom_error_1.APIError(`Approver ${errorRole} not exists in the system at task ${data.name}`);
    }
    // Validate Endorsers  
    if (endorsers.some((endorser) => {
        errorRole = endorser;
        return !roleNames.includes(endorser);
    })) {
        throw new custom_error_1.APIError(`Endorser ${errorRole} not exists in the system at task ${data.name}`);
    }
    // Validate Viewers
    if (viewers.some((viewer) => {
        errorRole = viewer;
        return !roleNames.includes(viewer);
    })) {
        throw new custom_error_1.APIError(`Viewer ${errorRole} not exists in the system at task ${data.name}`);
    }
    if (data.initialStartDate && new Date().getTime() > new Date(data.initialStartDate).setHours(23, 59, 59, 0))
        throw new Error("Start date must Not be in the past.");
    if (data.initialDueDate && new Date(data.initialStartDate).setHours(0, 0, 0, 0) > new Date(data.initialDueDate).setHours(23, 59, 59, 0))
        throw new Error("Start date must be lessthan due date.");
    return {
        name: data.name,
        description: data.description,
        initialStartDate: data.initialStartDate,
        initialDueDate: data.initialDueDate,
        // Validate ids
        // tags: data.tags,
        assignee: data.assignee,
        viewers: viewers || data.viewers,
        approvers: approvers || data.approvers,
        endorsers: endorsers || data.endorsers,
        stepId: data.stepId || data.step,
        pillarId: data.pillarId || data.pillar,
        isFromExcel: true,
        documents: data.documents
    };
}
async function projectCostInfo(projectId, projectCost, userRole, userId) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userRole, 'edit-project-cost');
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
        }
        const updatedProject = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { projectCost } }).exec();
        module_3.create({ activityBy: userId, activityType: error_msg_1.ACTIVITY_LOG.UPDATED_CITIIS_GRANTS, oldCost: updatedProject.projectCost, updatedCost: projectCost, projectId });
        let userDetails = await users_1.userFindOne("id", userId);
        let { fullName, mobileNo } = module_2.getFullNameAndMobile(userDetails);
        module_2.sendNotification({
            id: userId, fullName, email: userDetails.email, mobileNo,
            oldCost: updatedProject.projectCost, updatedCost: projectCost,
            templateName: "updateFinancial", mobileTemplateName: "updateFinancial"
        });
        return updatedProject;
    }
    catch (err) {
        throw err;
    }
}
exports.projectCostInfo = projectCostInfo;
async function citiisGrantsInfo(projectId, citiisGrants, userRole, userId) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userRole, 'edit-citiis-grants');
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
        }
        const projectInfo = await project_model_1.project.findById(projectId).exec();
        if (projectInfo.projectCost < citiisGrants) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.CITIIS_GRANTS_VALIDATION);
        }
        let totalFundData = await getTotalReleasedFunds(projectId);
        if (totalFundData.funds.totalReleased > citiisGrants) {
            throw new Error("CitiiesGrant must not be less then Released Funds");
        }
        const updatedProject = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { citiisGrants } }, { new: true }).exec();
        module_3.create({ activityBy: userId, activityType: error_msg_1.ACTIVITY_LOG.UPDATED_CITIIS_GRANTS, oldCost: projectInfo.citiisGrants, updatedCost: citiisGrants, projectId });
        // let userDetails = await userFindOne("id", userId);
        // let { fullName, mobileNo } = getFullNameAndMobile(userDetails);
        // sendNotification({
        //   id: userId, fullName, email: userDetails.email, mobileNo,
        //   oldCost: projectInfo.citiisGrants, updatedCost: citiisGrants,
        //   templateName: "updateFinancial", mobileTemplateName: "updateFinancial"
        // })
        return updatedProject;
    }
    catch (err) {
        throw err;
    }
}
exports.citiisGrantsInfo = citiisGrantsInfo;
async function addOpenComment(projectId, user, payload) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, 'add-open-comments')
    ]);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    if (!projectDetail.members.includes(user._id) && (projectDetail.createdBy != user._id)) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    if (!await open_comments_model_1.OpenCommentsModel.findOne({ projectId, userId: user._id }).exec()) {
        await open_comments_model_1.OpenCommentsModel.create(Object.assign({}, payload, { projectId, userId: user._id, isParent: true }));
    }
    await open_comments_model_1.OpenCommentsModel.findOneAndUpdate({ projectId, userId: user._id, isParent: true }, { $set: payload }).exec();
    // Creating copy
    await open_comments_model_1.OpenCommentsModel.create(Object.assign({}, payload, { projectId, userId: user._id, isParent: false }));
    return { message: 'Comment added successfully' };
}
exports.addOpenComment = addOpenComment;
async function myCommentDetail(projectId, userId) {
    const detail = await open_comments_model_1.OpenCommentsModel.findOne({ projectId, userId, isParent: true }).exec();
    return (detail || {});
}
exports.myCommentDetail = myCommentDetail;
async function getMyOpenCommentsHistory(projectId, userId) {
    return await open_comments_model_1.OpenCommentsModel.find({ projectId, userId, isParent: false }).sort({ createdAt: 1 }).exec();
}
exports.getMyOpenCommentsHistory = getMyOpenCommentsHistory;
async function getAllOpenCOmments(user, projectId, userId) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `view-open-comments`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    if (!userId) {
        throw new custom_error_1.APIError(`User id is required`);
    }
    return await open_comments_model_1.OpenCommentsModel.findOne({ projectId, isParent: true, userId }).exec();
    // const userIds = comments.map((comment: any) => comment.userId)
    // const usersInfo = await userFindMany('_id', userIds, { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 })
    // return comments.map(comment => ({...comment.toJSON(), userId: usersInfo.find((userInfo: any) => userInfo._id == (comment as any).userId)}))
}
exports.getAllOpenCOmments = getAllOpenCOmments;
async function getCommentedUsers(projectId, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `view-open-comments`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const comments = await open_comments_model_1.OpenCommentsModel.find({ projectId, isParent: true }).sort({ createdAt: 1 }).exec();
    const userIds = comments.map((comment) => comment.userId).filter(u => u != user._id);
    return await users_1.userFindMany('_id', userIds, { firstName: 1, lastName: 1, middleName: 1, email: 1, phone: 1, countryCode: 1, is_active: 1 });
}
exports.getCommentedUsers = getCommentedUsers;
async function editProjectMiscompliance(projectId, payload, userObj) {
    try {
        if (!mongoose_1.Types.ObjectId.isValid(projectId))
            throw new Error("Invalid Project Id.");
        const isEligible = await role_management_1.checkRoleScope(userObj.role, 'manage-compliance');
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.COMPLIANCES.MISCOMPLIANCE_ERROR);
        }
        let obj = {};
        if ("miscomplianceSpv" in payload)
            obj.miscomplianceSpv = payload.miscomplianceSpv;
        if ("miscomplianceProject" in payload)
            obj.miscomplianceProject = payload.miscomplianceProject;
        await project_model_1.project.findByIdAndUpdate(projectId, obj);
        return { message: `successfully ${"miscomplianceProject" in payload ? "miscomplianceProject" : "miscomplianceSpv"} updated.` };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.editProjectMiscompliance = editProjectMiscompliance;
;
async function editTriPartiteDate(id, payload, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `edit-tri-partite-aggrement-date`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN);
    }
    return await project_model_1.project.findByIdAndUpdate(id, { $set: { tripartiteAggrementDate: { modifiedBy: user._id, date: payload.tripartiteAggrementDate } } }, { new: true }).exec();
}
exports.editTriPartiteDate = editTriPartiteDate;
async function addPhaseToProject(projectId, payload) {
    return await project_model_1.project.findByIdAndUpdate(projectId, { $set: { phases: formatAndValidatePhasePayload(payload) } }, { new: true }).exec();
}
exports.addPhaseToProject = addPhaseToProject;
async function listPhasesOfProject(projectId) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const phaseIds = projectDetail.phases.map((phase) => phase.phase.toString());
    const phases = await model_1.phaseSchema.find({ _id: { $in: phaseIds } }).exec();
    return projectDetail.toJSON().phases.map((phase) => (Object.assign({}, phase, { phase: phases.find(_phase => _phase._id.toString() == phase.phase.toString()) })));
}
exports.listPhasesOfProject = listPhasesOfProject;
function formatAndValidatePhasePayload(payload) {
    return payload.map((_data, index) => {
        if (payload[index + 1]) {
            if (!_data.phase || !_data.startDate || !_data.endDate) {
                throw new custom_error_1.APIError(error_msg_1.DOCUMENT_ROUTER.MANDATORY);
            }
            if (_data.startDate > _data.endDate) {
                throw new custom_error_1.APIError(`Phase start date should be before end date`);
            }
            if (payload[index + 1] && (!payload[index + 1].startDate || (new Date(payload[index + 1].startDate).setHours(0, 0, 0, 0) <= new Date(_data.endDate).setHours(23, 59, 59, 0)))) {
                throw new custom_error_1.APIError(`There shouldn't be any gap/overlap between phases`);
            }
        }
        return {
            phase: _data.phase,
            startDate: new Date(new Date(_data.startDate).setHours(0, 0, 0, 0)),
            endDate: new Date(new Date(_data.endDate).setHours(23, 59, 59, 0)),
        };
    });
}
async function addInstallments(projectId, payload, user) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const finalPayload = payload.fundsReleased.map((fund, index) => {
        if (!fund.phase) {
            throw new custom_error_1.APIError(`Phase is required`);
        }
        if (!fund.percentage) {
            throw new custom_error_1.APIError(`Percentage is required`);
        }
        return Object.assign({}, fund, { installment: index + 1 });
    });
    const overAllPercentage = finalPayload.reduce((p, fund) => p + Number(fund.percentage), 0);
    if (overAllPercentage > 100) {
        throw new custom_error_1.APIError(`Percentage should not exceed 100`);
    }
    const updated = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { fundsReleased: finalPayload, fundsUtilised: finalPayload } }, { new: true }).exec();
    return updated;
}
exports.addInstallments = addInstallments;
async function addFunds(projectId, payload, user) {
    if (!payload.installment) {
        throw new custom_error_1.APIError(`Installment is required`);
    }
    // if(!(payload.releasedCost && payload.releasedDocuments)||!(payload.utilisedCost && payload.utilisedDocuments)){
    //   throw new APIError(`All Mandatory fields are required`)
    // }
    const fund = await project_model_1.project.findById(projectId).exec();
    if (!fund) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { funds, projectCost, citiisGrants } = fund;
    const otherFunds = funds.filter((fund) => fund.installment != payload.installment);
    const matchedFunds = funds.filter((fund) => fund.installment == payload.installment);
    if (payload.releasedCost && payload.releasedDocuments) {
        const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
        }
        if (citiisGrants < payload.releasedCost) {
            throw new Error("Released Amount should not exceed CitiisGrants");
        }
        let matchedFundsWithData = matchedFunds.length == 1 && !matchedFunds[0].releasedCost ? [] : matchedFunds;
        const updates = {
            funds: otherFunds.concat(matchedFundsWithData).concat([
                {
                    phase: matchedFunds[0].phase,
                    percentage: matchedFunds[0].percentage,
                    subInstallment: matchedFundsWithData.length + 1,
                    installment: payload.installment,
                    releasedDocuments: payload.releasedDocuments,
                    releasedCost: payload.releasedCost,
                    utilisedDocuments: matchedFunds[0].utilisedDocuments,
                    utilisedCost: matchedFunds[0].utilisedCost,
                    createdAt: new Date(),
                    modifiedAt: new Date(),
                    releasedBy: user._id,
                    utilisedBy: matchedFunds[0].utilisedBy ? matchedFunds[0].utilisedBy : null
                }
            ]).sort((a, b) => a.installment - b.installment)
        };
        let fundsData = updates.funds.reduce((p, fund) => {
            const { installmentType } = getPercentageByInstallment(fund.installment);
            const releasedItems = funds.filter((_fund) => (!_fund.deletedReleased && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON())));
            let difference = (Math.round(citiisGrants * (fund.percentage / 100))) - fund.releasedCost;
            p.push({
                fundsPlanned: Math.round(citiisGrants * (fund.percentage / 100)),
                difference: difference,
                cumulativeDifference: (p.cumulativeDifference || 0) + difference,
                installment: installmentType,
                percentage: fund.percentage,
                releasedItems,
                installmentLevelTotalReleased: releasedItems.reduce((p, item) => p + (item.releasedCost || 0), 0),
            });
            return p;
        }, []);
        if (payload.installment == (updates.funds.length - 1)) {
            let finalInstallmentFunds = fundsData.filter((eachfund) => eachfund.installment == payload.installment);
            if (finalInstallmentFunds[0].cumulativeDifference < 0) {
                throw new Error(`Released Amount exceeded CitiisGrants, Exceeded Amount is ${finalInstallmentFunds[0].cumulativeDifference}`);
            }
            if (finalInstallmentFunds[0].cumulativeDifference > 0) {
                throw new Error(`Released Amount is less than CitiisGrants,Please add ${finalInstallmentFunds[0].cumulativeDifference} amount`);
            }
        }
        const updatedFund = await project_model_1.project.findByIdAndUpdate(projectId, { $set: updates }, { new: true }).exec();
        module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.ADDED_FUND_RELEASE, projectId, updatedCost: payload.releasedCost, activityBy: user._id });
        return updatedFund;
    }
    if (payload.utilisedCost && payload.utilisedDocuments) {
        const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`);
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
        }
        let matchedFundsWithData = matchedFunds.length == 1 && !matchedFunds[0].utilisedCost ? [] : matchedFunds;
        const updates = {
            funds: otherFunds.concat(matchedFundsWithData).concat([
                {
                    phase: matchedFunds[0].phase,
                    percentage: matchedFunds[0].percentage,
                    subInstallment: matchedFundsWithData.length + 1,
                    installment: payload.installment,
                    releasedDocuments: matchedFunds[0].releasedDocuments,
                    releasedCost: matchedFunds[0].releasedCost,
                    utilisedDocuments: payload.utilisedDocuments,
                    utilisedCost: payload.utilisedCost,
                    createdAt: new Date(),
                    modifiedAt: new Date(),
                    utilisedBy: user._id,
                    releasedBy: matchedFunds[0].releasedBy ? matchedFunds[0].releasedBy : null
                }
            ]).sort((a, b) => a.installment - b.installment)
        };
        const updatedFund = await project_model_1.project.findByIdAndUpdate(projectId, { $set: updates }, { new: true }).exec();
        module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.ADDED_FUND_UTILIZATION, projectId, updatedCost: payload.utilisedCost, activityBy: user._id });
        return updatedFund;
    }
}
exports.addFunds = addFunds;
async function getFinancialInfoNew(projectId, userId, userRole) {
    const [isEligible1, isEligible2, canSeeMyProject, canSeeAllProjects, canManageProject] = await Promise.all([
        role_management_1.checkRoleScope(userRole, `manage-project-released-fund`),
        role_management_1.checkRoleScope(userRole, `manage-project-utilized-fund`),
        role_management_1.checkRoleScope(userRole, `view-my-project`),
        role_management_1.checkRoleScope(userRole, `view-all-projects`),
        role_management_1.checkRoleScope(userRole, `manage-project`)
    ]);
    if (!isEligible1 && !isEligible2 && !canSeeMyProject && !canSeeAllProjects && !canManageProject) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.FINANCIAL_INFO_NO_ACCESS);
    }
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const { fundsReleased, fundsUtilised, funds, projectCost, citiisGrants } = projectDetail;
    const documentIds = funds.map((fund) => (fund.releasedDocuments || []).concat(fund.utilisedDocuments || [])).reduce((p, c) => [...p, ...c], []).filter((v) => (!!v && mongoose_1.Types.ObjectId.isValid(v)));
    const documents = await module_4.documentsList(documentIds);
    let phases = await model_1.phaseSchema.find({}).exec();
    let fundsData = funds.reduce((p, fund) => {
        const { installmentType } = getPercentageByInstallment(fund.installment);
        const releasedItems = funds.filter((_fund) => (!_fund.deletedReleased && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { releasedDocuments: documents.filter((d) => (item.releasedDocuments || []).includes(d.id)) })));
        const utilisedItems = funds.filter((_fund) => (!_fund.deletedUtilised && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { utilisedDocuments: documents.filter((d) => (item.utilisedDocuments || []).includes(d.id)) })));
        let difference = (Math.round(citiisGrants * (fund.percentage / 100))) - fund.releasedCost;
        p.push({
            fundsPlanned: Math.round(citiisGrants * (fund.percentage / 100)),
            difference: difference,
            cumulativeDifference: (p.cumulativeDifference || 0) + difference,
            phase: phases.find(phase => phase.id == fund.phase),
            installment: installmentType,
            percentage: fund.percentage,
            // Filter empty data
            releasedItems,
            utilisedItems,
            installmentLevelTotalReleased: releasedItems.reduce((p, item) => p + (item.releasedCost || 0), 0),
            installmentLevelTotalUtilised: utilisedItems.reduce((p, item) => p + (item.utilisedCost || 0), 0)
        });
        return p;
    }, []);
    let ins = [];
    fundsData = fundsData.filter((f) => {
        if (!ins.includes(f.installment)) {
            ins.push(f.installment);
            return f;
        }
    });
    return {
        isMember: projectDetail.members.includes(userId) || (projectDetail.createdBy == userId),
        projectCost: projectCost,
        citiisGrants: citiisGrants,
        funds: {
            info: fundsData,
            totalReleased: fundsData.reduce((p, c) => p + c.installmentLevelTotalReleased, 0),
            totalUtilised: fundsData.reduce((p, c) => p + c.installmentLevelTotalUtilised, 0)
        }
    };
}
exports.getFinancialInfoNew = getFinancialInfoNew;
async function updateReleasedFundNew(projectId, payload, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { releasedDocuments, releasedCost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), releasedBy: user._id });
    updates['funds.$.releasedDocuments'] = releasedDocuments;
    updates['funds.$.releasedCost'] = releasedCost;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'funds._id': _id }, { $set: updates }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.UPDATED_FUND_RELEASE, oldCost: updatedProject.cost, updatedCost: payload.releasedCost, projectId, activityBy: user._id });
    return updatedProject;
}
exports.updateReleasedFundNew = updateReleasedFundNew;
async function updateUtilizedFundNew(projectId, payload, user) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`)
    ]);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { utilisedDocuments, utilisedCost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), utilisedBy: user._id });
    updates['funds.$.utilisedDocuments'] = utilisedDocuments;
    updates['funds.$.utilisedCost'] = utilisedCost;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'funds._id': _id }, { $set: updates }).exec();
    module_3.create({ activityType: error_msg_1.ACTIVITY_LOG.UPDATED_FUND_UTILIZATION, projectId, oldCost: updatedProject.utilisedCost, updatedCost: payload.cost, activityBy: user._id });
    return updatedProject;
}
exports.updateUtilizedFundNew = updateUtilizedFundNew;
async function deleteReleasedFundNew(projectId, payload, user) {
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { releasedDocuments, releasedCost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), releasedBy: user._id });
    updates['funds.$.deletedReleased'] = true;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'funds._id': _id }, { $set: updates }).exec();
    // createLog({activityType: ACTIVITY_LOG.UPDATED_FUND_RELEASE, oldCost: updatedProject.cost, updatedCost: payload.cost, projectId, activityBy: userId})
    return updatedProject;
}
exports.deleteReleasedFundNew = deleteReleasedFundNew;
async function deleteUtilizedFundNew(projectId, payload, user) {
    const [projectDetail, isEligible] = await Promise.all([
        project_model_1.project.findById(projectId).exec(),
        role_management_1.checkRoleScope(user.role, `manage-project-utilized-fund`)
    ]);
    if (!isEligible || (!projectDetail.members.includes(user._id))) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const { utilisedDocuments, utilisedCost, _id } = payload;
    let updates = {};
    updates = Object.assign({}, updates, { modifiedAt: new Date(), utilisedBy: user._id });
    updates['funds.$.deletedUtilised'] = true;
    const updatedProject = await project_model_1.project.findOneAndUpdate({ _id: projectId, 'funds._id': _id }, { $set: updates }).exec();
    // createLog({activityType: ACTIVITY_LOG.UPDATED_FUND_UTILIZATION, projectId, oldCost: updatedProject.cost, updatedCost: payload.cost, activityBy: userId})
    return updatedProject;
}
exports.deleteUtilizedFundNew = deleteUtilizedFundNew;
async function addInstallmentsNew(projectId, payload, user) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const isEligible = await role_management_1.checkRoleScope(user.role, `manage-project-released-fund`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const finalPayload = payload.funds.map((fund, index) => {
        if (!fund.phase) {
            throw new custom_error_1.APIError(`Phase is required`);
        }
        if (!fund.percentage) {
            throw new custom_error_1.APIError(`Percentage is required`);
        }
        return Object.assign({}, fund, { installment: index + 1 });
    });
    const overAllPercentage = finalPayload.reduce((p, fund) => p + Number(fund.percentage), 0);
    if (overAllPercentage != 100) {
        throw new custom_error_1.APIError(`Overall Percentage should be 100`);
    }
    const updated = await project_model_1.project.findByIdAndUpdate(projectId, { $set: { funds: finalPayload } }, { new: true }).exec();
    return updated;
}
exports.addInstallmentsNew = addInstallmentsNew;
async function getTotalReleasedFunds(projectId) {
    const projectDetail = await project_model_1.project.findById(projectId).exec();
    const { fundsReleased, fundsUtilised, funds, projectCost, citiisGrants } = projectDetail;
    const documentIds = funds.map((fund) => (fund.releasedDocuments || []).concat(fund.utilisedDocuments || [])).reduce((p, c) => [...p, ...c], []).filter((v) => (!!v && mongoose_1.Types.ObjectId.isValid(v)));
    const documents = await module_4.documentsList(documentIds);
    let phases = await model_1.phaseSchema.find({}).exec();
    let fundsData = funds.reduce((p, fund) => {
        const { installmentType } = getPercentageByInstallment(fund.installment);
        const releasedItems = funds.filter((_fund) => (!_fund.deletedReleased && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { releasedDocuments: documents.filter((d) => (item.releasedDocuments || []).includes(d.id)) })));
        const utilisedItems = funds.filter((_fund) => (!_fund.deletedUtilised && _fund.subInstallment && (_fund.installment == fund.installment))).map((item) => (Object.assign({}, item.toJSON(), { utilisedDocuments: documents.filter((d) => (item.utilisedDocuments || []).includes(d.id)) })));
        let difference = (Math.round(citiisGrants * (fund.percentage / 100))) - fund.releasedCost;
        p.push({
            fundsPlanned: Math.round(citiisGrants * (fund.percentage / 100)),
            difference: difference,
            cumulativeDifference: (p.cumulativeDifference || 0) + difference,
            phase: phases.find(phase => phase.id == fund.phase),
            installment: installmentType,
            percentage: fund.percentage,
            // Filter empty data
            releasedItems,
            utilisedItems,
            installmentLevelTotalReleased: releasedItems.reduce((p, item) => p + (item.releasedCost || 0), 0),
            installmentLevelTotalUtilised: utilisedItems.reduce((p, item) => p + (item.utilisedCost || 0), 0)
        });
        return p;
    }, []);
    let ins = [];
    fundsData = fundsData.filter((f) => {
        if (!ins.includes(f.installment)) {
            ins.push(f.installment);
            return f;
        }
    });
    return {
        projectCost: projectCost,
        citiisGrants: citiisGrants,
        funds: {
            info: fundsData,
            totalReleased: fundsData.reduce((p, c) => p + c.installmentLevelTotalReleased, 0),
            totalUtilised: fundsData.reduce((p, c) => p + c.installmentLevelTotalUtilised, 0)
        }
    };
}
exports.getTotalReleasedFunds = getTotalReleasedFunds;
