"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const app = require("./app");
require("./utils/role_management");
const socket_1 = require("./socket");
let http = require('http').Server(app);
socket_1.initializeSocket(http);
//  Port 
const PORT = process.env.PORT || 3000;
//  app listen
http.listen(PORT, () => {
    console.log(`Listening on port ${PORT}`);
});
