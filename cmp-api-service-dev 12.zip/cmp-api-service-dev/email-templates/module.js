"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const error_msg_1 = require("../utils/error_msg");
const marked = require("marked");
const email_1 = require("../utils/email");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const model_2 = require("../site-constants/model");
const module_1 = require("../users/module");
async function templateCreate(body) {
    try {
        if (!body.content || !body.templateName || !body.displayName) {
            throw new Error(error_msg_1.USER_ROUTER.MANDATORY);
        }
        let templateCreate = await model_1.TemplateSchema.create(body);
        return templateCreate;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.templateCreate = templateCreate;
;
async function list() {
    return await model_1.TemplateSchema.find({}).collation({ locale: 'en' }).sort({ templateName: 1 }).exec();
}
exports.list = list;
async function templateEdit(user, body, id) {
    try {
        let constantsList = await model_2.constantSchema.findOne({ key: 'editTemplate' }).exec();
        if (constantsList.value == "true") {
            const isEligible = await role_management_1.checkRoleScope(user.role, "edit-template");
            if (!isEligible)
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
            let objBody = {};
            if (body.content) {
                objBody.content = body.content;
            }
            if (body.displayName) {
                objBody.displayName = body.displayName;
            }
            if (body.subject) {
                objBody.subject = body.subject;
            }
            let templateCreate = await model_1.TemplateSchema.findByIdAndUpdate(id, { $set: objBody }, { new: true });
            return templateCreate;
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.templateEdit = templateEdit;
;
async function templateDelete(body, id) {
    try {
        let templateCreate = await model_1.TemplateSchema.findByIdAndRemove(id);
        return { message: "Template deleted successfully" };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.templateDelete = templateDelete;
;
async function templateGet(user, id) {
    try {
        const isEligible = await role_management_1.checkRoleScope(user.role, "display-template-management");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.INVALID_ADMIN, 403);
        let template = await model_1.TemplateSchema.findById(id);
        return template;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.templateGet = templateGet;
;
async function testTemplate(id, email) {
    let template = await model_1.TemplateSchema.findById(id);
    let templatInfo = await getTemplateBySubstitutions(template.templateName, {});
    if (!module_1.validateEmail(email))
        throw new Error(error_msg_1.USER_ROUTER.VALID_EMAIL);
    email_1.nodemail({
        email: email,
        subject: templatInfo.subject,
        html: templatInfo.content
    });
    return { message: "Email sent successfully" };
}
exports.testTemplate = testTemplate;
async function getTemplateBySubstitutions(templateId, substitutions) {
    try {
        var template = await model_1.TemplateSchema.findOne({ templateName: templateId }).exec();
        if (!template) {
            throw new Error(error_msg_1.TEMPLATE.INVALID_TEMPLATE + `${templateId}`);
        }
        if (!substitutions) {
            substitutions = {};
        }
        return {
            subject: Object.keys(substitutions).reduce((prev, key) => {
                return prev.replace(new RegExp(`\\[${key}\\]`, "g"), substitutions[key]);
            }, template.subject),
            content: `<style type="text/css">p{margin-bottom:1em;}</style>${template.form == "html" ?
                Object.keys(substitutions).reduce((prev, key) => {
                    return prev.replace(new RegExp(`\\[${key}\\]`, "g"), substitutions[key]);
                }, template.content) :
                marked(Object.keys(substitutions).reduce((prev, key) => {
                    return prev.replace(new RegExp(`\\[${key}\\]`, "g"), substitutions[key]);
                }, template.content))}`
        };
    }
    catch (err) {
        throw err;
    }
}
exports.getTemplateBySubstitutions = getTemplateBySubstitutions;
