"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const role_management_1 = require("../utils/role_management");
const module_1 = require("../role/module");
async function createConstant(objBody, userId) {
    let userRoles = await module_1.userRoleAndScope(userId);
    let userRole = userRoles.data[0];
    const isEligible = await role_management_1.checkRoleScope(userRole, "view-edit-configurations");
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.UNAUTHORIZED_ACTION, 403);
    }
    return await model_1.constantSchema.create(objBody);
}
exports.createConstant = createConstant;
async function addConstants(objBody, userId) {
    try {
        let userRoles = await module_1.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "view-edit-configurations");
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.UNAUTHORIZED_ACTION, 403);
        }
        let constantValue;
        const keys = Object.keys(objBody);
        if ([undefined, null, ''].includes(objBody[keys[0]])) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.MANDATORY);
        }
        let constantInfo = await model_1.constantSchema.findOne({ key: keys[0] });
        if (constantInfo.type && constantInfo.type == "boolean") {
            if (objBody[keys[0]] == "true") {
                constantValue = "true";
            }
            else if (objBody[keys[0]] == "false") {
                constantValue = "false";
            }
            else {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.CONSTANT_INVALID);
            }
        }
        if (constantInfo.type && constantInfo.type == "number") {
            if (Number(objBody[keys[0]]) == objBody[keys[0]] && Number(objBody[keys[0]]) >= 0) {
                constantValue = Number(objBody[keys[0]]);
            }
            else {
                throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.CONSTANT_INVALID);
            }
        }
        let constantsData = await model_1.constantSchema.findOneAndUpdate({ key: keys[0] }, { $set: { value: objBody[keys[0]] } }, { new: true }).exec();
        return constantsData;
    }
    catch (err) {
        throw err;
    }
}
exports.addConstants = addConstants;
async function constantsList() {
    try {
        // let userRoles = await userRoleAndScope(userId);
        // let userRole = userRoles.data[0];
        // const isEligible = await checkRoleScope(userRole, "view-edit-configurations");
        //     if (!isEligible) {
        //     throw new APIError("Unauthorized for this Action", 403);
        // }
        return await model_1.constantSchema.find({}).exec();
    }
    catch (err) {
        throw err;
    }
}
exports.constantsList = constantsList;
async function getConstantsGroupBy() {
    const data = await model_1.constantSchema.find({}).exec();
    let ans = data.reduce((p, c) => {
        c = c.toObject();
        if (p[c.groupName]) {
            p[c.groupName].push(c);
        }
        else {
            p[c.groupName] = [c];
        }
        return p;
    }, {});
    return ans;
}
exports.getConstantsGroupBy = getConstantsGroupBy;
async function getConstantsAndValues(constKeys) {
    try {
        const constantInfo = await model_1.constantSchema.find({}).exec();
        let result = constantInfo.reduce((prev, current) => {
            if (constKeys.includes(current.key)) {
                prev[current.key] = current.value;
            }
            return prev;
        }, {});
        return result;
    }
    catch (err) {
        throw err;
    }
}
exports.getConstantsAndValues = getConstantsAndValues;
