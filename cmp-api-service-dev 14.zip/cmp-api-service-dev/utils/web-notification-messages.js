"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DOC_NOTIFICATIONS = {
    inviteForDocument: (name) => `You are invited by [from] to collaborate on the document ${name}`,
    suggestTagNotification: (name) => `You have a tag suggestion on the document ${name} from [from]`,
    approveTagNotification: (name) => `A tag you suggested has been approved on the document ${name}`,
    approveRemoveTagNotification: (name) => `A tag you suggested for removal has been approved on the document ${name}`,
    rejectTagNotification: (name) => `A tag you suggested has been rejected on the document ${name}`,
    rejectRemoveTagNotification: (name) => `A tag you suggested for removal has been rejected on the document ${name}`,
    addCommentToDoc: (name) => `A new comment has been added to the document ${name}`,
    documentUpdate: (text, name) => `Document ${name}, has been updated ${text ? "with " + text : ""}`,
    invitePeopleDoc: (sharedUsers, role, name) => `Your document ${name} on CITIIS Management Platform, is shared with ${sharedUsers} in the capacity of ${role}`,
    publishDocument: (name) => `Document ${name}, is published`,
    unPublishDocument: (name) => `Document ${name} is unpublished`,
    replaceDocument: (name) => `Document ${name} is replaced with a new document.`,
    documentRequest: (name) => `Someone request your document for access on ${name}.`,
    documentRequestApproved: (name) => `your request for access was accecpt on his ${name} document.`,
    documentRequestRejected: (name) => `your request for access was rejected on his ${name} document.`,
    documentSuggestTagsModified: (name) => `You have new update in tag suggestion on the document ${name} from [from]`,
};
exports.GROUP_NOTIFICATIONS = {
    youAddTOGroup: `You are added to a group [groupId]`,
    groupStatus: `Group status for [groupId], which you are a part of, has been updated on CITIIS Management Platform.`,
    addGroupMember: `A new member is added to the user group [groupId] on CITIIS Management Platform.`
};
exports.USER_PROFILE = {
    passwordUpdateByAdmin: `Your password has been updated by [from]`,
    emailUpdateByAdmin: `Your email has been updated by [from]`,
    phoneUpdateByAdmin: `Your phone number has been updated by [from]`,
    emailUpdateByUser: `successfully you email has been updated`,
    phoneUpdateByUser: `successfully you phone number has been updated`,
    passwordUpdateByUser: `successfully you password has been updated`,
};
