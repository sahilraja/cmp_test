"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const error_handling_utils_1 = require("../utils/error-handling-utils");
const utils_1 = require("../utils/utils");
const router = express_1.Router();
router.post(`/create`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.create(res.locals.user._id, req.body, res.locals.user.role));
    }
    catch (error) {
        if (error.code == 11000)
            error.message = `${error.message.match(/{ : "(.*?)" }/g).pop().split('"')[1]} already exists`;
        next(error_handling_utils_1.processMongooseErrors(error)[0] || error_handling_utils_1.processMongooseErrors(error));
    }
});
router.get(`/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list());
    }
    catch (error) {
        next(error);
    }
});
router.post(`/getStepsByIds`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getStepsByIds(req.body.stepIds));
    }
    catch (error) {
        next(error);
    }
});
router.get(`/:id/detial`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.stepDetail(req.params.id));
    }
    catch (error) {
        next(error);
    }
});
router.post(`/:id/edit`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.updateStep(req.params.id, req.body, res.locals.user.role));
    }
    catch (error) {
        if (error.code == 11000)
            error.message = `${error.message.match(/{ : "(.*?)" }/g).pop().split('"')[1]} already exists`;
        next(error_handling_utils_1.processMongooseErrors(error)[0] || error_handling_utils_1.processMongooseErrors(error));
    }
});
module.exports = router;
