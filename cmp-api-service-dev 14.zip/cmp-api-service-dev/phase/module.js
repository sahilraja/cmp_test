"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const role_management_1 = require("../utils/role_management");
const module_1 = require("../project/module");
async function createPhase(payload, userObj) {
    try {
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "phase-manage");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.UNAUTHORIZED_ACTION, 403);
        if (!payload.phaseName && !payload.colorCode) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.MANDATORY);
        }
        if (!/.*[A-Za-z0-9]{1}.*$/.test(payload.phaseName))
            throw new Error(error_msg_1.USER_ROUTER.NAME_ERROR);
        let phaseInfo = await model_1.phaseSchema.create(Object.assign({}, payload, { phaseCode: payload.phaseName.toLowerCase(), createdBy: userObj._id }));
        let _a = phaseInfo.toObject(), { disable } = _a, phaseResult = __rest(_a, ["disable"]);
        return phaseResult;
    }
    catch (err) {
        throw err;
    }
}
exports.createPhase = createPhase;
async function editPhase(phaseId, body, userObj, token) {
    try {
        let isEligible = await role_management_1.checkRoleScope(userObj.role, "phase-manage");
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.UNAUTHORIZED_ACTION, 403);
        if (!/.*[A-Za-z0-9]{1}.*$/.test(body.phaseName))
            throw new Error(error_msg_1.USER_ROUTER.NAME_ERROR);
        let phaseInfo = await model_1.phaseSchema.findByIdAndUpdate(phaseId, { $set: { phaseName: body.phaseName, phaseCode: body.phaseName.toLowerCase(), colorCode: body.colorCode } }, { new: true }).exec();
        let _a = phaseInfo.toObject(), { disable } = _a, phaseResult = __rest(_a, ["disable"]);
        module_1.editProjectPhaseInES(phaseResult.id || phaseResult._id, token);
        return phaseResult;
    }
    catch (err) {
        throw err;
    }
}
exports.editPhase = editPhase;
async function getPhase(phaseId) {
    try {
        let phaseInfo = await model_1.phaseSchema.findById(phaseId).exec();
        let _a = phaseInfo.toObject(), { disable } = _a, phaseResult = __rest(_a, ["disable"]);
        return phaseResult;
    }
    catch (err) {
        throw err;
    }
}
exports.getPhase = getPhase;
async function deletePhase(phaseId) {
    try {
        await model_1.phaseSchema.findByIdAndUpdate(phaseId, { disable: true }).exec();
        return { messsage: "successfully deleted phase" };
    }
    catch (err) {
        throw err;
    }
}
exports.deletePhase = deletePhase;
async function listPhase() {
    try {
        return await model_1.phaseSchema.find({}).exec();
    }
    catch (err) {
        throw err;
    }
}
exports.listPhase = listPhase;
async function userListPhase(userId) {
    try {
        return await model_1.phaseSchema.findById({ createdBy: userId }).exec();
    }
    catch (err) {
        throw err;
    }
}
exports.userListPhase = userListPhase;
