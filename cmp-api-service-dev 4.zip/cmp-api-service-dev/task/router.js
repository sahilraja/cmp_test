"use strict";
const express_1 = require("express");
const proxy = require("express-http-proxy");
const router = express_1.Router();
const TASK_HOST = process.env.TASK_URL || "http://localhost:5052";
router.use('/', proxy(TASK_HOST, {
    proxyReqPathResolver: ((req) => {
        return req.url;
    }),
    proxyReqOptDecorator: async function (proxyReqOpts, srcReq) {
        // you can update headers
        proxyReqOpts.headers['Content-Type'] = 'application/json';
        proxyReqOpts.headers['Authorization'] = srcReq.headers.authorization;
        proxyReqOpts.headers['Accept'] = 'application/json';
        return proxyReqOpts;
    }
}));
module.exports = router;
