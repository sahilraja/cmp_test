"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const model_2 = require("../email-templates/model");
const rbac_1 = require("../utils/rbac");
async function notificationsUpdate(reqObject) {
    try {
        let { role, templateName, displayName, email, mobile } = reqObject;
        const oldInfo = await getRoleNotification(role, templateName);
        if (typeof (mobile) === 'undefined') {
            mobile = oldInfo.mobile;
        }
        if (typeof (email) === 'undefined') {
            email = oldInfo.email;
        }
        let updatedData = await model_1.notificationSchema.update({ 'role': role, "templates.templateName": templateName }, { $set: { 'templates.$.displayName': displayName, 'templates.$.mobile': mobile, 'templates.$.email': email } });
        return { message: "success", status: true };
    }
    catch (err) {
        throw err;
    }
}
exports.notificationsUpdate = notificationsUpdate;
async function addRoleNotification(roleName) {
    try {
        // let {roles}:any= await role_list();
        // roles.filter((user:any)=>{
        //     return user.role == roleName
        // })
        // if(roles.length){
        //     throw new Error(ROLE_NOT_EXIST);
        // }
        let existingRoll = await model_1.notificationSchema.find({ role: roleName }).count().exec();
        if (existingRoll) {
            throw new custom_error_1.APIError(error_msg_1.USER_ROUTER.CREATE_ROLE_NOTIFICATION_FAIL);
        }
        let templateList = await model_2.TemplateSchema.find({}).exec();
        let templates = [];
        templateList.forEach((template) => {
            templates.push({
                templateName: template.templateName,
                displayName: template.displayName,
                email: true,
                mobile: true
            });
        });
        return await model_1.notificationSchema.create({ role: roleName, templates });
    }
    catch (err) {
        throw err;
    }
}
exports.addRoleNotification = addRoleNotification;
async function addTemplateNotification(objBody) {
    try {
        const { templateName, displayName } = objBody;
        let templateList = await model_2.TemplateSchema.findOne({ templateName }).exec();
        if (!templateList) {
            throw new custom_error_1.APIError("Template is not found in email templates");
        }
        return await model_1.notificationSchema.updateMany({}, { "$push": { templates: { templateName, displayName, email: true, mobile: true } } });
    }
    catch (err) {
        throw err;
    }
}
exports.addTemplateNotification = addTemplateNotification;
async function getRoleNotification(roleName, templateName) {
    try {
        //let notificationInfo:any = await notificationSchema.aggregate([{$match:{ role: roleName}},{$unwind : "$templates"},{ $replaceRoot: { newRoot:{ $mergeObjects: [ { email: "$email", mobile:"$mobile",role:"$role"}, "$templates" ] }} }])
        let notificationInfo = await model_1.notificationSchema.findOne({ role: roleName }).exec();
        notificationInfo = notificationInfo.toObject();
        let [userTemplateInfo] = notificationInfo.templates.filter((notif) => {
            return notif.templateName == templateName;
        });
        let { mobile, email } = userTemplateInfo;
        return { role: roleName, templateName, mobile, email };
    }
    catch (err) {
        throw err;
    }
}
exports.getRoleNotification = getRoleNotification;
async function userRolesNotification(userId, templateName) {
    try {
        let { data } = await rbac_1.getRoles(userId);
        let roleInfo = await Promise.all(data.map(async (role) => {
            return await getRoleNotification(role, templateName);
        }));
        //return roleInfo
        let notificationResult = roleInfo.reduce((acc, roleObj) => {
            if (roleObj.email == true) {
                acc['email'] = true;
            }
            if (roleObj.mobile == true) {
                acc['mobile'] = true;
            }
            return acc;
        }, { email: false, mobile: false });
        return notificationResult;
    }
    catch (err) {
        throw err;
    }
}
exports.userRolesNotification = userRolesNotification;
async function getNotifications() {
    const notifications = await model_1.notificationSchema.find({}).exec();
    const notificationScenarios = notifications[0].templates.reduce((p, template) => [...p, (template.displayName || template.templateName)], []);
    return { data: notifications, notificationScenarios };
}
exports.getNotifications = getNotifications;
