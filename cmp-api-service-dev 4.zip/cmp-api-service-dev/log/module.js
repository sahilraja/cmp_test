"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const users_1 = require("../utils/users");
const mongoose_1 = require("mongoose");
const tag_model_1 = require("../tags/tag_model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
async function create(payload) {
    return await model_1.ActivitySchema.create(payload);
}
exports.create = create;
async function list(query = {}) {
    return await model_1.ActivitySchema.find(query).exec();
}
exports.list = list;
async function detail(id) {
    return await model_1.ActivitySchema.findById(id).exec();
}
exports.detail = detail;
async function edit(id, updates) {
    return await model_1.ActivitySchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
}
exports.edit = edit;
async function paginatedList(query = {}, page = 1, limit = 20) {
    return await model_1.ActivitySchema.paginate(query, { page, limit });
}
exports.paginatedList = paginatedList;
async function getTaskLogs(taskId, token, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `view-activity-log`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
    }
    const activities = await model_1.ActivitySchema.find({ taskId }).sort({ createdAt: 1 }).exec();
    const userIds = activities.reduce((p, activity) => [...p, ...((activity.addedUserIds || []).concat(activity.removedUserIds || []).concat([activity.activityBy]))
    ], []).filter((v) => v);
    const subTaskIds = activities.reduce((p, activity) => {
        p = p.concat([activity.subTask, ...(activity.linkedTasks || []), ...(activity.unlinkedTasks || [])]);
        return p;
    }, []).filter((v) => !!v);
    const [usersInfo, subTasks] = await Promise.all([
        users_1.userFindMany('_id', userIds, { firstName: 1, lastName: 1, middleName: 1, email: 1, phoneNumber: 1, countryCode: 1, profilePic: 1, phone: 1, is_active: 1 }),
        users_1.getTasksByIds(subTaskIds, token)
    ]);
    const tagObjects = await tag_model_1.tags.find({ _id: { $in: [...new Set(activities.reduce((main, curr) => [...main, ...(curr.tagsAdded || []), ...(curr.tagsRemoved || [])], []))] } }).exec();
    let logs = activities.map((activity) => (Object.assign({}, activity.toJSON(), { subTask: subTasks.find((subTask) => subTask._id == activity.subTask), linkedTasks: subTasks.filter((subTask) => (activity.linkedTasks || []).includes(subTask._id)), unlinkedTasks: subTasks.filter((subTask) => (activity.unlinkedTasks || []).includes(subTask._id)), activityBy: usersInfo.find((user) => user._id == activity.activityBy), addedUserIds: usersInfo.filter((s) => (activity.addedUserIds || []).includes(s._id)), removedUserIds: usersInfo.filter((s) => (activity.removedUserIds || []).includes(s._id)), tagsAdded: tagObjects.filter(({ id }) => (activity.tagsAdded || []).includes(id)), tagsRemoved: tagObjects.filter(({ id }) => (activity.tagsRemoved || []).includes(id)) }))).sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    return (logs.map(logObj => getFormantedTaskLogs(logObj))).reverse();
}
exports.getTaskLogs = getTaskLogs;
;
async function getDocumentsLogs(docId, token, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `document-activity-log`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
        const select = { name: true, description: true };
        const activities = await model_1.ActivitySchema.find({ documentId: mongoose_1.Types.ObjectId(docId) }).populate([{ path: 'fromPublished', select }, { path: 'fromPublished', select }, { path: "documentId", select }]).exec();
        let logs = await Promise.all(activities.map((activity) => {
            return activityFetchDetails(activity);
        }));
        return (logs.map(logObj => getFormantedDocLogs(logObj))).reverse();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getDocumentsLogs = getDocumentsLogs;
;
async function activityFetchDetails(activity) {
    const userObj = (activity.documentAddedUsers || []).concat(activity.documentRemovedUsers || []).filter(({ type }) => type == "user");
    const groupObj = (activity.documentAddedUsers || []).concat(activity.documentRemovedUsers || []).filter(({ type }) => type == "group");
    const userIds = userObj.reduce((main, curr) => main.concat(curr.id), []);
    const groupIds = groupObj.reduce((main, curr) => main.concat(curr.id), []);
    let groupsData = await users_1.groupPatternMatch({}, {}, { "_id": groupIds }, {});
    let usersData = await users_1.userFindMany('_id', userIds.concat(activity.activityBy), { firstName: 1, lastName: 1, middleName: 1, email: 1, phoneNumber: 1, countryCode: 1, profilePic: 1, phone: 1, is_active: 1 });
    usersData = groupsData.concat(usersData);
    const tagIds = (activity.tagsAdded || []).concat(activity.tagsRemoved || []);
    const tagsData = await tag_model_1.tags.find({ _id: { $in: tagIds } });
    try {
        return Object.assign({}, activity.toJSON(), { activityBy: usersData.find((users) => activity.activityBy == users._id), documentAddedUsers: usersData.filter((obj) => (activity.documentAddedUsers || []).map((d) => d.id).includes(obj._id)), documentRemovedUsers: usersData.filter((obj) => (activity.documentRemovedUsers || []).map((d) => d.id).includes(obj._id)), tagsAdded: tagsData.filter((obj) => (activity.tagsAdded || []).includes(obj.id)), tagsRemoved: tagsData.filter((obj) => (activity.tagsRemoved || []).includes(obj.id)) });
    }
    catch (err) {
        throw err;
    }
}
async function getProfileLogs(profileId, token) {
    try {
        const activities = await model_1.ActivitySchema.find({ profileId: mongoose_1.Types.ObjectId(profileId) }).exec();
        let logs = await Promise.all(activities.map((activity) => {
            return profileFetchDetails(activity.toJSON());
        }));
        return (logs.map(logObj => getFormantedUserLogs(logObj))).reverse();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getProfileLogs = getProfileLogs;
;
async function profileFetchDetails(activity) {
    try {
        let userObj = (activity.profileId) ? await users_1.userFindMany("_id", [activity.activityBy, activity.profileId]) : await users_1.userFindMany("_id", [activity.activityBy]);
        return Object.assign({}, activity, { activityBy: userObj.find((users) => activity.activityBy == users._id), profileId: (activity.profileId) ? Object.assign({ firstName: '', lastName: '', middleName: '', email: '' }, userObj.find((users) => activity.profileId == users._id)) : "" });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function getMergedLogs() {
    try {
        const activities = await model_1.ActivitySchema.find({ activityType: "MERGED-TAG" }, { activityType: 1, activityBy: 1, mergedTag: 1, tagsToMerge: 1, updatedAt: 1, createdAt: 1 }).exec();
        return await Promise.all(activities.map((activity) => {
            return profileFetchDetails(activity.toJSON());
        }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getMergedLogs = getMergedLogs;
async function projectLogs(projectId, token, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `project-activity-log`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.TASK_ERROR.UNAUTHORIZED_PERMISSION);
        const activities = await model_1.ActivitySchema.find({ projectId }).populate({ path: 'projectId' }).exec();
        let taskObjects = await users_1.getTasksByIds([...new Set((activities.reduce((main, curr) => main.concat([curr.taskId]), [])).filter((id) => mongoose_1.Types.ObjectId(id)))], token);
        let logs = await Promise.all(activities.map((activity) => {
            return fetchProjectLogDetails(activity.toJSON(), taskObjects);
        }));
        return (logs.map(logObj => getFormantedProjectLogs(logObj))).reverse();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.projectLogs = projectLogs;
async function fetchProjectLogDetails(activity, taskObjects) {
    try {
        let userObj = await users_1.userFindMany("_id", [activity.activityBy, ...(activity.addedUserIds || []), ...(activity.removedUserIds || [])]);
        return Object.assign({}, activity, { activityBy: userObj.find(({ _id }) => _id == activity.activityBy), addedUserIds: userObj.filter(({ _id }) => (activity.addedUserIds || []).includes(_id)), removedUserIds: userObj.filter(({ _id }) => (activity.removedUserIds || []).includes(_id)), taskId: taskObjects.find(({ _id }) => activity.taskId == _id) });
    }
    catch (err) {
        throw err;
    }
    ;
}
;
function getFormantedDocLogs(activityLog) {
    let message;
    switch (activityLog.activityType) {
        case 'DOCUMENT_CREATED':
            message = `${UserFullName(activityLog.activityBy)} created this document`;
            break;
        case 'DOCUMENT_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} updated this document`;
            break;
        case 'CANCEL_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} canceled this document update`;
            break;
        case 'TAGS_ADDED':
            message = `${UserFullName(activityLog.activityBy)} added tags ${getTagName(activityLog.tagsAdded)} to this document`;
            break;
        case 'TAGS_REMOVED':
            message = `${UserFullName(activityLog.activityBy)} removed tags ${getTagName(activityLog.tagsRemoved)} from this document`;
            break;
        case 'MODIFIED_USER_SHARED_AS_VIEWER':
            message = `${UserFullName(activityLog.activityBy)} modified document access from collaborator to viewer for ${getNamesFromIds(activityLog.documentAddedUsers)}`;
            break;
        case 'MODIFIED_USER_SHARED_AS_COLLABORATOR':
            message = `${UserFullName(activityLog.activityBy)} modified document access from viewer to collaborator for  ${getNamesFromIds(activityLog.documentAddedUsers)}`;
            break;
        case 'MODIFIED_GROUP_SHARED_AS_VIEWER':
            message = `${UserFullName(activityLog.activityBy)} modified document access from collaborator to viewer for ${getNamesFromIds(activityLog.documentAddedUsers)}`;
            break;
        case 'MODIFIED_GROUP_SHARED_AS_COLLABORATOR':
            message = `${UserFullName(activityLog.activityBy)} modified document access from viewer to collaborator for  ${getNamesFromIds(activityLog.documentAddedUsers)}`;
            break;
        case 'DOCUMENT_SHARED_AS_VIEWER':
            message = `${UserFullName(activityLog.activityBy)} shared document with ${getNamesFromIds(activityLog.documentAddedUsers)} with view access`;
            break;
        case 'DOCUMENT_SHARED_AS_COLLABORATOR':
            message = `${UserFullName(activityLog.activityBy)} shared document with ${getNamesFromIds(activityLog.documentAddedUsers)} with edit access`;
            break;
        case 'REMOVED_USER_FROM_DOCUMENT':
            message = `${UserFullName(activityLog.activityBy)} removed access to this document for ${getNamesFromIds(activityLog.documentRemovedUsers)}`;
            break;
        case 'REMOVED_GROUP_FROM_DOCUMENT':
            message = `${UserFullName(activityLog.activityBy)} removed access to this document for ${getNamesFromIds(activityLog.documentRemovedUsers)} group`;
            break;
        case 'DOUCMENT_PUBLISHED':
            message = `${UserFullName(activityLog.activityBy)} published this document`;
            break;
        case 'DOUCMENT_UNPUBLISHED':
            message = `${UserFullName(activityLog.activityBy)} unpublished this document`;
            break;
        case 'DOUCMENT_REPLACED':
            message = `${UserFullName(activityLog.activityBy)} replaced this document`;
            break;
        case 'DOCUMENT_DELETED':
            message = `${UserFullName(activityLog.activityBy)} deleted this document`;
            break;
        case 'DOCUMENT_VIEWED':
            message = `${UserFullName(activityLog.activityBy)} viewed this document`;
            break;
        case 'DOCUMENT_COMMENT':
            message = `${UserFullName(activityLog.activityBy)} added a comment to this document`;
            break;
        case 'DOCUMENT_DOWNLOAD':
            message = `${UserFullName(activityLog.activityBy)} Dowloaded this document`;
            break;
        case "TAGS_ADD_AND_REMOVED":
            message = `${UserFullName(activityLog.activityBy)} added tags ${getTagName(activityLog.tagsAdded)} to this document and removed tags ${getTagName(activityLog.tagsRemoved)} from this document`;
            break;
        default:
            message = "";
    }
    return { message, activityBy: activityLog.activityBy._id, createdAt: activityLog.createdAt, activityType: "NEW_RESPONSE" };
}
function UserFullName({ firstName, middleName, lastName }) {
    return (firstName ? firstName + " " : "") + (middleName ? middleName + " " : "") + (lastName ? lastName : "");
}
function getTagName(tagsArr) {
    let namesArr = [];
    let namesStr;
    tagsArr.map(item => {
        namesArr.push(item.tag);
    });
    namesStr = namesArr.join();
    return namesStr;
}
function getNamesFromIds(userIdsArr) {
    let namesArr = [];
    let namesStr;
    userIdsArr.map((item) => {
        if (item.firstName && item.lastName) {
            namesArr.push(`${item.firstName} ${item.lastName} `);
        }
        else {
            namesArr.push(item.name);
        }
    });
    namesStr = namesArr.join();
    return namesStr;
}
function getFormantedTaskLogs(activityLog) {
    let message;
    switch (activityLog.activityType) {
        case 'TASK_CREATED':
            message = `${UserFullName(activityLog.activityBy)} created this task`;
            break;
        case 'ASSIGNEE_CHANGED':
            message = `${UserFullName(activityLog.activityBy)} has changed the assignee for the task from ${activityLog.removedUserIds[0].firstName} ${activityLog.removedUserIds[0].lastName} to ${activityLog.addedUserIds[0].firstName} ${activityLog.addedUserIds[0].lastName}`;
            break;
        case 'APPROVED_BY_USER':
            message = `${UserFullName(activityLog.activityBy)} approved this task`;
            break;
        case 'ENDORSED_BY_USER':
            message = `${UserFullName(activityLog.activityBy)} endorsed this task`;
            break;
        case 'TASK_REOPENED':
            message = `${UserFullName(activityLog.activityBy)} reopened this task`;
            break;
        case 'TASK_REJECTED':
            message = `${UserFullName(activityLog.activityBy)} rejected this task`;
            break;
        case 'STEP_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} has updated the step from ${activityLog.oldStep.name} to ${activityLog.updatedStep.name}`;
            break;
        case 'PILLAR_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} has updated the pillar from ${activityLog.updatedPillar.name} to ${activityLog.updatedPillar.name}`;
            break;
        case 'APPROVERS_UPDATED':
            if (activityLog.addedUserIds && activityLog.addedUserIds.length && activityLog.removedUserIds && activityLog.removedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} and removed ${getNamesFromIds(activityLog.removedUserIds)} as approver(s)`;
            }
            else if (activityLog.addedUserIds && activityLog.addedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} as approver(s)`;
            }
            else {
                message = `${UserFullName(activityLog.activityBy)} has removed ${getNamesFromIds(activityLog.removedUserIds)} as approver(s)`;
            }
            break;
        case 'ENDORSERS_UPDATED':
            if (activityLog.addedUserIds && activityLog.addedUserIds.length && activityLog.removedUserIds && activityLog.removedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} and removed ${getNamesFromIds(activityLog.removedUserIds)} as endorser(s)`;
            }
            else if (activityLog.addedUserIds && activityLog.addedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} as endorser(s)`;
            }
            else {
                message = `${UserFullName(activityLog.activityBy)} has removed ${getNamesFromIds(activityLog.removedUserIds)} as endorser(s)`;
            }
            break;
        case 'SUPPORTERS_UPDATED':
            if (activityLog.addedUserIds && activityLog.addedUserIds.length && activityLog.removedUserIds && activityLog.removedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} and removed ${getNamesFromIds(activityLog.removedUserIds)} as supporter(s)`;
            }
            else if (activityLog.addedUserIds && activityLog.addedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} as supporter(s)`;
            }
            else {
                message = `${UserFullName(activityLog.activityBy)} has removed ${getNamesFromIds(activityLog.removedUserIds)} as supporter(s)`;
            }
            break;
        case 'VIEWERS_UPDATED':
            if (activityLog.addedUserIds && activityLog.addedUserIds.length && activityLog.removedUserIds && activityLog.removedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} and removed ${getNamesFromIds(activityLog.removedUserIds)} as viewer(s)`;
            }
            else if (activityLog.addedUserIds && activityLog.addedUserIds.length) {
                message = `${UserFullName(activityLog.activityBy)} has added ${getNamesFromIds(activityLog.addedUserIds)} as viewer(s)`;
            }
            else {
                message = `${UserFullName(activityLog.activityBy)} has removed ${getNamesFromIds(activityLog.removedUserIds)} as viewer(s)`;
            }
            break;
        case 'TASK_STATUS_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} has updated the task status from ${getStatus(activityLog.oldStatus, "")} to ${getStatus(activityLog.updatedStatus, "")}`;
            break;
        case 'TASK_START_DATE_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} has updated the start date from ${activityLog.previousStartDate} to ${activityLog.updatedStartDate}`;
            break;
        case 'TASK_DUE_DATE_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} has updated the due date from ${activityLog.previousEndDate} to ${activityLog.updatedEndDate}`;
            break;
        case 'DOCUMENTS_ADDED':
            message = `${UserFullName(activityLog.activityBy)} added documents to this task`;
            break;
        case 'SUBTASK_ADDED':
            message = `${UserFullName(activityLog.activityBy)} added subtask ${(activityLog.subTask || {}).name} to this task`;
            break;
        case 'DOCUMENTS_REMOVED':
            message = `${UserFullName(activityLog.activityBy)} removed documents from this task`;
            break;
        case 'SUBTASK_REMOVED':
            message = `${UserFullName(activityLog.activityBy)} removed subtask ${(activityLog.subTask || {}).name} from this task`;
            break;
        case 'NEW_TASK_LINKED':
            message = `${UserFullName(activityLog.activityBy)} linked ${(activityLog.subTask || {}).name} task to this task`;
            break;
        case 'LINKED_TASK_REMOVED':
            message = `${UserFullName(activityLog.activityBy)} removed linked task ${(activityLog.subTask || {}).name} from this task`;
            break;
        case 'TAGS_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} updated tags of this task`;
            break;
        default:
            message = "";
    }
    return { message, activityBy: activityLog.activityBy._id, createdAt: activityLog.createdAt, activityType: "NEW_RESPONSE" };
}
function getStatus(status_code, status = "") {
    switch (status_code) {
        case 0:
            return "Create";
        case 1:
            return status = "reject" ? ' Rejected ' : status = "reopen" ? 'Reopened' : 'To Do';
        case 2:
            return 'In Progress';
        case 3:
            return 'Pending Approval';
        case 4:
            return 'Approved';
        case 5:
            return 'Completed';
        case 6:
            return "Rejected";
        case 7:
            return 'Request For Re-assignment';
        case 8:
            return 'Cancelled';
        case 9:
            return 'Pending Endorsement';
        case 10:
            return 'Endorsed';
    }
}
function getFormantedProjectLogs(activityLog) {
    let message;
    switch (activityLog.activityType) {
        case 'PROJECT_CREATED':
            message = `${UserFullName(activityLog.activityBy)} created this Project`;
            break;
        case 'TASK_DATES_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} updated the task start date`;
            break;
        case 'CREATE_TASK_FROM_PROJECT':
            message = `${UserFullName(activityLog.activityBy)} created task ${activityLog.taskId ? activityLog.taskId.name : ""}`;
            break;
        case 'PROJECT_MEMBERS_UPDATED':
            message = `${UserFullName(activityLog.activityBy)} added ${getNamesFromIds(activityLog.addedUserIds)} as a core team member`;
            break;
        case 'ADDED_FUND_RELEASE':
            message = `${UserFullName(activityLog.activityBy)} added ${activityLog.updatedCost} INR to fund released`;
            break;
        case 'ADDED_FUND_UTILIZATION':
            message = `${UserFullName(activityLog.activityBy)} added ${activityLog.updatedCost} INR to fund utilised`;
            break;
        case 'UPDATED_FUND_RELEASE':
            message = `${UserFullName(activityLog.activityBy)} updated fund release to ${activityLog.updatedCost} INR`;
            break;
        case 'UPDATED_FUND_UTILIZATION':
            message = `${UserFullName(activityLog.activityBy)} updated fund utilization to ${activityLog.updatedCost} INR`;
            break;
        case 'UPDATED_CITIIS_GRANTS':
            message = `${UserFullName(activityLog.activityBy)} updated citiis grants to ${activityLog.updatedCost} INR`;
            break;
        case 'UPDATED_PROJECT_COST':
            message = `${UserFullName(activityLog.activityBy)} updated project cost to ${activityLog.updatedCost} INR`;
            break;
        case 'REPLACE_USER':
            message = "";
            break;
        default:
            message = "";
    }
    return { message, activityBy: activityLog.activityBy._id, createdAt: activityLog.createdAt, activityType: "NEW_RESPONSE" };
}
function getFormantedUserLogs(activityLog) {
    let message;
    switch (activityLog.activityType) {
        case 'INVITE-USER':
            message = `${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} sent Invitation to ${activityLog.profileId.email} .`;
            break;
        case 'REGISTER-USER':
            message = `${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} has been Registered on CMP .`;
            break;
        case 'EDIT-PROFILE':
            message = `${activityLog.profileId.firstName} ${activityLog.profileId.lastName} edited their profile for ${activityLog.editedFields.length > 0 ? (activityLog.editedFields.slice(0, activityLog.editedFields.length)) : 'No'} ${activityLog.editedFields.length > 1 ? 'fields.' : 'field.'}`;
            break;
        case 'EDIT-PROFILE-BY-ADMIN':
            message = `${activityLog.profileId.firstName} ${activityLog.profileId.lastName}'s profile has been edited by ${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} for ${activityLog.editedFields.length > 0 ? (activityLog.editedFields) : 'No'} ${activityLog.editedFields.length > 1 ? 'fields.' : 'field.'}`;
            break;
        case 'ACTIVATE-PROFILE':
            message = `${activityLog.profileId.firstName} ${activityLog.profileId.lastName}'s profile has been activated by ${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} .`;
            break;
        case 'DEACTIVATE-PROFILE':
            message = `${activityLog.profileId.firstName} ${activityLog.profileId.lastName}'s profile has been deactivated by ${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} .`;
            break;
        case 'RESEND-INVITE-USER':
            message = `${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} has resent the invitation to ${activityLog.profileId.email} .`;
            break;
        case 'EDIT-ROLE':
            message = `${activityLog.profileId.firstName} ${activityLog.profileId.lastName}'s role has been edited by ${activityLog.activityBy.firstName} ${activityLog.activityBy.lastName} .`;
            break;
        default:
            message = "";
    }
    return { message, activityBy: activityLog.activityBy._id, createdAt: activityLog.createdAt, activityType: "NEW_RESPONSE" };
}
