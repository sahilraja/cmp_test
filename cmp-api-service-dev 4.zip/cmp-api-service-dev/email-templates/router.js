"use strict";
const express_1 = require("express");
const utils_1 = require("../utils/utils");
const module_1 = require("./module");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const router = express_1.Router();
router.post(`/getTemplateBySubstitution`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getTemplateBySubstitutions(req.body.templateId, req.body));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.templateCreate(req.body));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Template already exists`;
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get(`/list`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.post("/edit/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.templateEdit(res.locals.user, req.body, req.params.id));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = `Template already exists`;
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/delete/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.templateDelete(req.body, req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.get("/getTemplate/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.templateGet(res.locals.user, req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
router.post("/testTemplate/:id", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.testTemplate(req.params.id, req.body.email));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
module.exports = router;
