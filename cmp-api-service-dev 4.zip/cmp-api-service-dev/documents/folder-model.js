"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    name: { type: String, trim: true },
    doc_id: [{ type: mongoose_1.Schema.Types.ObjectId, ref: 'documents' }],
    parentId: { type: String },
    ownerId: { type: String },
}, { timestamps: true });
schema.index({ ownerId: 1 });
schema.index({ ownerId: 1, parentId: 1 });
exports.folders = mongoose_1.model("folders", schema);
