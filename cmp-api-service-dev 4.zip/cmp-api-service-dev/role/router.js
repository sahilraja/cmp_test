"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const utils_1 = require("../utils/utils");
const custom_error_1 = require("../utils/custom-error");
const router = express_1.Router();
//  list roles
router.get('/list', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.role_list());
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
//  list roles
router.get('/scope/list/:userid', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.userRoleAndScope(req.params.userid));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.get("/user/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.usersForRole(req.query.role));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
});
router.get('/capabilities/list', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.capabilities_list());
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.get('/all/capabilities/list', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.allrolecapabilities());
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.post('/capability/add', utils_1.authenticate, async (req, res, next) => {
    try {
        let scope = 'global';
        res.status(200).send(await module_1.addCapability(req.body.role, scope, req.body.capability, res.locals.user._id, req.query.auth));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message, 409));
    }
    ;
});
router.post('/capability/add/no-auth', async (req, res, next) => {
    try {
        let scope = 'global';
        res.status(200).send(await module_1.addCapability(req.body.role, scope, req.body.capability, "", false));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message, 409));
    }
    ;
});
router.put('/capability/remove', utils_1.authenticate, async (req, res, next) => {
    try {
        let scope = 'global';
        res.status(200).send(await module_1.removeCapability(req.body.role, scope, req.body.capability, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message, 409));
    }
    ;
});
router.put('/:role/edit', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.updaterole(req.params.role, req.body, res.locals.user._id));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.post('/addRoles', async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addRolesFromJSON());
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.post('/add', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addRole(res.locals.user._id, req.body));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.post('/add/roleCapabilities', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addRoleCapabilitiesFromJSON(res.locals.user._id));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
module.exports = router;
