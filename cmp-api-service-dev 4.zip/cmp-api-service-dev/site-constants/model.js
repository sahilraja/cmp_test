"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    key: { type: String },
    value: { type: String },
    groupName: { type: String },
    type: { type: String, default: "string" },
    displayName: { type: String }
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.constantSchema = mongoose_1.model("constant", schema);
