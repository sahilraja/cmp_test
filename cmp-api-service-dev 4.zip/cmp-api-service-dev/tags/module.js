"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tag_model_1 = require("./tag_model");
const model_1 = require("../documents/model");
const module_1 = require("../documents/module");
const MESSAGE_URL = process.env.MESSAGE_URL || "http://localhost:4001";
const TASK_URL = process.env.TASK_HOST || "http://localhost:5052";
const role_management_1 = require("../utils/role_management");
const module_2 = require("../role/module");
const request = require("request-promise");
const custom_error_1 = require("../utils/custom-error");
const module_3 = require("../log/module");
const mongoose_1 = require("mongoose");
//  get list of tags
async function tag_list(search) {
    try {
        let success = await tag_model_1.tags.find({ tag: new RegExp(search, "i"), is_active: true, deleted: false });
        return { status: true, data: success };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.tag_list = tag_list;
//  get list of tags
async function mergeTags(body, token, userId) {
    try {
        let userRoles = await module_2.userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_1.checkRoleScope(userRole, "merge-tag");
        if (!isEligible) {
            throw new custom_error_1.APIError("Unauhorized Action", 403);
        }
        let mergeTagId;
        if (!body.tags || !body.mergeTag)
            throw new Error("All Mandatory Fields Required");
        let mergeTag = await tag_model_1.tags.find({ tag: body.mergeTag, is_active: true, deleted: false });
        if (mergeTag.length) {
            mergeTagId = mergeTag[0]._id;
        }
        else {
            let mergeTag = await tag_model_1.tags.create({ tag: body.mergeTag, is_active: true });
            mergeTagId = mergeTag._id;
        }
        let tagData = (await tag_model_1.tags.find({ _id: { $in: body.tags } })).map(({ tag }) => tag);
        let docData = await model_1.documents.find({ tags: { "$in": body.tags } });
        let docIds = docData.map((doc) => { return doc._id; });
        let updateDocs = await model_1.documents.update({ _id: { "$in": docIds } }, {
            $pull: { tags: { $in: body.tags } }
        }, { multi: true });
        let updateDocsWithMergeTag = await model_1.documents.update({ _id: { "$in": docIds } }, {
            $addToSet: { tags: mergeTagId }
        }, { multi: true });
        let bodyObj = {
            tags: body.tags,
            mergeTag: mergeTagId
        };
        let messageMergeTags = await mergeMessageTags(bodyObj, token);
        let taskMergeTags = await mergeTaskTags(bodyObj, token);
        let removeTagIds = body.tags.filter((tag) => tag != mergeTagId);
        let removeTags = await tag_model_1.tags.remove({ _id: { "$in": removeTagIds } });
        //   $set: { deleted: true }
        // },
        //   { multi: true });
        let val = await Promise.all(docIds.map(async (docId) => {
            let doc = await model_1.documents.findById(docId);
            let tags = await module_1.getTags((doc.tags && doc.tags.length) ? doc.tags.filter((tag) => mongoose_1.Types.ObjectId.isValid(tag)) : []);
            return {
                docId: JSON.parse(JSON.stringify(docId)),
                tags: tags.map((tagData) => { return tagData.tag; })
            };
        }));
        let updateTagsInElasticSearch = await module_1.updateTagsInDOcs(val, userId);
        await module_3.create({ activityType: "MERGED-TAG", activityBy: userId, mergedTag: body.mergeTag, tagsToMerge: tagData });
        return {
            status: true,
            Message: "Tags Merged Successfully",
            mergeTagId
        };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.mergeTags = mergeTags;
async function mergeMessageTags(body, token) {
    try {
        let Options = {
            uri: `${MESSAGE_URL}/v1/merge/tags`,
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function updateUserInMessages(body, token) {
    try {
        let Options = {
            uri: `${MESSAGE_URL}/v1/update/userMessages`,
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.updateUserInMessages = updateUserInMessages;
;
async function mergeTaskTags(body, token) {
    try {
        let Options = {
            uri: `${TASK_URL}/tag/merge`,
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function updateUserInTasks(body, token) {
    try {
        let Options = {
            uri: `${TASK_URL}/update/user`,
            method: "POST",
            headers: { Authorization: `Bearer ${token}` },
            body: body,
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.updateUserInTasks = updateUserInTasks;
;
