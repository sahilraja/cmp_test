"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoose_transform_1 = require("mongoose-transform");
const SchemaDef = new mongoose_1.Schema({
    opportunityNumber: { type: Number },
    opportunityTrend: { type: Number },
    dateRaised: { type: Date },
    projectId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'project' },
    opportunityFamily: { type: String, trim: true },
    description: { type: String, trim: true },
    phase: { type: mongoose_1.Schema.Types.ObjectId, ref: 'phase' },
    impact: { type: Number, default: 0 },
    probability: { type: Number, default: 0 },
    actions: { type: String, trim: true },
    comments: { type: String, trim: true },
    opportunityProvision: { type: Number, default: 0 },
    opportunityOwner: { type: String },
    status: { type: String },
    parentId: { type: mongoose_1.Types.ObjectId, ref: "opportunities", default: null },
    previousTrend: { type: Number, default: 0 },
    deleted: { type: Boolean, default: false },
    createdBy: { type: String }
}, { timestamps: true });
SchemaDef.plugin(mongoose_transform_1.default);
exports.OpportunitySchema = mongoose_1.model('opportunities', SchemaDef);
