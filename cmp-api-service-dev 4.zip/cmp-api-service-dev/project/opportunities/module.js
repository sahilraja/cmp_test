"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const custom_error_1 = require("../../utils/custom-error");
const error_msg_1 = require("../../utils/error_msg");
const users_1 = require("../../utils/users");
const role_management_1 = require("../../utils/role_management");
const utils_1 = require("../../utils/utils");
async function create(payload, projectId, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.OPPORTUNITY.UNAUTHORIZED_ACCESS);
    }
    return await model_1.OpportunitySchema.create(Object.assign({}, payload, { projectId, createdBy: userObj._id }));
}
exports.create = create;
async function list(projectId) {
    let details = await model_1.OpportunitySchema.find({ deleted: false, projectId, parentId: null }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
    return details.map((obj) => { return Object.assign({}, obj.toJSON(), { age: utils_1.dateDifference(obj.createdAt) }); });
}
exports.list = list;
async function detail(id) {
    const detail = await model_1.OpportunitySchema.findById(id).populate({ path: 'phase' }).exec();
    const { opportunityOwner } = detail.toJSON();
    if (opportunityOwner) {
        return Object.assign({}, detail.toJSON(), { opportunityOwner: await users_1.userFindOne('_id', opportunityOwner), age: utils_1.dateDifference(detail.createdAt) });
    }
    return detail;
}
exports.detail = detail;
async function edit(id, updates, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.OPPORTUNITY.UNAUTHORIZED_ACCESS);
    }
    const oldObject = await model_1.OpportunitySchema.findById(id).exec();
    if (Object.keys(updates).includes('impact')) {
        if (oldObject.impact != updates.impact) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    if (Object.keys(updates).includes('probability')) {
        if (oldObject.probability != updates.probability) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    return await model_1.OpportunitySchema.findByIdAndUpdate(id, { $set: updates }).exec();
}
exports.edit = edit;
async function opportunitySaveAll(projectId, updateObjs, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
        if (!isEligible)
            throw new custom_error_1.APIError(error_msg_1.OPPORTUNITY.UNAUTHORIZED_ACCESS);
        await Promise.all(updateObjs.map((opportunityObj) => saveaAllOpportunities(opportunityObj, projectId, userObj)));
        return { message: "Saved successfully" };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.opportunitySaveAll = opportunitySaveAll;
;
async function saveaAllOpportunities(opportunityObj, projectId, userObj) {
    try {
        if ("_id" in opportunityObj || "id" in opportunityObj) {
            const oldObject = await model_1.OpportunitySchema.findById(opportunityObj._id || opportunityObj.id).exec();
            if (Object.keys(opportunityObj).some(key => opportunityObj[key] != oldObject[key])) {
                if (!opportunityObj.opportunityTrend && opportunityObj.opportunityTrend != 0) {
                    opportunityObj.opportunityTrend = 0;
                }
                else {
                    let lastUpdatedObj = (await model_1.OpportunitySchema.find({ parentId: opportunityObj._id || opportunityObj.id })).pop();
                    opportunityObj.opportunityTrend = Math.abs((lastUpdatedObj.impact || 0) * (lastUpdatedObj.probability || 0) - (opportunityObj.impact || 0) * (opportunityObj.probability || 0));
                }
                if (Object.keys(opportunityObj).includes('impact'))
                    if (oldObject.impact != opportunityObj.impact)
                        opportunityObj['previousTrend'] = oldObject.impact * oldObject.probability;
                if (Object.keys(opportunityObj).includes('probability'))
                    if (oldObject.probability != opportunityObj.probability)
                        opportunityObj['previousTrend'] = oldObject.impact * oldObject.probability;
                let opportunityDetails = await model_1.OpportunitySchema.findByIdAndUpdate(opportunityObj._id || opportunityObj.id, { $set: opportunityObj }, { new: true }).exec();
                await model_1.OpportunitySchema.create(Object.assign({}, opportunityDetails.toJSON(), { projectId, parentId: opportunityDetails._id }));
            }
            ;
        }
        else {
            let opportunity = await model_1.OpportunitySchema.create(Object.assign({}, opportunityObj, { projectId, createdBy: userObj._id }));
            await model_1.OpportunitySchema.create(Object.assign({}, opportunityObj, { parentId: opportunity._id, projectId, createdBy: userObj._id }));
        }
        return true;
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function logList(projectId, opportunityId) {
    return await model_1.OpportunitySchema.find({ deleted: false, projectId, parentId: opportunityId }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
}
exports.logList = logList;
