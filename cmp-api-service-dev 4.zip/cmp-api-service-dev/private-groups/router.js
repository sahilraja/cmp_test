"use strict";
const express_1 = require("express");
const utils_1 = require("../utils/utils");
const custom_error_1 = require("../utils/custom-error");
const mongoose_1 = require("mongoose");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const error_msg_1 = require("../utils/error_msg");
const router = express_1.Router();
//  Group Id Validation
router.param("id", async (req, res, next, value) => {
    const groupId = req.params.id;
    try {
        if (!mongoose_1.Types.ObjectId.isValid(groupId))
            throw new Error(error_msg_1.PRIVATE_MEMBER.INVALID);
        next();
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
//  Create Private Group 
router.post("/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createPrivateGroup(req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000) {
            err.message = error_msg_1.PRIVATE_MEMBER.CREATE.GROUP_NAME_EXIST;
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Edit Private Group Details
router.post("/:id/edit", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editPrivateGroup(req.params.id, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Remove Private Group Details
router.post("/:id/member/remove", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.removePrivateGroup(req.params.id, req.body, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Change Status of the Private Group
router.put("/:id/status", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.privateGroupStatus(req.params.id, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get List Private Group Deatils
router.get("/list", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.privateGroupList(res.locals.user._id, req.query.search));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Get Private Group Details
router.get("/:id/details", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.privateGroupDetails(req.params.id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
module.exports = router;
