"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("../site-constants/model");
var nodemailer = require('nodemailer');
var smtpTransport = require('nodemailer-smtp-transport');
// const EMAIL = process.env.EMAIL || "cmp@niua.org";
// const PASSWORD = process.env.PASSWORD || "hahahaha"
// const EMAIL = process.env.EMAIL || `testmailm588@gmail.com`;
// const PASSWORD = process.env.PASSWORD || 'Hello@123';
const EMAIL = process.env.EMAIL || `tcmpemail@gmail.com`;
const PASSWORD = process.env.PASSWORD || 'Hello@12';
// let transport = process.env.EMAIL ? smtpTransport({
//   host: 'smtp.rediffmailpro.com',
//   port: '587',
//   auth: {
//     user: EMAIL,
//     pass: PASSWORD
//   }
// }) : {
//     service: 'gmail',
//     auth: {
//       user: EMAIL,
//       pass: PASSWORD
//     }
//   }
async function nodemail(objBody) {
    try {
        let constants = await model_1.constantSchema.findOne({ key: 'bcc' }).exec();
        let transporter = nodemailer.createTransport(smtpTransport({
            // Uat
            // host: 'smtp.rediffmailpro.com',
            // port: '465',
            // secure: true,
            // Dev
            host: 'smtp.gmail.com',
            port: '587',
            auth: {
                user: EMAIL,
                pass: PASSWORD
            }
        }));
        var mailOptions = {
            from: EMAIL,
            to: objBody.email,
            bcc: constants.value || "",
            subject: objBody.subject,
            html: objBody.html
        };
        transporter.sendMail(mailOptions, function (error, info) {
            if (error) {
                console.error(error);
            }
            else {
                console.log('Email sent: ' + info.response);
            }
        });
        transporter.close();
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.nodemail = nodemail;
