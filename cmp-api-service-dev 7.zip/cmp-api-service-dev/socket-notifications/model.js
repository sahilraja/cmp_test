"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
var NotificationType;
(function (NotificationType) {
    NotificationType[NotificationType["DOCUMENT"] = 0] = "DOCUMENT";
    NotificationType[NotificationType["TASK"] = 1] = "TASK";
    NotificationType[NotificationType["MESSAGE"] = 2] = "MESSAGE";
    NotificationType[NotificationType["PROJECT"] = 3] = "PROJECT";
})(NotificationType = exports.NotificationType || (exports.NotificationType = {}));
const schemaDef = new mongoose_1.Schema({
    from: { type: String },
    title: { type: String },
    notificationType: { type: String, required: true },
    userId: { type: String, required: true },
    docId: { type: mongoose_1.Types.ObjectId, ref: 'documents' },
    taskId: { type: String, default: null },
    groupId: { type: String, default: null },
    messageId: { type: String, default: null },
    read: { type: Boolean, default: false }
}, { timestamps: true });
schemaDef.plugin(mongoosePaginate);
exports.SocketNotifications = mongoose_1.model(`web_notifiations`, schemaDef);
