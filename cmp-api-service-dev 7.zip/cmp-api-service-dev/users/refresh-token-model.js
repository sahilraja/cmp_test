"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const SchemaDef = new mongoose_1.Schema({
    userId: { type: String },
    access_token: { type: String },
    lastUsedAt: { type: Date, default: new Date() }
}, { timestamps: true });
exports.RefreshTokenSchema = mongoose_1.model('refresh_tokens', SchemaDef);
