"use strict";
const express_1 = require("express");
const custom_error_1 = require("../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("../steps/module");
const router = express_1.Router();
router.get(`/step-info`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.stepDetail(req.params.stepId));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-all-steps`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
