"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let SchemaDef = new mongoose_1.Schema({
    state: { type: String },
    cities: { type: [String] }
});
exports.CitySchema = mongoose_1.model('cities', SchemaDef);
