"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const custom_error_1 = require("../utils/custom-error");
const router = express_1.Router();
router.post(`/create`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createPhase(req.body, res.locals.user));
    }
    catch (error) {
        if (error.code == 11000) {
            error.message = `Phase already exists`;
        }
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/getPhase/:id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getPhase(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put('/edit/:id', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editPhase(req.params.id, req.body, res.locals.user, req.token));
    }
    catch (error) {
        if (error.code == 11000) {
            error.message = `Phase already exists`;
        }
        next(new custom_error_1.APIError(error.message));
    }
});
router.post(`/deletePhase/:id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.deletePhase(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.listPhase());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/userPhase/list/:id`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.userListPhase(req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
