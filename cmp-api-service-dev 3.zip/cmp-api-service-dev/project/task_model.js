"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const project_model_1 = require("./project_model");
const schema = new mongoose_1.Schema({
    name: { type: String, trim: true },
    startDate: { type: Date, default: new Date() },
    endDate: { type: Date },
    access: { type: Array },
    file: { type: String },
    fileName: { type: String },
    projectId: { type: mongoose_1.Types.ObjectId, ref: project_model_1.project },
    is_active: { type: Boolean, default: true }
}, { timestamps: true });
exports.taskModel = mongoose_1.model("task", schema);
