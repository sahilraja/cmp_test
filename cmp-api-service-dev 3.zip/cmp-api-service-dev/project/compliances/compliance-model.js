"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const SchemaDef = new mongoose_1.Schema({
    projectId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'project' },
    complianceType: { type: String },
    documentNeeded: { type: Boolean, default: false },
    complaint: { type: Boolean, default: false },
    taskId: { type: String },
    name: { type: String, trim: true },
    document: { type: String },
    createdBy: { type: String }
}, { timestamps: true });
SchemaDef.index({ projectId: 1 });
exports.ComplianceSchema = mongoose_1.model('compliances', SchemaDef);
