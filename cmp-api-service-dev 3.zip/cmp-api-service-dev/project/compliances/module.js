"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const compliance_model_1 = require("./compliance-model");
const role_management_1 = require("../../utils/role_management");
const custom_error_1 = require("../../utils/custom-error");
const error_msg_1 = require("../../utils/error_msg");
const urls_1 = require("../../utils/urls");
const project_model_1 = require("../project_model");
async function createCompliance(payload, projectId, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, 'manage-compliance');
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.COMPLIANCES.UNAUTHORIZED_TO_CREATE);
    }
    if (!payload.taskId) {
        throw new custom_error_1.APIError(error_msg_1.COMPLIANCES.REQUIRED_TASK);
    }
    return await compliance_model_1.ComplianceSchema.create(Object.assign({}, payload, { projectId, createdBy: userObj._id }));
}
exports.createCompliance = createCompliance;
async function listCompliances(userToken, projectId) {
    const compliances = await compliance_model_1.ComplianceSchema.find({ projectId }).exec();
    const projectDetails = await project_model_1.project.findById(projectId).select({ miscomplianceSpv: 1, miscomplianceProject: 1 });
    const taskIds = compliances.map((compliance) => compliance.taskId).filter(v => !!v);
    const tasks = await role_management_1.httpRequest({
        url: `${urls_1.TASKS_URL}/task/getTasksDocs`,
        method: 'POST',
        body: { taskIds },
        headers: { 'Authorization': `Bearer ${userToken}` },
        json: true
    });
    const filteredTasks = tasks.filter((task) => task.status != 8);
    let complianceData = compliances.map((compliance) => {
        return Object.assign({}, compliance.toJSON(), { task: filteredTasks.find((task) => task._id == compliance.taskId), taskStatus: tasks.find((task) => task._id == compliance.taskId).status });
    }).filter(compliance => compliance.task);
    let spvCompliance = complianceData.filter(({ complianceType }) => complianceType == "SPV");
    let projectCompliance = complianceData.filter(({ complianceType }) => complianceType == "PROJECT");
    return {
        spvPercentage: spvCompliance ? Math.floor(((spvCompliance.filter(({ taskStatus }) => taskStatus == 4 || taskStatus == 5)).length / spvCompliance.length) * 100) : 0,
        projectPercentage: projectCompliance ? Math.floor(((projectCompliance.filter(({ taskStatus }) => taskStatus == 4 || taskStatus == 5)).length / projectCompliance.length) * 100) : 0,
        spvCompliance, projectCompliance,
        miscompliance: projectDetails
    };
}
exports.listCompliances = listCompliances;
async function editCompliance(id, updates, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, 'manage-compliance');
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.COMPLIANCES.UNAUTHORIZED_TO_EDIT);
    }
    if (Object.keys(updates).includes('taskId') && !updates.taskId) {
        throw new custom_error_1.APIError(error_msg_1.COMPLIANCES.REQUIRED_TASK);
    }
    // Need to handle task case
    return await compliance_model_1.ComplianceSchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
}
exports.editCompliance = editCompliance;
