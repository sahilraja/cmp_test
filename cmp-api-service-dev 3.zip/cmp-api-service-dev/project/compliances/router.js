"use strict";
const express_1 = require("express");
const custom_error_1 = require("../../utils/custom-error");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const router = express_1.Router();
router.post(`/:id/compliance/create`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.createCompliance(req.body, req.params.id, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/:id/compliance/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.listCompliances(req.token, req.params.id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.put(`/:id/compliance/:compliance_id/edit`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.editCompliance(req.params.compliance_id, req.body, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
