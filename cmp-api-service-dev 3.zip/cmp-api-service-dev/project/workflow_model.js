"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const task_model_1 = require("./task_model");
const schema = new mongoose_1.Schema({
    type: { type: String, trim: true },
    role: { type: String, trim: true },
    user: { type: String },
    status: { type: String, enum: ["PENDING", "REJECT", "APPROVE"] },
    taskId: { type: mongoose_1.Types.ObjectId, ref: task_model_1.taskModel },
    is_active: { type: Boolean, default: true }
}, { timestamps: true });
exports.workflowModel = mongoose_1.model("workflow", schema);
