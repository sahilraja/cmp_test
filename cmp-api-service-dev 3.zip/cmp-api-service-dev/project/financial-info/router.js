"use strict";
const express_1 = require("express");
const utils_1 = require("../../utils/utils");
const http_status_codes_1 = require("http-status-codes");
const custom_error_1 = require("../../utils/custom-error");
const module_1 = require("./module");
const router = express_1.Router();
//  Create financial-info
router.post("/:id/financial-info/instalment/create", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.financialInfoCreate(req.body, req.params.id, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000 || err.name == "ValidationError") {
            err.message = "A Phase with same name already exists.";
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Edit financial-info
router.post("/:id/financial-info/:financialId/instalment/edit", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id: projectId, financialId } = req.params;
        res.status(http_status_codes_1.OK).send(await module_1.financialInfoEdit(projectId, financialId, req.body, res.locals.user));
    }
    catch (err) {
        if (err.code == 11000 || err.name == "ValidationError") {
            err.message = "A Phase with same name already exists.";
        }
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  list financial-info
router.get("/:id/financial-info/instalment/list", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id: projectId } = req.params;
        res.status(http_status_codes_1.OK).send(await module_1.financialInfoList(projectId, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Delete financial-info
router.get("/:id/financial-info/:financialId/instalment/details", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id: projectId, financialId } = req.params;
        res.status(http_status_codes_1.OK).send(await module_1.financialInfoDetails(projectId, financialId, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
//  Delete financial-info
router.post("/:id/financial-info/:financialId/instalment/delete", utils_1.authenticate, async (req, res, next) => {
    try {
        const { id: projectId, financialId } = req.params;
        res.status(http_status_codes_1.OK).send(await module_1.financialInfoDelete(projectId, financialId, res.locals.user));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
    ;
});
module.exports = router;
