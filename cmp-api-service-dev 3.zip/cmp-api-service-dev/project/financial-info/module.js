"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const error_msg_1 = require("../../utils/error_msg");
;
//  create financial-Info
async function financialInfoCreate(body, projectId, userObj) {
    try {
        // const isEligible = await checkRoleScope(userObj.role, "financial-info-management");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        if (!body.percentage || !body.phase || body.phase.trim() == "")
            throw new Error(error_msg_1.FINANCIAL_INFO.MANDATORY);
        let existPhase = await model_1.financialSchema.find({ projectId: projectId, phase: body.phase, isDeleted: false });
        if (existPhase.length)
            throw new Error(error_msg_1.FINANCIAL_INFO.PHASE_EXIST);
        return model_1.financialSchema.create(Object.assign({}, body, { projectId, createdBy: userObj._id }));
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.financialInfoCreate = financialInfoCreate;
;
//  edit financial-Info
async function financialInfoEdit(projectId, financialId, body, userObj) {
    try {
        // const isEligible = await checkRoleScope(userObj.role, "financial-info-management");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        let existPhase = await model_1.financialSchema.findOne({ projectId, phase: body.phase, isDeleted: false });
        if (existPhase && existPhase._id != financialId)
            throw new Error(error_msg_1.FINANCIAL_INFO.PHASE_EXIST);
        return await model_1.financialSchema.findByIdAndUpdate(financialId, { $set: Object.assign({}, body) }, { new: true });
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.financialInfoEdit = financialInfoEdit;
;
//  delete financial-Info 
async function financialInfoDelete(projectId, financialId, userObj) {
    try {
        // const isEligible = await checkRoleScope(userObj.role, "financial-info-management");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        let PhaseDetails = await model_1.financialSchema.findById(financialId).exec();
        if (!PhaseDetails)
            throw new Error(error_msg_1.FINANCIAL_INFO.PHASE_NOT_FOUND);
        let data = await model_1.financialSchema.findByIdAndUpdate(financialId, { $set: { isDeleted: PhaseDetails.isDeleted ? false : true } }, { new: true });
        return { message: data.isDeleted ? error_msg_1.RESPONSE.INACTIVE : error_msg_1.RESPONSE.ACTIVE };
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.financialInfoDelete = financialInfoDelete;
;
//  delete financial-Info 
async function financialInfoDetails(projectId, financialId, userObj) {
    try {
        // const isEligible = await checkRoleScope(userObj.role, "financial-info-management");
        // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        return await model_1.financialSchema.findById(financialId).populate("projectId").exec();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.financialInfoDetails = financialInfoDetails;
;
//  list financial-Info
async function financialInfoList(projectId, userObj, validation = true, search) {
    try {
        if (validation) {
            // const isEligible = await checkRoleScope(userObj.role, "financial-info-management");
            // if (!isEligible) throw new APIError("Unauthorized Action.", 403);
        }
        let searchQuery = search ? { name: new RegExp(search, "i"), isDeleted: false, projectId } : { projectId, isDeleted: false };
        return await model_1.financialSchema.find(Object.assign({}, searchQuery)).exec();
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.financialInfoList = financialInfoList;
;
