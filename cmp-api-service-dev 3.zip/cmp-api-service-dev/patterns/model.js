"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePagination = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    patternCode: { type: String, trim: true, required: true },
    patternName: { type: String, trim: true, required: true },
    createdBy: { type: String, required: true },
    isDeleted: { type: Boolean, default: false }
}, { timestamps: true });
schema.index({ patternCode: 1, isDeleted: 1 });
schema.plugin(mongoosePagination);
exports.patternSchema = mongoose_1.model("patterns", schema);
