"use strict";
var __rest = (this && this.__rest) || function (s, e) {
    var t = {};
    for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p) && e.indexOf(p) < 0)
        t[p] = s[p];
    if (s != null && typeof Object.getOwnPropertySymbols === "function")
        for (var i = 0, p = Object.getOwnPropertySymbols(s); i < p.length; i++) if (e.indexOf(p[i]) < 0)
            t[p[i]] = s[p[i]];
    return t;
};
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
const utils_1 = require("../utils/utils");
const module_1 = require("../users/module");
const module_2 = require("../log/module");
async function create(payload, projectId, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
    }
    let risk = await model_1.RiskSchema.create(Object.assign({}, payload, { projectId, createdBy: userObj._id }));
    await model_1.RiskSchema.create(Object.assign({}, payload, { parentId: risk._id, projectId, createdBy: userObj._id }));
    return risk;
}
exports.create = create;
async function list(projectId) {
    let details = await model_1.RiskSchema.find({ deleted: false, projectId, parentId: null }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
    return details.map((riskObj) => { return Object.assign({}, riskObj.toJSON(), { age: utils_1.dateDifference(riskObj.createdAt) }); });
}
exports.list = list;
async function detail(riskId) {
    const detail = await model_1.RiskSchema.findById(riskId).populate({ path: 'phase' }).exec();
    const { riskOwner } = detail.toJSON();
    if (riskOwner) {
        return Object.assign({}, detail.toJSON(), { riskOwner: (await module_1.userFindManyWithRole(riskOwner) || [{}]).pop(), age: utils_1.dateDifference(detail.createdAt) });
    }
    return detail;
}
exports.detail = detail;
async function edit(id, updates, userObj) {
    const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
    }
    const oldObject = await model_1.RiskSchema.findById(id).exec();
    if (Object.keys(updates).includes('impact')) {
        if (oldObject.impact != updates.impact) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    if (Object.keys(updates).includes('probability')) {
        if (oldObject.probability != updates.probability) {
            updates['previousTrend'] = oldObject.impact * oldObject.probability;
        }
    }
    let riskDetails = await model_1.RiskSchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
    await model_1.RiskSchema.create(Object.assign({}, riskDetails, { parentId: riskDetails._id }));
    return riskDetails;
}
exports.edit = edit;
async function riskSaveAll(projectId, updateObjs, userObj) {
    try {
        const isEligible = await role_management_1.checkRoleScope(userObj.role, `manage-risk-opportunity`);
        if (!isEligible) {
            throw new custom_error_1.APIError(error_msg_1.RISK.UNAUTHORIZED_ACCESS);
        }
        let response = await Promise.all(updateObjs.map((riskObj) => saveaAll(riskObj, projectId, userObj)));
        return response[0];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.riskSaveAll = riskSaveAll;
;
async function saveaAll(riskObj, projectId, userObj) {
    try {
        let message = `Saved successfully`;
        if ("_id" in riskObj || "id" in riskObj) {
            const { riskCriticality, phase, riskPrevTrend, showDeleteIcon, showHistoryIcon, dateRaised } = riskObj, others = __rest(riskObj, ["riskCriticality", "phase", "riskPrevTrend", "showDeleteIcon", "showHistoryIcon", "dateRaised"]);
            const oldObject = await model_1.RiskSchema.findById(riskObj._id || riskObj.id).exec();
            if (Object.keys(others).some(key => others[key] != oldObject[key]) ||
                phase.some((_phase) => !(oldObject.phase || []).map((p) => p.toString()).includes(_phase))) {
                if (!riskObj.riskTrend && riskObj.riskTrend != 0) {
                    riskObj.riskTrend = 0;
                }
                else {
                    let lastUpdatedObj = (await model_1.RiskSchema.find({ parentId: riskObj._id || riskObj.id })).pop();
                    // riskObj.riskTrend = (riskObj.impact || 0) * (riskObj.probability || 0) - (lastUpdatedObj.impact || 0) * (lastUpdatedObj.probability || 0)
                    riskObj.riskTrend = (((riskObj.impact || 0) != (lastUpdatedObj.impact || 0)) || ((riskObj.probability || 0) != (lastUpdatedObj.probability || 0))) ?
                        ((riskObj.impact || 0) * (riskObj.probability || 0) - (lastUpdatedObj.impact || 0) * (lastUpdatedObj.probability || 0)) : riskObj.riskTrend;
                }
                if (Object.keys(riskObj).includes('impact'))
                    if (oldObject.impact != riskObj.impact)
                        riskObj['previousTrend'] = oldObject.impact * oldObject.probability;
                if (Object.keys(riskObj).includes('probability'))
                    if (oldObject.probability != riskObj.probability)
                        riskObj['previousTrend'] = oldObject.impact * oldObject.probability;
                let riskDetails = await model_1.RiskSchema.findByIdAndUpdate(riskObj._id || riskObj.id, { $set: riskObj }, { new: true }).exec();
                module_2.create({ projectId, riskOpportunityNumber: riskDetails.riskNumber, activityBy: userObj._id, activityType: error_msg_1.ACTIVITY_LOG.RISK_UPDATED, opportunityId: riskDetails._id });
                const _a = riskDetails.toJSON(), { createdAt, updatedAt } = _a, others = __rest(_a, ["createdAt", "updatedAt"]);
                await model_1.RiskSchema.create(Object.assign({}, others, { projectId, parentId: riskDetails._id, updatedAt: new Date() }));
            }
            ;
            message = `Risk(s) updated successfully`;
        }
        else {
            let risk = await model_1.RiskSchema.create(Object.assign({}, riskObj, { projectId, createdBy: userObj._id }));
            module_2.create({ projectId, riskOpportunityNumber: risk.riskNumber, activityBy: userObj._id, activityType: error_msg_1.ACTIVITY_LOG.RISK_CREATED, riskId: risk._id });
            await model_1.RiskSchema.create(Object.assign({}, riskObj, { parentId: risk._id, projectId, createdBy: userObj._id }));
            message = `Risk(s) added successfully`;
        }
        return { message };
    }
    catch (err) {
        throw err;
    }
    ;
}
;
async function logList(projectId, riskId) {
    let list = await model_1.RiskSchema.find({ deleted: false, projectId, parentId: riskId }).populate({ path: 'phase' }).sort({ createdAt: 1 }).exec();
    return list;
}
exports.logList = logList;
