"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.configLimit = {
    name: 30,
    description: 100
};
