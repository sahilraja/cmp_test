"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const fs = require("fs");
const path_1 = require("path");
const request = require("request-promise");
const rbac_1 = require("./rbac");
const urls_1 = require("./urls");
const users_1 = require("./users");
const model_1 = require("../site-constants/model");
const model_2 = require("../notifications/model");
const module_1 = require("../role/module");
const model_3 = require("../email-templates/model");
const fs_1 = require("fs");
const custom_error_1 = require("./custom-error");
const model_4 = require("../sms/model");
const model_5 = require("../role/model");
async function init() {
    let removeOptions = {
        url: `${urls_1.RBAC_URL}/capabilities/remove/all`,
        method: "PUT",
        json: true
    };
    let removeCapabilities = await request(removeOptions);
    if (!removeCapabilities.status) {
        throw "Something Went wrong while removeing the capabilities.";
    }
    // let findOptions = {
    //   url: `${RBAC_URL}/capabilities/list`,
    //   method: "GET",
    //   json: true
    // };
    // let findCapabilities: any = await request(findOptions);
    // if (!findCapabilities.status) {
    //   throw "Something Went wrong while listing the capabilities.";
    // } else if (findCapabilities.status && findCapabilities.data.length) {
    //   throw findCapabilities.data.length + " capabilities exist in users";
    //   console.log(findCapabilities.data.length);
    // } else {
    let roles = JSON.parse(fs.readFileSync(path_1.join(__dirname, "rbac.json"), "utf8"));
    const capabilities = roles.reduce((capabilities, role) => {
        return capabilities.concat(role.capabilities.map((capability) => {
            return Object.assign({}, capability, { role: role.role });
        }));
    }, []);
    let addOptions = {
        url: `${urls_1.RBAC_URL}/capabilities/add/all`,
        method: "POST",
        headers: {
            "Content-Type": "application/json"
        },
        body: {
            capabilities
        },
        json: true
    };
    let addCapabilities = await request(addOptions);
    if (!addCapabilities.status) {
        throw "Something Went wrong while adding the capabilities.";
    }
    console.log("Added capabilities from rbac.json");
}
exports.init = init;
async function userInit() {
    let existingUserCount = await users_1.userList({});
    if (!existingUserCount.length) {
        let user = await users_1.createUser({
            "emailVerified": true,
            "phoneVerified": false,
            "firstName": "pranay",
            "lastName": `bhardwaj`,
            "email": "pranay@citiis.com",
            "aboutme": "Technology lead for CITIIS Project",
            "password": "Citiis@123",
            "phone": "7989238348",
            "countryCode": "+91",
            "is_active": true
        });
        let grants = await rbac_1.addRole(user._id, "technology-lead");
        module_1.addCapability("technology-lead", 'global', "display-role-management", user._id, false);
        console.log("No existing users found. Technology specialist user created successfully");
    }
    else {
        console.log(`${existingUserCount.length} existing users found in DB`);
    }
}
exports.userInit = userInit;
async function rolesInit() {
    let rolesCount = await model_5.roleSchema.count({}).exec();
    if (rolesCount) {
        console.log(`${rolesCount} Roles found in DB`);
    }
    else {
        await module_1.addRolesFromJSON();
        console.log(`Roles created successfully`);
    }
}
exports.rolesInit = rolesInit;
async function siteConstants() {
    let existingConstantsCount = await model_1.constantSchema.find().count().exec();
    if (!existingConstantsCount) {
        await model_1.constantSchema.create(JSON.parse(fs_1.readFileSync(path_1.join(__dirname, "system_config.json"), "utf8")));
        console.log(`site-constants created successfully`);
    }
    else {
        console.log(`${existingConstantsCount} site-constants found in DB`);
    }
}
exports.siteConstants = siteConstants;
async function notifications() {
    let existingNotificationsCount = await model_2.notificationSchema.find().count().exec();
    if (!existingNotificationsCount) {
        let { roles } = await module_1.role_list();
        let templateList = await model_3.TemplateSchema.find({}).exec();
        let notificationsList = roles.map((user) => {
            let templates = [];
            templateList.forEach((template) => {
                // let removeTemplates = ['invite','changeMobileOTP', 'changeEmailOTP', 'forgotPasswordOTP'];
                // if (!removeTemplates.includes(template.templateName)) {
                templates.push({
                    templateName: template.templateName,
                    displayName: template.displayName || template.templateName,
                    email: true,
                    mobile: true,
                });
                // }
            });
            return {
                role: user.role,
                templates
            };
        });
        await model_2.notificationSchema.create(notificationsList);
        console.log(`notifications created successfully`);
    }
    else {
        console.log(`existing notifications found in DB`);
    }
}
exports.notifications = notifications;
async function templates() {
    let existingTemplatesCount = await model_3.TemplateSchema.find().count().exec();
    if (!existingTemplatesCount) {
        await model_3.TemplateSchema.create(JSON.parse(fs_1.readFileSync(path_1.join(__dirname, "email_template.json"), "utf8")));
        console.log(`templates created successfully`);
    }
    else {
        console.log(`${existingTemplatesCount} templates found in DB`);
    }
}
exports.templates = templates;
async function httpRequest(options) {
    return new Promise((resolve, reject) => {
        request(Object.assign({}, options, { json: true }), function (err, response, body) {
            if (err) {
                return reject(err);
            }
            if (body.errors) {
                return reject(body.errors);
            }
            try {
                resolve(body || {});
            }
            catch (error) {
                console.log("Failed to parse JSON", options.url, body);
                reject(new Error(`Failed to fetch results`));
            }
        });
    }).catch(error => {
        throw new custom_error_1.APIError(error[0].error);
    });
}
exports.httpRequest = httpRequest;
async function smsTemplates() {
    let existingTemplatesCount = await model_4.smsTemplateSchema.find().count().exec();
    if (!existingTemplatesCount) {
        await model_4.smsTemplateSchema.create(JSON.parse(fs_1.readFileSync(path_1.join(__dirname, "sms_template.json"), "utf8")));
        console.log(`SMS templates created successfully`);
    }
    else {
        console.log(`existing SMS templates found in DB`);
    }
}
exports.smsTemplates = smsTemplates;
async function fetchRoles() {
    let Options = {
        url: `${urls_1.RBAC_URL}/capabilities/policy/list`,
        method: "GET",
        json: true
    };
    return await httpRequest(Options);
}
exports.fetchRoles = fetchRoles;
async function checkRoleScope(role, capabilities) {
    try {
        const data = await fetchRoles();
        if (!data.status)
            throw new Error("Error to fetch Roles");
        let eligible = role ? await role.map((eachRole) => {
            if (data.data.find((d) => d[0] == eachRole && d[2] == capabilities)) {
                return true;
            }
            else {
                return false;
            }
        }) : [false];
        if (eligible.includes(true)) {
            return true;
        }
        else {
            return false;
        }
        // for (const policy of data.data) {
        //     if ((policy[0] == role) && (policy[2] == capabilities)) {
        //         return true
        //     }
        // }
        // return false
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
exports.checkRoleScope = checkRoleScope;
