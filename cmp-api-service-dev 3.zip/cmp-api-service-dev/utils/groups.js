"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const request = require("request-promise");
const urls_1 = require("./urls");
const users_1 = require("./users");
var roleHierarchy;
(function (roleHierarchy) {
    roleHierarchy[roleHierarchy["owner"] = 0] = "owner";
    roleHierarchy[roleHierarchy["collaborator"] = 1] = "collaborator";
    roleHierarchy[roleHierarchy["viewer"] = 2] = "viewer";
})(roleHierarchy = exports.roleHierarchy || (exports.roleHierarchy = {}));
;
// Add Policies for Documents
async function groupsAddPolicy(userId, docId, role) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/document/user/add`,
            method: "POST",
            body: {
                userId: userId,
                docId: docId,
                role: role
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupsAddPolicy = groupsAddPolicy;
;
// Add Policies for Documents
async function groupsRemovePolicy(userId, docId, role) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/document/user/remove`,
            method: "POST",
            body: {
                userId: userId,
                docId: docId,
                role: role
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupsRemovePolicy = groupsRemovePolicy;
;
// Add Policies for Documents
async function groupsPolicyFilter(userId, filter = 0, policy = "p") {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/policy/filter`,
            method: "GET",
            qs: {
                userId: userId,
                filter: filter,
                policy: policy
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupsPolicyFilter = groupsPolicyFilter;
;
async function GetUserIdsForDocWithRole(docId, role) {
    try {
        let policies = await groupsPolicyFilter(`document/${docId}`, 1, "p");
        if (!policies.data)
            throw new Error("policies not found for this document.");
        let users = policies.data.filter((policy) => {
            if (policy[2] == role)
                return policy[0];
        }).map((key) => key[0]);
        return [...new Set(users)];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.GetUserIdsForDocWithRole = GetUserIdsForDocWithRole;
;
async function GetDocIdsForUser(userId, type, docRole) {
    try {
        let userType = type || "user";
        let docRoles = docRole || ["collaborator", "viewer"];
        if (userType == "group") {
            let group = await users_1.groupFindOne("id", userId);
            if (!group || !group.is_active)
                return [];
        }
        let policies = await groupsPolicyFilter(`${userType}/${userId}`, 0, "p");
        let users = policies.data.filter((policy) => {
            if (docRoles.includes(policy[2]))
                return policy;
        }).map((key) => key[1].substring(key[1].indexOf("/") + 1));
        return [...new Set(users)];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.GetDocIdsForUser = GetDocIdsForUser;
;
// get Role of Doc in return Array[2] 
async function getRoleOfDoc(userId, docId, type) {
    try {
        let userType = type || "user";
        let { data: policies } = await groupsPolicyFilter(`${userType}/${userId}`, 0, "p");
        let data = policies.filter((key) => {
            if (key[1].includes(docId) && ["owner", "collaborator", "viewer"].includes(key[2]))
                return key;
        });
        return data[0];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.getRoleOfDoc = getRoleOfDoc;
;
async function shareDoc(userId, type, docId, role) {
    try {
        let userRole = await getRoleOfDoc(userId, docId, type);
        if (!userRole) {
            return await groupsAddPolicy(`${type}/${userId}`, docId, role);
        }
        if (userId && roleHierarchy[userRole[2]] > roleHierarchy[role]) {
            await groupsRemovePolicy(`${type}/${userId}`, docId, userRole[2]);
            return await groupsAddPolicy(`${type}/${userId}`, docId, role);
        }
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.shareDoc = shareDoc;
;
async function GetUserIdsForDoc(docId) {
    try {
        let policies = await groupsPolicyFilter(`document/${docId}`, 1, "p");
        if (!policies.data)
            throw new Error("policies not found for this document.");
        let users = (policies.data || []).map((key) => key[0]);
        return [...new Set(users)];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.GetUserIdsForDoc = GetUserIdsForDoc;
;
async function GetDocCapabilitiesForUser(userId, docId, type) {
    try {
        let userType = type || "user";
        let policies = await groupsPolicyFilter(`${userType}/${userId}`, 0, "p");
        if (!policies.data)
            throw new Error("policies not found for this User.");
        let capability = policies.data.filter((policy) => {
            if (policy[1].includes(docId))
                return policy;
        }).map((key) => key[2]);
        return [...new Set(capability)];
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.GetDocCapabilitiesForUser = GetDocCapabilitiesForUser;
;
// Get user exist in group ids
async function userGroupsList(userId) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/group/list/${userId}`,
            method: "GET",
            json: true
        };
        return (await request(Options)).groups;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.userGroupsList = userGroupsList;
;
// Get group is user ids
async function groupUserList(groupId) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/group/user/list/${groupId}`,
            method: "GET",
            json: true
        };
        return (await request(Options)).users;
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.groupUserList = groupUserList;
;
//  it will create users by group id in group rbc module
async function addUserToGroup(userId, groupId) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/group/user/add`,
            method: "POST",
            body: {
                userId: userId,
                groupId: groupId
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.addUserToGroup = addUserToGroup;
;
//  it will remove user by group id in group rbc module
async function removeUserToGroup(userId, groupId) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/group/user/remove`,
            method: "POST",
            body: {
                userId: userId,
                groupId: groupId
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.removeUserToGroup = removeUserToGroup;
;
async function checkCapability(user, scope, capability) {
    try {
        let Options = {
            uri: `${urls_1.GROUPS_URL}/policy/enforce`,
            method: "GET",
            qs: {
                userId: user,
                scope: scope,
                capability: capability
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.checkCapability = checkCapability;
;
