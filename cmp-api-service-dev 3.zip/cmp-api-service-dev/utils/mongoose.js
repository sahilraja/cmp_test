"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose = require("mongoose");
const tunnel = require("tunnel-ssh");
const os_1 = require("os");
const path = require("path");
const fs_1 = require("fs");
const urls_1 = require("./urls");
const role_management_1 = require("./role_management");
async function initializeDB() {
    try {
        await role_management_1.rolesInit();
        await role_management_1.siteConstants();
        await role_management_1.templates();
        await role_management_1.smsTemplates();
        await role_management_1.userInit();
        await role_management_1.notifications();
        // await init();
    }
    catch (err) {
        console.error(err);
    }
}
function handleMongooseConnection(successMessage) {
    const db = mongoose.connection;
    db.on('error', function (err) {
        console.error(err);
    });
    db.once('open', function () {
        // we're connected!
        console.log(successMessage);
        initializeDB();
    });
}
if (!urls_1.USE_REMOTE_DB) {
    mongoose.connect(process.env.MONGO_URL, { useNewUrlParser: true });
    handleMongooseConnection("Local DB connected ");
}
else {
    const sshTunnelConfig = {
        agent: process.env.SSH_AUTH_SOCK,
        username: 'ubuntu',
        privateKey: fs_1.readFileSync(path.join(os_1.homedir(), '.ssh/citiis2.pem')),
        host: '13.235.227.24',
        port: 22,
        dstHost: 'localhost',
        dstPort: 27017,
    };
    tunnel(sshTunnelConfig, function (error, server) {
        if (error) {
            console.log("SSH connection error: " + error);
        }
        mongoose.connect('mongodb://localhost:27017/cmp-dev?authSource=admin', { auth: {
                user: 'cmp-dev',
                password: 'Hello6362373783'
            } });
        handleMongooseConnection("Remote DB connection successful");
    });
}
