"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const model_1 = require("./model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const error_msg_1 = require("../utils/error_msg");
async function stepCount() {
    return await model_1.StepsSchema.count({}).exec();
}
async function create(userId, payload, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `add-edit-step`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    const stepInfo = await model_1.StepsSchema.create(Object.assign({}, payload, { nameCode: payload.name, s_no: (await stepCount()) + 1, createdBy: userId }));
    return { stepInfo, successMessage: `Step created successfully` };
}
exports.create = create;
async function list() {
    return await model_1.StepsSchema.find({}).exec();
}
exports.list = list;
async function stepDetail(id) {
    return await model_1.StepsSchema.findById(id).exec();
}
exports.stepDetail = stepDetail;
async function updateStep(id, updates, userRole) {
    const isEligible = await role_management_1.checkRoleScope(userRole, `add-edit-step`);
    if (!isEligible) {
        throw new custom_error_1.APIError(error_msg_1.PROJECT_ROUTER.UNAUTHORIZED_ACCESS);
    }
    if (updates.name) {
        updates = Object.assign({}, updates, { nameCode: updates.name });
    }
    const stepInfo = await model_1.StepsSchema.findByIdAndUpdate(id, { $set: updates }, { new: true }).exec();
    return { stepInfo, successMessage: `Step updated successfully` };
}
exports.updateStep = updateStep;
async function getStepsByIds(ids) {
    return await model_1.StepsSchema.find({ _id: { $in: ids } }).exec();
}
exports.getStepsByIds = getStepsByIds;
