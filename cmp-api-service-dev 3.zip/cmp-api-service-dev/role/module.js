"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const request = require("request-promise");
const urls_1 = require("../utils/urls");
const fs = require("fs");
const path_1 = require("path");
const users_1 = require("../utils/users");
const model_1 = require("./model");
const role_management_1 = require("../utils/role_management");
const custom_error_1 = require("../utils/custom-error");
const role_management_2 = require("../utils/role_management");
const error_msg_1 = require("../utils/error_msg");
// Get Roles List
async function role_list() {
    let roles = await model_1.roleSchema.find();
    if (roles.length) {
        return {
            status: true,
            roles: roles
        };
    }
    else {
        return { roles: [] };
    }
}
exports.role_list = role_list;
;
async function roles_list() {
    let roles = JSON.parse(fs.readFileSync(path_1.join(__dirname, "..", "utils", "roles.json"), "utf8"));
    let listOfRoles = roles.map(role => {
        return { role: role.role, description: role.description, category: role.category };
    });
    return {
        status: true,
        roles: listOfRoles
    };
}
exports.roles_list = roles_list;
;
async function capabilities_list() {
    let capabilities = JSON.parse(fs.readFileSync(path_1.join(__dirname, "..", "utils", "capabilities.json"), "utf8"));
    let listcapabilities = capabilities.map(capability => {
        return { capability: capability.capability, description: capability.description, scope: capability.scope, shortDescription: capability.shortDescription, category: capability.category };
    });
    let result = listcapabilities.reduce((response, capability) => {
        response[capability.category] = response[capability.category] || [];
        response[capability.category].push(capability);
        return response;
    }, Object.create(null));
    result = Object.keys(result).reduce((p, r) => (Object.assign({}, p, { [r]: result[r].sort((a, b) => a.shortDescription.localeCompare(b.shortDescription, 'en', { sensitivity: 'base' })) })), {});
    // console.log(result);
    return {
        status: true,
        capabilities: result
    };
}
exports.capabilities_list = capabilities_list;
;
//  Check Role Scope
// export async function checkRoleScope(role: any, capabilities: any) {
//     try {
//         let Options = {
//             uri: `${RBAC_URL}/capabilities/policy/list`,
//             method: "GET",
//             json: true
//         }
//         let data = await request(Options);
//         if (!data.status) throw new Error("Error to fetch Roles")
//         if (data.data.some((policy: any) => policy[0] == role && policy[2] == capabilities)) {
//             return true
//         }
//         return false
//     } catch (err) {
//         console.error(err);
//         throw err
//     }
// }
async function userRoleAndScope(userId) {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/list/${userId}`,
            method: "GET",
            json: true
        };
        let success = await request(Options);
        if (!success.status)
            throw new Error(error_msg_1.USER_ROUTER.SOMETHING_WENT_WRONG);
        // success.data.map((key: any) => {
        //     if (object[key.role]) {
        //         object[key.role].push(key.scope)
        //     } else {
        //         if (key.scope == "global") {
        //             object[key.scope] = [key.role]
        //         } else {
        //             object[key.role] = [key.scope]
        //         }
        //     }
        // });
        // return { data: object, user: userId }
        // let object: any = {}
        // success.data.map((eachRole: any) => {
        //     eachRole.map((key: any) => {
        //         if (object[key.role]) {
        //             object[key.role].push(key.scope)
        //         } else {
        //             if (key.scope == "global") {
        //                 object[key.scope] = [key.role]
        //             } else {
        //                 object[key.role] = [key.scope]
        //             }
        //         }
        //     })
        // });
        return { data: success.data, user: userId };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.userRoleAndScope = userRoleAndScope;
async function usersForRole(role) {
    try {
        if (!role)
            throw new Error("Missing Role.");
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/user/list`,
            method: "GET",
            qs: {
                role: role,
            },
            json: true
        };
        let success = await request(Options);
        if (!success)
            throw new Error("Fail to get users.");
        let users = await users_1.userList({ _id: { $in: success.users } }, { firstName: 1, middleName: 1, lastName: 1, email: 1, phone: 1, is_active: 1 });
        return { role: role, users: users };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
    ;
}
exports.usersForRole = usersForRole;
;
async function capabilities() {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/capabilities/list`,
            method: "GET",
            json: true
        };
        let data = await request(Options);
        if (!data.status)
            throw new Error("Error to fetch Roles");
        return data;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.capabilities = capabilities;
async function allrolecapabilities() {
    try {
        let Options = {
            uri: `${urls_1.RBAC_URL}/role/all/capabilities/list`,
            method: "GET",
            json: true
        };
        let data = await request(Options);
        if (!data.status)
            throw new Error("Error to fetch Roles");
        return data;
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.allrolecapabilities = allrolecapabilities;
async function addCapability(role, scope, capability, userId, auth) {
    try {
        auth = auth == false ? false : true;
        if (auth) {
            let userRoles = await userRoleAndScope(userId);
            let userRole = userRoles.data[0];
            const isEligible = await role_management_2.checkRoleScope(userRole, "display-role-management");
            if (!isEligible) {
                throw new custom_error_1.APIError("Unauthorized for this Action", 403);
            }
        }
        let Options = {
            uri: `${urls_1.RBAC_URL}/capabilities/add`,
            method: "POST",
            body: {
                "role": role,
                "scope": scope,
                "capability": capability
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.addCapability = addCapability;
;
async function removeCapability(role, scope, capability, userId) {
    try {
        let userRoles = await userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_2.checkRoleScope(userRole, "display-role-management");
        if (!isEligible) {
            throw new custom_error_1.APIError("Unauthorized for this Action", 403);
        }
        let Options = {
            uri: `${urls_1.RBAC_URL}/capabilities/remove`,
            method: "PUT",
            body: {
                "role": role,
                "scope": scope,
                "capability": capability
            },
            json: true
        };
        return await request(Options);
    }
    catch (err) {
        throw err;
    }
    ;
}
exports.removeCapability = removeCapability;
;
async function updaterole(role, bodyObj, userId) {
    try {
        let userRoles = await userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_2.checkRoleScope(userRole, "display-role-management");
        if (!isEligible) {
            throw new custom_error_1.APIError("Unauthorized for this Action", 403);
        }
        let findRole = await model_1.roleSchema.find({ role: role });
        if (!findRole.length) {
            throw new Error("Role does not exist");
        }
        let roleData = findRole.map((_role) => {
            return _role;
        });
        let updateRole = await model_1.roleSchema.update({ role: role }, {
            category: bodyObj.category ? bodyObj.category : roleData[0].category,
            roleName: bodyObj.roleName ? bodyObj.roleName : roleData[0].roleName,
            description: bodyObj.description ? bodyObj.description : roleData[0].description
        }).exec();
        if (updateRole) {
            return { success: true, data: updaterole };
        }
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
exports.updaterole = updaterole;
async function addRolesFromJSON() {
    try {
        let data = await roles_list();
        if (!data.roles.length)
            throw new Error("Error to fetch Roles");
        let roles = data.roles.map((eachRole) => {
            return {
                role: eachRole.role,
                roleName: eachRole.description,
                description: eachRole.description,
                category: eachRole.category
            };
        });
        let response = await model_1.roleSchema.insertMany(roles);
        return { success: true, response };
    }
    catch (err) {
        console.error(err);
        throw err;
    }
}
exports.addRolesFromJSON = addRolesFromJSON;
async function addRole(userId, bodyObj) {
    try {
        let userRoles = await userRoleAndScope(userId);
        let userRole = userRoles.data[0];
        const isEligible = await role_management_2.checkRoleScope(userRole, "display-role-management");
        if (!isEligible) {
            throw new custom_error_1.APIError("Unauthorized for this Action", 403);
        }
        if (!bodyObj.role || !bodyObj.category || !bodyObj.roleName)
            throw new Error("All mandatory fields are reuired");
        let role = bodyObj.role.replace(/ /g, '-');
        role = role.toLowerCase().trim();
        let response = await model_1.roleSchema.create({
            role: bodyObj.role,
            roleName: bodyObj.roleName,
            description: bodyObj.description,
            category: bodyObj.category,
            createdBy: userId
        });
        return { success: true, response };
    }
    catch (err) {
        console.log(err);
        throw err;
    }
}
exports.addRole = addRole;
async function addRoleCapabilitiesFromJSON(userId) {
    try {
        await role_management_1.init();
        return { success: true };
    }
    catch (err) {
        console.error(err);
    }
}
exports.addRoleCapabilitiesFromJSON = addRoleCapabilitiesFromJSON;
