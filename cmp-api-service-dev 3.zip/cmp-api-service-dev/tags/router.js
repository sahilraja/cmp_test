"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const custom_error_1 = require("../utils/custom-error");
const utils_1 = require("../utils/utils");
const router = express_1.Router();
//  list of tag
router.get("/list", async (req, res, next) => {
    try {
        res.status(200).send(await module_1.tag_list(req.query.search));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
// Merge tags
router.post("/merge", utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.mergeTags(req.body, req.token, res.locals.user._id));
    }
    catch (err) {
        next(new custom_error_1.APIError(err.message));
    }
});
module.exports = router;
