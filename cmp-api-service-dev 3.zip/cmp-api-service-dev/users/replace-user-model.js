"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const SchemaDef = new mongoose_1.Schema({
    oldUser: { type: String },
    replacedWith: { type: String },
    replacedBy: { type: String }
}, { timestamps: true });
exports.ReplaceUserSchema = mongoose_1.model('replace_user', SchemaDef);
