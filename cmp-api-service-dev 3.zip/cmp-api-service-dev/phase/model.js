"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const mongoosePaginate = require("mongoose-paginate");
const schema = new mongoose_1.Schema({
    phaseName: { type: String },
    phaseCode: { type: String, unique: true },
    colorCode: { type: String },
    createdBy: { type: String },
    disable: { type: Boolean, default: false }
}, { timestamps: true });
schema.plugin(mongoosePaginate);
exports.phaseSchema = mongoose_1.model("phase", schema);
