"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
let SchemaDef = new mongoose_1.Schema({
    docId: { type: String },
    taskId: { type: String },
    activityBy: { type: String },
    taskStatus: { type: String }
}, { timestamps: true });
SchemaDef.index({ taskId: 1 });
SchemaDef.index({ taskId: 1, docId: 1 });
exports.DocumentTaskActivityModel = mongoose_1.model(`doc_task_activities`, SchemaDef);
