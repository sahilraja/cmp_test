"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mongoose_1 = require("mongoose");
const schema = new mongoose_1.Schema({
    docId: { type: mongoose_1.Schema.Types.ObjectId, ref: 'documents' },
    userId: { type: String },
    isDeleted: { type: Boolean, default: false },
}, { timestamps: true });
schema.index({ docId: 1, userId: 1, isDeleted: 1 });
exports.moveToMyDocsModel = mongoose_1.model("document-moveto-mydocs", schema);
