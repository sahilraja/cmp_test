"use strict";
const express_1 = require("express");
const http_status_codes_1 = require("http-status-codes");
const module_1 = require("./module");
const custom_error_1 = require("../utils/custom-error");
const utils_1 = require("../utils/utils");
const router = express_1.Router();
router.post('/create', async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.create(req.body));
    }
    catch (error) {
        next(error);
    }
});
router.post(`/list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.list(req.body));
    }
    catch (error) {
        next(error);
    }
});
router.post(`/paginated-list`, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.paginatedList(req.body, req.query.page, req.query.limit));
    }
    catch (error) {
        next(error);
    }
});
router.get(`/get-task-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getTaskLogs(req.query.taskId, req.token, res.locals.user.role));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-document-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getDocumentsLogs(req.query.docId, req.token, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-profile-edit-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getProfileLogs(req.query.userId, req.token, res.locals.user._id));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-merged-tags-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getMergedLogs());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-Project-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.projectLogs(req.query.projectId, req.token, res.locals.user));
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
router.get(`/get-role-logs`, utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(http_status_codes_1.OK).send(await module_1.getRoleLogs());
    }
    catch (error) {
        next(new custom_error_1.APIError(error.message));
    }
});
module.exports = router;
