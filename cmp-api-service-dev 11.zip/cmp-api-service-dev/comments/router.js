"use strict";
const express_1 = require("express");
const module_1 = require("./module");
const utils_1 = require("../utils/utils");
const router = express_1.Router();
//  list roles
router.get('/list/:doc_id', async (req, res, next) => {
    try {
        let type = req.query.type ? req.query.type : "document";
        res.status(200).send(await module_1.commentsList(req.params.doc_id, type));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
router.post('/add', utils_1.authenticate, async (req, res, next) => {
    try {
        res.status(200).send(await module_1.addComment(req.body, res.locals.user, req.token));
    }
    catch (err) {
        res.status(400).send({ error: err.message });
    }
    ;
});
module.exports = router;
